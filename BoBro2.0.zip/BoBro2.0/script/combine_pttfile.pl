# the script is used to combine the ptt  files of a same species
#! /usr/bin/perl -w
use strict;

my ($file_list, $operondir, $outputdir);
if (!$ARGV[0]) { print "the script is used to combine the ptt files of a same species\nperl combine_operonfile.pl -i files_list_faa -j pttdir -o ptt_combined_dir\n"; die ;}
for (my $i=0; $i<@ARGV; ++$i) {
        if ($ARGV[$i] eq "-i") {if ($ARGV[$i+1]) {$file_list = $ARGV[$i+1];}         else {print "wrong input format (-i)\n"; printmanul(); die "exit.\n";} }
        if ($ARGV[$i] eq "-j") {if ($ARGV[$i+1]) {$operondir = $ARGV[$i+1];}         else {print "wrong input format (-j)\n"; printmanul(); die "exit.\n";} }
        if ($ARGV[$i] eq "-o") {if ($ARGV[$i+1]) {$outputdir = $ARGV[$i+1];}         else {print "wrong input format (-o)\n"; printmanul(); die "exit.\n";} }
}

open (fp, "$file_list") || die "$!";
chomp (my @operon_list = <fp>);
close fp;

my ($operon_max, $operon_max_NC, $end_pos);
for (my $i = 0; $i < @operon_list; $i++){
	chomp (my @operon_temp = split (/\t/,$operon_list[$i]));
	if ($i ==0 ){
		$operon_max = $operon_temp[0];
		$operon_max_NC = $operon_temp[2];
		if (-e "$outputdir/$operon_max_NC.ptt"){
			system ("rm $outputdir/$operon_max_NC.ptt");
		}
		open (fp2, "$operondir/$operon_temp[2].ptt") || die "$!";
		chomp (my @aa = <fp2>);
		close fp2;
		open (fp1, ">>$outputdir/$operon_temp[2].ptt")||die "$!";
		for (my $j = 0; $j < @aa; $j++){
			if ($j == 0){
				chomp (my @bb = split(/\.\./,$aa[$j]));
				$end_pos = $bb[1];
			}
			print fp1 "$aa[$j]\n";
		}
	}else{
		if ($operon_temp[0] eq $operon_max){
			open (fp2, "$operondir/$operon_temp[2].ptt");
	                chomp (my @aa = <fp2>);
	                close fp2;
			my @bb = split (/\.\./,$aa[0]);
			for (my $j = 3; $j < @aa; $j++){
				chomp (my @bb= split (/\t/,$aa[$j]));
				chomp (my @cc = split (/\.\./,$bb[0]));
				my $start_new = $cc[0]+$end_pos;
				my $end_new = $cc[1]+$end_pos;
				print fp1 "$start_new\.\.$end_new";
				for (my $k=1; $k<@bb; $k++){
					print fp1 "\t$bb[$k]";
				}
				print fp1 "\n";
			}
			$end_pos += $bb[1];

		}else{
			close fp1;
			$operon_max = $operon_temp[0];
			$operon_max_NC = $operon_temp[2];
			if (-e "$outputdir/$operon_max_NC.ptt"){
	                        system ("rm $outputdir/$operon_max_NC.ptt");
	                }
			open (fp2, "$operondir/$operon_temp[2].ptt"); 
	                chomp (my @aa = <fp2>);
        	        close fp2;
	                open (fp1, ">>$outputdir/$operon_temp[2].ptt")||die "$!";
        	        for (my $j = 0; $j < @aa; $j++){
                	        if ($j == 0){
                        	        chomp (my @bb = split(/\.\./,$aa[$j]));
                                	$end_pos = $bb[1];
	                        }
        	                print fp1 "$aa[$j]\n";
               		}
		}
	}
}
close fp1;
