/************************************************************************/
/* Author: Qin Ma <maqin@csbl.bmb.uga.edu>, Feb. 16, 2010
 * read all kinds of input files	
 */

#include "read_file.h"
#define MAXC 100000
#define MAX_SEQUENCE_LENGTH 3000
#define MAX_PROMOTER_NUM 200
#define MAXC 100000

static int bb[USHRT_MAX];
static char delims[] = " _>\t\r\n";
static char delims1[] = ":";
static char *atom = NULL;
/***********************************************************************/
/* read the annotation file, if any, with the format of NC_000913_motif */
void read_annotation(FILE* fp)
{
        char *buffer;
        int i=0;
        buffer=(char*)malloc(sizeof(char)*MAXC);
        /* get the sequences number*/
        while(fgets(buffer,MAXC,fp)!=NULL)  i++;
        Annotation *aa;
        /* make point fp to the begining of the file by rewind function */
	rewind(fp);
        i=0;
        while(fgets(buffer,MAXC,fp)!=NULL)
        {
                int j=0,k=0;
                AllocVar(aa);
                aa->init = dsNew(20);
                aa->end = dsNew(20);
                aa->TF = alloc2c (20,10);
                atom = strtok(buffer, delims);
                atom = strtok(NULL, delims);
                atom = strtok(NULL, delims);
                atom = strtok(NULL, delims);
                while (atom != NULL)
                {
                        j++;
                        if (j%3 == 1) strcpy(aa->TF[k], atom);
                        else if (j%3 == 2) dsPush(aa->init,atoi(atom));
                        else if (j%3 == 0) {dsPush(aa->end, atoi(atom)); k++;}
                        atom = strtok(NULL, delims);
                }
		aa->num = k;
		/* save current annotations to global structure **anno */
                anno[i] = aa;
                i++;
        }
        free (buffer);
}

/***********************************************************************/
/*read the .closures file output by BoBro*/
void read_closures (FILE* fc)
{
        char *buffer;
	double significance=0;
        int i=0,j;
        /*get the number of closures*/
        clo_num=0;
        buffer=(char*)malloc(sizeof(char)*MAXC);
        while(fgets(buffer,MAXC,fc)!=NULL)
                if (buffer[0] == '#')  clo_num++;
        /* we need minus the first five head lines with # at the begining in .closures file */
	clo_num = clo_num-5;
	/* pop up the real number of candidate closures in input .closures file */
        printf ("There are %d candidate closures\n",clo_num);

        AllocArray(all, clo_num);
        /* set the indicator to the begining of the file and skip the first five header rows*/
        rewind(fc);
        for (i=0;i<5;i++)
		fgets(buffer,MAXC,fc);
        discrete *clo_row;
        AllocArray(clo_row, clo_num);
        /*count the number of motif (TFBS) in each closure which are saved in *clo_row*/
        i=0;
        int i_1=0;
        while(fgets(buffer,MAXC,fc)!=NULL)
        {
                if (buffer[0] == '#')
                {
                        j=0;
                        while(fgets(buffer,MAXC,fc)!=NULL)
                        {
                                if (buffer[0] == '-') break;
                                else  j++;
                        }
                        clo_row[i] = j;
                        i++;
                }
		if (buffer[0] == 'I')  i_1++;
        }
        /*read the information of each closure*/
        rewind(fc);
        for (i=0;i<5;i++)
                fgets(buffer,MAXC,fc);
        i=0;
	char *oper_name;
	AllocArray (oper_name,20);
        Closures *cctemp;
        while(fgets(buffer,MAXC,fc)!=NULL)
        {
		if (buffer[0] == 'I' )
		{
			AllocArray (oper_name,20);
			atom = strtok(buffer, delims);
			atom = strtok(NULL, delims);
			atom = strtok(NULL, delims);
			strcpy(oper_name, atom);	
		}
		/*read in the pvalue of each closure*/
		if (buffer[0] == ' ' && buffer[1] == 'P')
		{
			atom = strtok(buffer, delims);
			atom = strtok(NULL, delims);
			significance = atof(atom);
		}
		if (buffer[0] == '#')
                {
                        AllocVar(cctemp);
                        int temp = clo_row[i];
                        cctemp->sequence = dsNew(temp);
                        cctemp->position = dsNew(temp);
                        j=0;
			while(fgets(buffer,MAXC,fc)!=NULL)
                        {
                                if (buffer[0] == '-') break;
                                else
                                {
                                        atom = strtok(buffer, delims);
                                        cctemp->length = po->MOTIFLENGTH;
                                        dsPush(cctemp->sequence,atoi(atom));
                                        atom = strtok(NULL, delims);
                                        dsPush(cctemp->position,atoi(atom));
                                        j++;
                                }
                        }
			AllocArray (cctemp->name,20);
			strcpy(cctemp->name,oper_name);
			cctemp->significance = significance;
/*			printf ("%3.2e\n",cctemp->significance);*/
                        cctemp->closure_rows = j;
			/* save current closure's information to global **all */
                        all[i] = cctemp;
                        i++;
                }
        }
	/* compare similarity between the readed closures and generate a matrix clo_matr 
	 * so that we can find clique base on the 0-1 matrix by function 'regulon' */
        clo_matr = get_closure_matrix_1 (all, clo_num, po->thre);
}
/***********************************************************************/
void read_sequences(FILE* fp1 )
/*read fasta sequence file*/
{
        char *buffer;
        int i=0,j=0,k=0,t=0;
        buffer=(char*)malloc(sizeof(char)*MAX_SEQUENCE_LENGTH);
        /* get the sequences number*/
        s_rows=0;
        while(fgets(buffer,MAX_SEQUENCE_LENGTH,fp1)!=NULL)
                if (buffer[0]=='>') s_rows++;
	/* if there are less than two sequences in input file, err pop up */
	if (s_rows < 2)
	{
	       printf ("\nSorry, there is not enough sequences in your fasta file\n");
               exit(1);	   
	}    
	/* save the locus_id*/
	if (po->ID)
	{
		locus_id = alloc2c(s_rows,20);
		rewind(fp1);
		i=0;
		while(fgets(buffer,MAX_SEQUENCE_LENGTH,fp1)!=NULL)
	        {
			if (buffer[0]=='>')
			{
				atom = strtok(buffer, delims);
				atom = strtok(NULL, delims);
        	                atom = strtok(NULL, delims);
				strcpy(locus_id[i++], atom);
			}
		}
	}
	
	printf ("%d\n",s_rows);
	/*read the weighted sequences*/
	if (po->SequenceWeight)
        {
                AllocArray (SequenceWeight, s_rows);
                rewind(fp1);
                i=0;
                while(fgets(buffer,MAX_SEQUENCE_LENGTH,fp1)!=NULL)
                {
                        if (buffer[0]=='>')
                        {
                                atom = strtok(buffer, delims1);
                                atom = strtok(NULL, delims1);
                                SequenceWeight[i++] = atof(atom);
                        }
                }
        }

        s_col=(int*)malloc(sizeof(int)*s_rows);
        /* read in the sequences*/
        rewind(fp1);
        sequences= alloc2c(s_rows,MAX_SEQUENCE_LENGTH);
        while(fgets(buffer,MAX_SEQUENCE_LENGTH,fp1)!=NULL)
        {
		/* case insensitive */
		if(buffer[0]=='A'||buffer[0]=='T'||buffer[0]=='G'||buffer[0]=='C'||buffer[0]=='a'||buffer[0]=='t'||buffer[0]=='g'||buffer[0]=='c'||buffer[0]=='N'||buffer[0]=='n')
                {
                        t=1;
			/* fix the problem that there may exist \n between two '>' */
                        for (j=k;j<strlen(buffer)-1+k;j++)
                                sequences[i][j] = buffer[j-k];
                        k=k+strlen(buffer)-1;
                }
                else
                {
                        if (t==0) i=0;
                        else i++;
                        k=0;
                }
        }
        s_cols=strlen(sequences[0]);
        /*consider the situation of comparing sequences with different length*/
        for (i=0;i<s_rows;i++)
        {
                s_col[i]=strlen(sequences[i]);
		if (s_col[i] < po->MOTIFLENGTH)
		{
			printf ("\nThe %dth sequence are too short to find motif\n", i+1);
			/*printf ("\nSorry, the %dth sequence are too short to find motif\n", i+1);
	                exit(1);*/
		}
		/*printf ("%d\n",s_col[i]);*/
                if (strlen(sequences[i])>s_cols) 
		{
			s_cols=strlen(sequences[i]);
		}
        }
        /*the markov processing, generate a markov matrix so that we can simulate sequences*/
        p_markov = markov(sequences,s_rows);
        free (buffer);
}
/***********************************************************************/
/*read a combined file containing reference genomes for all the confirmed operons*/
void read_reference_genome (FILE* fp)
{
	char *buffer;
	buffer=(char*)malloc(sizeof(char)*MAX_SEQUENCE_LENGTH);
	int oper_num = 0;
	int  promo_num=0, t, k,i,j;
	/* count the number of operons */
	while(fgets(buffer,MAX_SEQUENCE_LENGTH,fp)!=NULL)
                if ((buffer[0]=='>')&&(buffer[1]=='>')) oper_num++;
	/* we minus the last >>end from the counter */	
	reference_oper_num = oper_num-1;
	AllocArray (genome,(oper_num-1));
	oper_num_all = oper_num-1;
	Reference_genome *genome_temp;
	AllocVar (genome_temp);
	oper_num=0;

	char **sequences_temp;
	int *clo_length;
	char name[20];
	sequences_temp = alloc2c(MAX_PROMOTER_NUM , MAX_SEQUENCE_LENGTH);
	AllocArray (clo_length, MAX_PROMOTER_NUM);
	rewind(fp);
	t=0,k=0;
	while(fgets(buffer,MAX_SEQUENCE_LENGTH,fp)!=NULL)
	{
		if ((buffer[0]=='>')&&(buffer[1]=='>')&& (t==0))
		{
			atom = strtok(buffer, delims);
  			strcpy(name, atom);
			AllocVar (genome_temp);
			AllocArray (genome_temp->oper_name, 20);
			promo_num = 0;
			continue;
		}
		if ((buffer[0]=='>')&&(buffer[1]=='>')&&(t==1))
		{
			genome_temp->sequences_r = alloc2c ((promo_num+1), MAX_SEQUENCE_LENGTH);
			AllocArray (genome_temp->clo_num,(promo_num+1));
			for (i=0; i<promo_num+1; i++)
				genome_temp->clo_num[i] = clo_length [i];
			for (i=0; i<promo_num+1; i++)
				for (j=0; j<clo_length[promo_num]; j++)
					genome_temp->sequences_r[i][j] = sequences_temp[i][j];
			strcpy (genome_temp->oper_name, name);
		       	genome_temp->seq_num = promo_num+1;	
			genome_temp->markov_matrix = markov(genome_temp->sequences_r,genome_temp->seq_num);
			/* save current reference genome to global **genome */
			genome[oper_num++] = genome_temp;
			AllocVar (genome_temp);
			AllocArray (genome_temp->oper_name, 20);
			atom = strtok(buffer, delims);
			strcpy(name, atom);
			promo_num = 0;
			t=0;
			continue;
		}
		/* case insensitive and adopt \n in each sequence */
		if(buffer[0]=='A'||buffer[0]=='T'||buffer[0]=='G'||buffer[0]=='C'||buffer[0]=='a'||buffer[0]=='t'||buffer[0]=='g'||buffer[0]=='c')
                {
                        t=1;
/*			printf ("%Zu\n",strlen(buffer));*/
                        for (j=k;j<strlen(buffer)-1+k;j++)
                                sequences_temp[promo_num][j] = buffer[j-k];
                        k=k+strlen(buffer)-1;
			clo_length [promo_num] = strlen(sequences_temp[promo_num]);
                }
                else
                {
                        if (t==0) promo_num = 0;
                        else promo_num++;
                        k=0;
                }
	}
}
/***********************************************************************/
/*the following functions are used to read microarray data matrix*/
/* Pre-read the datafile, retrieve gene labels and condition labels
 *  as well as determine the matrix size */
void get_matrix_size (FILE* fp)
{
        /*size_t n = 0;
        char *line;
        if (getline(&line, &n, fp)>=0)*/
	char line[MAXC];
        if (fgets(line,MAXC,fp)!=NULL)
        {
                atom = strtok(line, delims);
                atom = strtok(NULL, delims);
                while (atom != NULL)
                {
                        atom = strtok(NULL, delims);
                        cols++;
                }
        }
        /*while (getline(&line, &n, fp)>=0)*/
	while (fgets(line,MAXC,fp)!=NULL)
        {
                atom = strtok(line, delims);
                rows++;
        }
        fseek(fp, 0, 0);
}
/* Read in the labels on x and y, in microarray terms, genes(rows) and conditions(cols)*/
void read_labels (FILE* fp)
{
        int row = 0;
        int col;
        /*size_t n = 0;
        char *line;
        while (getline(&line, &n, fp)>=0)*/
	char line[MAXC];
	while (fgets(line,MAXC,fp)!=NULL)
        {
                atom = strtok(line, delims);
                if (row >= 1)
                        strcpy(genes_n[row-1], atom);
                atom = strtok(NULL, delims);
                col = 0;
                while (atom != NULL)
                {
                        if (row == 0)
                                strcpy(conds_n[col], atom);
                        atom = strtok(NULL, delims);
                        if (++col == cols) break;
                }
                if (++row == rows+1) break;
        }
        fseek(fp, 0, 0);
}

static int charset_add(discrete *ar, discrete s)
{
        int ps = s + SHRT_MAX;
        if (bb[ps]<0)
        {
                bb[ps] = sigma;
                ar[sigma++] = s;
        }
        return bb[ps];
}
/* initialize data for discretization */
void init_dis_m()
{
        int row, col;
        AllocArray(symbols, USHRT_MAX);
        memset(bb, -1, USHRT_MAX*sizeof(*bb));
        charset_add(symbols, 0);
        arr_c = alloc2d (rows,cols);
        for (row = 0; row < rows; row++)
                for (col = 0; col < cols; col++)
                        arr_c[row][col] = 0;
}
/*read discreted microarray data matrix*/
void read_discrete (FILE* fp)
{
        int row, col, i;
        init_dis_m();
        /*size_t n = 0;
        char *line;*/
        row = 1;
	/* Skip first line with condition labels */
        /*getline(&line, &n, fp);*/
	char line[MAXC];
        fgets(line,MAXC,fp);
        while (fgets(line,MAXC,fp)!=NULL)

        /*while (getline(&line, &n, fp)>=0)*/
        {
                atom = strtok(line, delims);
		/*skip the first column*/
                atom = strtok(NULL, delims);
                col = 0;
                while (atom != NULL)
                {
                        arr_c[row-1][col] = charset_add(symbols, atoi(atom));
                        atom = strtok(NULL, delims);
                        if (++col == cols) break;
                }
                if (++row == rows+1) break;
        }
        printf("Discretized data contains %d classes with charset [ ", sigma);
        for (i=0;i<sigma;i++)
                printf("%d ", symbols[i]); printf("]\n");
        fseek(fp, 0, 0);
}

/***********************************************************************/

