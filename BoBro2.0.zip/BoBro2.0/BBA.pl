# used to run BBC job
#! /usr/bin/perl -w
use strict;

if (!$ARGV[0]){
	print "\nUsage:\n\t\$ perl BBA.pl Input SeqNum\nMore detail, see README-BBA\n";
	exit(1);
}

system ("perl bin/BBA_Motif_Correlation.pl $ARGV[0] $ARGV[0].BBA $ARGV[1] >$ARGV[0].BBA.all");

print "The significantly co-occurence TF pairs are collected in $ARGV[0].BBA;\nFor all p-value, see $ARGV[0].BBA.all.\n\n";
