# used to run BBS job
#! /usr/bin/perl -w
use strict;

if (!$ARGV[0]){
	print "\nSearch motif in alignment format:\n\tperl BBS.pl motif_alignment promoters 1\nSearch motif in matrix format:\n\tperl BBS.pl motif_matrix promoters 2 \nSearch motif in consensus format\n\tperl BBS.pl motif_consensus promoters 3\nSearch motif considering background genome:\n\tperl BBS.pl motif_consensus promoters 1/2/3 background\n\nPlease go to README-BBS file for further details\n\n";
	exit(1);
}

if (!$ARGV[3]){
	if ($ARGV[2] == 1){
		system ("bin/BBS -i $ARGV[1] -j $ARGV[0]");
	}
	if ($ARGV[2] == 2){
		system ("bin/BBS -i $ARGV[1] -m $ARGV[0]");
	}
	if ($ARGV[2] == 3){
		system ("bin/BBS -p $ARGV[0] -i $ARGV[1] > $ARGV[0]_matrix");
	       	system ("bin/BBS -i $ARGV[1] -m $ARGV[0]_matrix");
	}
}else{
	if ($ARGV[2] == 1){
		system ("bin/BBS -i $ARGV[1] -j $ARGV[0] -z $ARGV[3]");
	}
	if ($ARGV[2] == 2){
		system ("bin/BBS -i $ARGV[1] -m $ARGV[0] -z $ARGV[3]");
	}
	if ($ARGV[2] == 3){
		system ("bin/BBS -p $ARGV[0] -i $ARGV[1] > $ARGV[0]_matrix");
	       	system ("bin/BBS -i $ARGV[1] -m $ARGV[0]_matrix -z $ARGV[3]");
	}
}
