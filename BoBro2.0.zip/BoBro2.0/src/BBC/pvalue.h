#ifndef _CLOSURE_PROCESS_H
#define _CLOSURE_PROCESS_H

#include "struct.h"
continuous **markov (char **sequences_r, int seq_num);


/*from closure_process*/
extern continuous **get_profile (char **sequence_temp,continuous **markov_matrix, int a, int b, int motif_number);
extern continuous **impovre_profle (continuous **scoreM, double  length_local_1);
extern discrete **frequency_matrix (char **sequence_temp, int a, int b, int motif_number);
extern continuous **impovre_profle_palindromic (continuous **scoreM, double  length_local_1,  char **sequence_1, int a ,int motif_number);

/*from pvalue*/
extern continuous **markov (char **sequences_r, int seq_num);

#endif
