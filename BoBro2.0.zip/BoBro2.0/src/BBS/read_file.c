/************************************************************************/
/* Author: Qin Ma <maqin@uga.edu>, Feb. 16, 2010
 * read all kinds of input files: fasta format sequences, motif alignment and motif profile matrix	
 */
/***********************************************************************/

#include "read_file.h"
#define MAX_SEQUENCE_LENGTH 10000
#define MAX_MOTIF_NAME_LENGTH 2000
#define MAX_MOTIF_LENGTH 1000
#define MAX_PATTERN_NUM 1000

static char delims[] = "_>\t\r\n";
static char delims1[] = ">\n";
static char *atom = NULL;

/***********************************************************************/
int scan_genome (continuous **scoreM, continuous AveScore, int motif_length, FILE* fp)
/*scan each seed in background genome*/
{
    sum_genome = 0;
    rewind(fp);
    
    int background_num =0, i,j,seq_length=0;
    bool IS_end_sequences = FALSE;
    continuous score_scan, score_scan_p, **scoreM_panlindromic;
    char *buffer, *buffer_combine_end,  *end_sequence;
    discrete *buffer_combine_end_number;
	
    scoreM_panlindromic = get_palindromic_profle (scoreM, motif_length) ;
    buffer=(char*)malloc(sizeof(char)*MAX_SEQUENCE_LENGTH);
    buffer_combine_end =(char*)malloc(sizeof(char)*MAX_SEQUENCE_LENGTH);
    end_sequence =(char*)malloc(sizeof(char)*motif_length);
    buffer_combine_end_number = change_AGCT_to_num(buffer_combine_end,seq_length);

    while(fgets(buffer,MAX_SEQUENCE_LENGTH,fp)!=NULL)
    {
	if (buffer[0]=='>') continue;
	if (IS_end_sequences)
	{
	    j=0;
	    for (i=0;i<strlen(end_sequence);i++)
		buffer_combine_end[j++] = end_sequence[i];
	    for (i=0;i<strlen(buffer)-1;i++)
	    {
		buffer_combine_end[j++] = buffer[i];
		sum_genome++;
	    }
	    seq_length = j;
	    /*printf ("all\t%Zu\t%Zu\t%d\n",strlen(buffer_combine_end),strlen(buffer),seq_length);*/
	}
	else
	{
	    j=0;
	    for (i=0;i<strlen(buffer)-1;i++)
            {
	        buffer_combine_end[j++] = buffer[i];
		sum_genome++;
	    }
	    seq_length = j;
	}
	buffer_combine_end_number = change_AGCT_to_num(buffer_combine_end,seq_length);
	for (i=0;i<seq_length-motif_length+1;i++)
	{
	    score_scan = 0;
	    score_scan_p = 0;	
	    for (j=0;j<motif_length;j++)
            {
		score_scan += scoreM[buffer_combine_end_number[i+j]+1][j];
                score_scan_p += scoreM_panlindromic[buffer_combine_end_number[i+j]+1][j];
            }
	    /*printf ("%.2f\n",po->conserve_background);*/
	    if (score_scan >= po->conserve_background*AveScore || score_scan_p >= po->conserve_background*AveScore)
		background_num++;
	}
	j=0;
	for (i=seq_length-motif_length+1; i<seq_length; i++)
	{
	    end_sequence[j++] = buffer_combine_end[i];	
	    IS_end_sequences = TRUE;
	}
    }
    /*free (buffer);
    free (buffer_combine_end);
    free (end_sequence);*/
    free (buffer_combine_end_number);
    fseek (fp,0,0);
    return background_num;
}
/***********************************************************************/
int scan_genome_markov (char **sequences, int motif_number, continuous **scoreM, continuous AveScore, int motif_length, FILE* fp)
/*scan each seed in background genome considering the markov chain model*/
{
    sum_genome = 0;
    rewind(fp);
    
    int background_num =0, i,j,seq_length=0;
    bool IS_end_sequences = FALSE;
    continuous score_scan, score_scan_p, **scoreM_panlindromic, **transM, trans_score=0, trans_score_RC=0;
    char *buffer, *buffer_combine_end,  *end_sequence, *current_seq, *current_seq_palindromic;
    discrete *buffer_combine_end_number;
	
    scoreM_panlindromic = get_palindromic_profle (scoreM, motif_length) ;
    buffer=(char*)malloc(sizeof(char)*MAX_SEQUENCE_LENGTH);
    buffer_combine_end =(char*)malloc(sizeof(char)*MAX_SEQUENCE_LENGTH);
    end_sequence =(char*)malloc(sizeof(char)*motif_length);
    buffer_combine_end_number = change_AGCT_to_num(buffer_combine_end,seq_length);
    transM = getTransMatrix (sequences, motif_number);
    AllocArray (current_seq, motif_length);

    while(fgets(buffer,MAX_SEQUENCE_LENGTH,fp)!=NULL)
    {
	if (buffer[0]=='>') continue;
	if (IS_end_sequences)
	{
	    j=0;
	    for (i=0;i<strlen(end_sequence);i++)
		buffer_combine_end[j++] = end_sequence[i];
	    for (i=0;i<strlen(buffer)-1;i++)
	    {
		buffer_combine_end[j++] = buffer[i];
		sum_genome++;
	    }
	    seq_length = j;
	}
	else
	{
	    j=0;
	    for (i=0;i<strlen(buffer)-1;i++)
            {
	        buffer_combine_end[j++] = buffer[i];
		sum_genome++;
	    }
	    seq_length = j;
	}
	buffer_combine_end_number = change_AGCT_to_num(buffer_combine_end,seq_length);
	for (i=0;i<seq_length-motif_length+1;i++)
	{
	    score_scan = 0;
	    score_scan_p = 0;	
	    for (j=0;j<motif_length;j++)
            {
		score_scan += scoreM[buffer_combine_end_number[i+j]+1][j];
                score_scan_p += scoreM_panlindromic[buffer_combine_end_number[i+j]+1][j];
            }

            for (j=0;j<motif_length;j++)
            	current_seq[j] = buffer_combine_end[i+j];
            trans_score = get_trans_score(sequences, current_seq, motif_number, motif_length);
            score_scan += trans_score;
            current_seq_palindromic = palindromic_seq (current_seq, motif_length);
            trans_score_RC = get_trans_score(sequences, current_seq_palindromic, motif_number, motif_length);
            score_scan_p += trans_score_RC;		

	    if (score_scan >= po->conserve_background*AveScore || score_scan_p >= po->conserve_background*AveScore)
		background_num++;
	}
	j=0;
	for (i=seq_length-motif_length+1; i<seq_length; i++)
	{
	    end_sequence[j++] = buffer_combine_end[i];	
	    IS_end_sequences = TRUE;
	}
    }
    free (buffer_combine_end_number);
    free (current_seq);
    fseek (fp,0,0);
    return background_num;
}
/***********************************************************************/
discrete *change_AGCT_to_num (char *seq, int length)
{
        int i=0;
        discrete *number;
        AllocArray (number,length);
        for (i=0;i<length;i++)
                number[i]=0;
        for (i=0;i<length;i++)
        {
                if (seq[i]=='G' || seq[i]=='g') number[i] = 1;
                if (seq[i]=='C' || seq[i]=='c') number[i] = 2;
                if (seq[i]=='T' || seq[i]=='t') number[i] = 3;
        }
        return number;
}
/***********************************************************************/
void read_sequences(FILE* fp1 )
/*read fasta format sequence file*/
{
        char *buffer;
        buffer=(char*)malloc(sizeof(char)*MAX_SEQUENCE_LENGTH);
        /* get the sequences number*/
        s_rows=0;
        while(fgets(buffer,MAX_SEQUENCE_LENGTH,fp1)!=NULL)
                if (buffer[0]=='>') s_rows++;
	printf ("there are %d sequences\n", s_rows);
	/* if there are less than two sequences in input file, err pop up */
	if (s_rows < 1)
	       errAbort ("\nSorry, there is not enough sequences in your fasta file\n");
	/*save the description in line with >*/
	SequenceInfo = alloc2c(s_rows,200);
	rewind(fp1);
	int SequenceId=0;
	while(fgets(buffer,MAX_SEQUENCE_LENGTH,fp1)!=NULL)
	{
		if (buffer[0]=='>')
		{
			atom = strtok(buffer, delims1);
			if (strlen(atom)>200)
				errAbort("\nSorry, the title of squence is too long (>200 chars)\n");
			/*atom = strtok(NULL, delims);
        	        atom = strtok(NULL, delims);*/
			strcpy(SequenceInfo[SequenceId++], atom);
		}
	}
        /* read in the sequences*/
        int i=0,j=0,k=0,t=0;
        s_col=(int*)malloc(sizeof(int)*s_rows);
        rewind(fp1);
        sequences = alloc2c(s_rows,MAX_SEQUENCE_LENGTH);

	 /* change A T C G to 0 1 2 3*/
        seq_matrix = alloc2d(s_rows,MAX_SEQUENCE_LENGTH);
        for (i=0;i<s_rows; i++)
                for (j=0;j<MAX_SEQUENCE_LENGTH; j++)
                        seq_matrix[i][j] = 0;

        while(fgets(buffer,MAX_SEQUENCE_LENGTH,fp1)!=NULL)
        {
		if (strlen(buffer) > MAX_SEQUENCE_LENGTH )
		{
			errAbort("\nSorry, the length of promoter squence is too long (>10000 nucleotides)\n");	
		}
                /* case insensitive */
		if(buffer[0]=='A'||buffer[0]=='T'||buffer[0]=='G'||buffer[0]=='C'||buffer[0]=='a'||buffer[0]=='t'||buffer[0]=='g'||buffer[0]=='c'||buffer[0]=='N'||buffer[0]=='n')
                {
                        t=1;
			/* fix the problem that there may exist \n between two '>' */
                        for (j=k;j<strlen(buffer)-1+k;j++)
			{
                                sequences[i][j] = buffer[j-k];
				if (buffer[j-k]=='T' || buffer[j-k]=='t') seq_matrix[i][j] = 3;
                                if (buffer[j-k]=='C' || buffer[j-k]=='c') seq_matrix[i][j] = 2;
                                if (buffer[j-k]=='G' || buffer[j-k]=='g') seq_matrix[i][j] = 1;
			}
                        k=k+strlen(buffer)-1;
                }
                else
                {
                        if (t==0) i=0;
                        else i++;
                        k=0;
                }
        }
        s_cols=strlen(sequences[0]);
        s_col_min=strlen(sequences[0]);
        /*consider the situation of comparing sequences with different length*/
        for (i=0;i<s_rows;i++)
        {
                s_col[i]=strlen(sequences[i]);
                if (strlen(sequences[i])>s_cols) s_cols=strlen(sequences[i]);
                if (strlen(sequences[i])<s_col_min) s_col_min=strlen(sequences[i]);
        }
        /*the markov processing, generate a markov matrix so that we can simulate sequences*/
        p_markov = markov(sequences,s_rows);
	
	/*print out the markov chain matrix*/
	/*for (i=0; i< 5; i++)
	{
	    for (j=0; j<5; j++)
	    {
	    	printf ("%.2f\t", p_markov[i][j]);
	    }
	    printf ("\n");
	}*/

        free (buffer);
	fseek (fp1,0,0);
}
/***********************************************************************/
void read_motif_matrix(FILE* fm)
/* read motif matrix file*/
{
	char *buffer;	
	buffer=(char*)malloc(sizeof(char)*MAX_MOTIF_LENGTH);
	/*get matrix number*/
	matrix_num = 0;
	while(fgets(buffer,MAX_MOTIF_LENGTH,fm)!=NULL)
        {
                if(buffer[0]=='>')
                        matrix_num++;
        }
	matrix_num = matrix_num -1;

	AllocArray (Matrix, matrix_num);
	MotifMatrix *Matrix_temp;
	AllocVar (Matrix_temp);

	discrete **matrix;
	int RowNum=0, ColNum=0, i=0, j=0, t=0, number = 0;
        char name[MAX_MOTIF_NAME_LENGTH];
        matrix= alloc2d(5 , MAX_MOTIF_LENGTH);
	
	rewind(fm);
	while(fgets(buffer,MAX_MOTIF_LENGTH,fm)!=NULL)
        {
                if ((buffer[0]=='>')&&(t==0))
                {
                        atom = strtok(buffer, delims);
                        strcpy(name, atom);
                        AllocVar (Matrix_temp);
                        AllocArray (Matrix_temp->motif_name, MAX_MOTIF_NAME_LENGTH);
                        RowNum = 0;
                        continue;
                }  
                if ((buffer[0]=='>')&&(t==1))
                {  
                        if (RowNum < 2)
                                errAbort("Sorry, the  motif matrix is not significant enough\n");
                        Matrix_temp->matrix = alloc2d (5, ColNum);
                        Matrix_temp->ColNum = ColNum;
                        for (i=1; i<5; i++)
                        { 
                                for (j=0; j<Matrix_temp->ColNum; j++) 
                                        Matrix_temp->matrix[i][j] = matrix[i][j];
                        }
                        strcpy (Matrix_temp->motif_name, name);
                        Matrix_temp->RowNum = RowNum;
			if (Matrix_temp->ColNum > s_col_min)
			{
				printf ("%d\t%d\n",s_col_min, Matrix_temp->ColNum);
				errAbort ("\nSorry, some input sequences are too short to search current matrix\n");
			}
                        /* save current alignment to global **Alignment */
                        Matrix[number++] = Matrix_temp;

                        AllocVar (Matrix_temp);
                        AllocArray (Matrix_temp->motif_name, MAX_MOTIF_NAME_LENGTH);
                        atom = strtok(buffer, delims);
                        strcpy(name, atom);
                        RowNum = 0;
			ColNum = 0;
                        t=0;
			i=0;
                        continue;
                }
		if(buffer[0]=='A'||buffer[0]=='T'||buffer[0]=='G'||buffer[0]=='C'||buffer[0]=='a'||buffer[0]=='t'||buffer[0]=='g'||buffer[0]=='c')   
                {
                        t=1;
			i++;
			ColNum = 0;
			atom = strtok(buffer, delims);
			
			atom = strtok(NULL, delims);
			RowNum += atoi(atom);
	                while (atom != NULL)
        	        {
                	        matrix[i][ColNum] = atoi(atom);
				atom = strtok(NULL, delims);
                        	ColNum++;
	                }
                }
        }	

        free (buffer);
	free (Matrix_temp);
	for (i=0;i<5;i++)
		free (matrix[i]);
	free (matrix);
}
/***********************************************************************/
void read_motif_consensus (FILE* fp)
{
	int consensus_num=0, i=0, j=0;
	char *buffer;
        buffer=(char*)malloc(sizeof(char)*MAX_MOTIF_LENGTH);
	/*get the alignment number*/
	while(fgets(buffer,MAX_MOTIF_LENGTH,fp)!=NULL)
        {
                if(buffer[0]=='>')
                        consensus_num++;
        }
	rewind(fp);
	while(fgets(buffer,MAX_MOTIF_LENGTH,fp)!=NULL)
	{
		if (buffer[0]=='>')
			printf ("%s",buffer);
		else
		{
			for (i=0;i<4;i++)
			{
				if (i==0)
				{
					printf ("A");
					for (j=0;j<strlen(buffer)-1;j++)
					{
						if (buffer[j]=='A') printf ("\t%d",12);
						else if (buffer[j]=='R') printf ("\t%d",6);
						else if (buffer[j]=='M') printf ("\t%d",6);
						else if (buffer[j]=='W') printf ("\t%d",6);
						else if (buffer[j]=='H') printf ("\t%d",4);
						else if (buffer[j]=='V') printf ("\t%d",4);
						else if (buffer[j]=='D') printf ("\t%d",4);
						else if (buffer[j]=='N') printf ("\t%d",3);
						else printf ("\t%d",0);
					}
					printf ("\n");
				}
				else if (i==2) 
				{
					printf ("C");
					for (j=0;j<strlen(buffer)-1;j++)
					{
						if (buffer[j]=='C') printf ("\t%d",12);
						else if (buffer[j]=='Y') printf ("\t%d",6);
						else if (buffer[j]=='M') printf ("\t%d",6);
						else if (buffer[j]=='S') printf ("\t%d",6);
						else if (buffer[j]=='H') printf ("\t%d",4);
						else if (buffer[j]=='B') printf ("\t%d",4);
						else if (buffer[j]=='V') printf ("\t%d",4);
						else if (buffer[j]=='N') printf ("\t%d",3);
						else printf ("\t%d",0);
					}
					printf ("\n");
				}
				else if (i==1) 
				{
					printf ("G");
					for (j=0;j<strlen(buffer)-1;j++)
					{
						if (buffer[j]=='G') printf ("\t%d",12);
						else if (buffer[j]=='R') printf ("\t%d",6);
						else if (buffer[j]=='K') printf ("\t%d",6);
						else if (buffer[j]=='S') printf ("\t%d",6);
						else if (buffer[j]=='V') printf ("\t%d",4);
						else if (buffer[j]=='B') printf ("\t%d",4);
						else if (buffer[j]=='D') printf ("\t%d",4);
						else if (buffer[j]=='N') printf ("\t%d",3);
						else printf ("\t%d",0);
					}
					printf ("\n");
				}
				else  
				{
					printf ("T");
					for (j=0;j<strlen(buffer)-1;j++)
					{
						if (buffer[j]=='T' || buffer[j]=='U') printf ("\t%d",12);
						else if (buffer[j]=='Y') printf ("\t%d",6);
						else if (buffer[j]=='K') printf ("\t%d",6);
						else if (buffer[j]=='W') printf ("\t%d",6);
						else if (buffer[j]=='H') printf ("\t%d",4);
						else if (buffer[j]=='B') printf ("\t%d",4);
						else if (buffer[j]=='D') printf ("\t%d",4);
						else if (buffer[j]=='N') printf ("\t%d",3);
						else printf ("\t%d",0);
					}
					printf ("\n");
				}
			}
		}
	}
	printf (">end\n");
}
/***********************************************************************/
void read_motif_alignment(FILE* fa )
/*read motif alignment file*/
{
    char *buffer;
    buffer=(char*)malloc(sizeof(char)*MAX_MOTIF_LENGTH);
    /*get the alignment number*/
    alignment_num = 0;
    while(fgets(buffer,MAX_MOTIF_LENGTH,fa)!=NULL)
    {
    	if(buffer[0]=='>')
        alignment_num++;
    }
    /* we need decrease the alignment_num by one because we have the last line >end*/
    alignment_num = alignment_num -1;
    AllocArray (Alignment, alignment_num);
    MotifAlignment *Alignment_temp;
    AllocVar (Alignment_temp);

    char **sequences_temp, name[MAX_MOTIF_NAME_LENGTH];
    int *clo_length, RowNum=0, number = 0, i=0,j=0,t=0;
    sequences_temp = alloc2c(MAX_PATTERN_NUM , MAX_MOTIF_LENGTH);
    AllocArray (clo_length, MAX_PATTERN_NUM);
    rewind(fa);

    while(fgets(buffer,MAX_MOTIF_LENGTH,fa)!=NULL)
    {
	if ((buffer[0]=='>')&&(t==0))
	{
  	    atom = strtok(buffer, delims);
	    strcpy(name, atom);
	    AllocVar (Alignment_temp);
	    AllocArray (Alignment_temp->motif_name,MAX_MOTIF_NAME_LENGTH);
	    RowNum = 0;
	    continue;
	}
	if ((buffer[0]=='>')&&(t==1))
	{
	    if (RowNum < 2)
		errAbort("Sorry, the motif alignment is not significant enough\n");
	    Alignment_temp->sequences = alloc2c (RowNum, MAX_MOTIF_LENGTH);
	    Alignment_temp->ColNum = clo_length[RowNum-1];
	    /*if (Alignment_temp->ColNum > s_col_min)
		errAbort ("\nSorry, some input sequences are too short to search current motif\n");*/
	    for (i=0; i<RowNum; i++)
	    {
		for (j=0; j<Alignment_temp->ColNum; j++)
	  	    Alignment_temp->sequences[i][j] = sequences_temp[i][j];
	    }
	    strcpy (Alignment_temp->motif_name, name);
	    Alignment_temp->RowNum = RowNum;	
	    	/*get the transition matrix for current alignment*/
	    Alignment_temp->transMatrix = getTransMatrix (Alignment_temp->sequences, Alignment_temp->RowNum);
	    	/* save current alignment to global **Alignment */
	    Alignment[number++] = Alignment_temp;
		
	    AllocVar (Alignment_temp);
	    AllocArray (Alignment_temp->motif_name,MAX_MOTIF_NAME_LENGTH);
	    atom = strtok(buffer, delims);
	    strcpy(name, atom);
	    RowNum = 0;
	    t=0;
	    continue;
	}
	/* case insensitive and adopt \n in each sequence */
	if(buffer[0]=='A'||buffer[0]=='T'||buffer[0]=='G'||buffer[0]=='C'||buffer[0]=='a'||buffer[0]=='t'||buffer[0]=='g'||buffer[0]=='c'||buffer[0]=='N'||buffer[0]=='n')
        {
            t=1;
            for (j=0;j<strlen(buffer)-1;j++)
        	sequences_temp[RowNum][j] = buffer[j];
	    clo_length[RowNum] = strlen(buffer)-1;
	    RowNum++;
        }
    }

    if (po->ChangeAlignment)
    {
	discrete **frequency;
	char *consensus;
	for (i=0; i<number; i++)
	{
 	    AllocArray (consensus, Alignment[i]->ColNum);
	    frequency = frequency_matrix (Alignment[i]->sequences, 5, Alignment[i]->ColNum, Alignment[i]->RowNum);
	    consensus = get_consensus (frequency, 5 , Alignment[i]->ColNum);
	    printf (">%s\t%s\n",Alignment[i]->motif_name,consensus);
	    for (j=1;j<5; j++)
	    {
		if (j==1) printf ("A");
	 	else if (j==2)	printf ("G");
		else if (j==3)	printf ("C");
		else 	printf ("T");
		for (t=0; t<Alignment[i]->ColNum; t++)
		    printf ("\t%d",frequency[j][t]);
		printf ("\n");
	    }
	}
	printf (">end");
	exit(1);
    }

    free (Alignment_temp);
    free (buffer);
    free (clo_length);
    for (i=0; i<MAX_PATTERN_NUM; i++)
	free (sequences_temp[i]);
    free (sequences_temp);
    fseek (fa,0,0);
}
/***********************************************************************/

