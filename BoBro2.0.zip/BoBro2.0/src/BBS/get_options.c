/************************************************************************/
/* Author: Qin Ma <maqin@csbl.bmb.uga.edu>, Feb. 16, 2010
 * Organize the parameters of Bregulon
 */

/***************************************************************************/ 

#include "get_options.h"

/***************************************************************************/ 
/* ./Bregulon or ./Bregulon -h will pop up the usage of Bregulon */
static const char USAGE[] = 
"===================================================================\n\
[Usage]\n\
$ ./BBS -i promoters -j aligned_motif  [argument list]\n\
===================================================================\n\
[Input]\n\
-i : input file must be standard fasta file format\n\
-j : input the motif alignment file\n\
-m : input the motif matrix file\n\
-p : input the motif consensus file\n\
-z : input the background genome (fasta format)\n\
===================================================================\n\
[Output]\n\
-S : the flag sorting the output closures with zscore, otherwise keep the\n\
     original order of seeds\n\
     defult: FALSE\n\
-C : the flag comparing the input motif\n\
     default: FALSE\n\
-s : the nunber of simulation times [5, ]\n\
     default: 5\n\
-c : the enlarge times of each seed's original size\n\
     default: 0 (output the real size of searched motif)\n\
-a : the flag to change alignment to matrix\n\
     default: FALSE\n\
-E : the flag of expansion of closures\n\
     default: FALSE\n\
-e : the initial motif alignment enlargment times [1,3]\n\
     default: 1\n\
-A : the flag of approximation of pvalue calculation\n\
     default: FALSE\n\
-t : the level of motif conservation (0,1)\n\
     default: 0.95\n\
-u : the level of motif conservation in background (0,1)\n\
     default: 0.95\n\
-n:  the filter of weak-conservered patterns (0,0.9]\n\
     default: 0.5\n\
-w:  the flag of two ends enhancer\n\
     default: TRUE\n\
-M:  the flag of considering Markov chain transition matrix for moitf alignment\n\
===================================================================\n";

/***************************************************************************/ 
/* we assign initial values to the parameters */
static void init_options ()
{
	/* default parameters */
	strcpy(po->FN, " ");
	strcpy(po->AN, " ");
	strcpy(po->MN, " ");
	strcpy(po->PN, " ");
	strcpy(po->ZN, " ");
	po->IsAlignment = FALSE;
	po->IsMatrix = FALSE;
	po->IsMarkov = FALSE;
	po->zscore = FALSE;
	po->output = FALSE;
	po->IsConsensus = FALSE;
	po->ToBeSearched = FALSE;
	po->IsCompare = FALSE;
    	po->FP = NULL;
	po->simu = 5;
	po->expansion = FALSE;
	po->approximate = FALSE;
	po->ChangeAlignment = FALSE;
	po->IsPrintSeed = TRUE;
	po->IsSorted = FALSE;
	po->twoendweight = TRUE;
	po->size = 0;
	po->closure_enlarge_times = 1;
	po->conserve_threshold = 0.95;
	po->conserve_background = .95;
	po->threshold_e2 = 0.5;
	po->range = 5;
}
/***************************************************************************/ 
/* arrange input parameters */
void get_options (int argc, char* argv[])
{
	int op;
	bool is_valid = TRUE;
        AllocVar(po);
	/* get default value of parameters */
        init_options();
        while ((op = getopt(argc, argv, "i:j:m:p:z:O:u:s:c:e:t:n:r:awEASCDMh")) >0)
	{
		switch (op)
		{
                        case 'i': strcpy(po->FN, optarg); po->ToBeSearched = TRUE; break;
			case 'j': strcpy(po->AN, optarg); po->IsAlignment = TRUE; break;
			case 'm': strcpy(po->MN, optarg); po->IsMatrix = TRUE; break;	  
			case 'p': strcpy(po->PN, optarg); po->IsConsensus = TRUE; break;	  
			case 'z': strcpy(po->ZN, optarg); po->zscore = TRUE; break;	  
			case 'O': strcpy(po->ON, optarg); po->output = TRUE; break;	  
		        case 'u': po->conserve_background = atof(optarg);break;
		        case 's': po->simu = atoi(optarg);break;
		        case 'c': po->size = atoi(optarg);break;
			case 'e': po->closure_enlarge_times = atoi(optarg); break;	  
			case 't': po->conserve_threshold = atof(optarg); break;	  
			case 'n': po->threshold_e2 = atof(optarg); break;	  
			case 'r': po->range = atoi(optarg); break;	  
			case 'a': po->ChangeAlignment = TRUE; break;
			case 'w': po->twoendweight = FALSE; break;
			case 'E': po->expansion = TRUE; break;
			case 'A': po->approximate = TRUE; break;
			case 'S': po->IsSorted = TRUE; break;
			case 'C': po->IsCompare = TRUE; break;
			case 'D': po->IsPrintSeed = FALSE; break;
			case 'M': po->IsMarkov = TRUE; break;
			case 'h': puts(USAGE); exit(0); 
			default : is_valid = FALSE;
		}
	}
	/* ./Bregulon will pop up the usage */
	if (argc==1) { puts(USAGE); exit(0);}
	/* read the input files  */
	if (po->IsAlignment) { 	po->FA = mustOpen(po->AN, "r");}
	if (po->ToBeSearched) { po->FP = mustOpen(po->FN, "r");}
	if (po->IsMatrix){ po->FM = mustOpen(po->MN, "r");}
	if (po->IsConsensus){ po->Fp = mustOpen(po->PN, "r");}
	if (po->zscore){ po->FZ = mustOpen(po->ZN, "r");}
	if (po->output) { po->FO = mustOpen(po->ON, "w");}
	if (po->IsMatrix && po->IsMarkov) 
	{
                err("-M can only be used when motif alignment is available");
                is_valid = FALSE;
	}
	if (po->IsConsensus && po->IsMarkov) 
	{
                err("-M can only be used when motif alignment is available");
                is_valid = FALSE;
	}
	if (po->simu<5)
        {
                err("-s number of simulation should be >=5");
                is_valid = FALSE;
        }
        if ( po->threshold_e2 < 0 || po->threshold_e2 > 1)
        {
                err("-n the value of n should be (0,1]");
                is_valid = FALSE;
	}
        if ( po->conserve_threshold < 0.3 || po->conserve_threshold > 1)
        {
		printf ("%f\n",po->conserve_threshold);
                err("-t the value of t should be [-n,1]");
                is_valid = FALSE;
	}
        if ( po->closure_enlarge_times < 1 || po->closure_enlarge_times > 3)
        {
                err("-e the value of e should be [1,3]");
                is_valid = FALSE;
	}
	if (!is_valid) errAbort("Type -h to view possible options");
}

/***************************************************************************/ 
