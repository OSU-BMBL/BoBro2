#ifndef _CLOSURE_PROCESS_H
#define _CLOSURE_PROCESS_H

#include "struct.h"
continuous **markov (char **sequences_r, int seq_num);
continuous **getTransMatrix(char **sequences, int seq_num);
continuous get_trans_score(char **sequences_2, char *seq_temp, int motif_number, int length_local_1);
continuous aver_score_closure(char **sequences_2, continuous **scoreM, continuous *score, int motif_number, int length_local_1);
continuous aver_score_closure_markov(char **sequences_2, continuous **scoreM, continuous *score, int motif_number, int length_local_1);
int motif_num_closure (Reference_genome *genome_1, int motif_length, continuous **scoreM, continuous thre);
continuous *motif_num_R_closure (Reference_genome *genome_1, int motif_length, continuous **scoreM, continuous thre);
continuous get_pvalue(Reference_genome *genome_1, int motif_num, continuous *motif_num_R);
int block_cmpr_g(const void *a, const void *b);
void sort_genomes_list(Reference_genome **el, int n);


/*from closure_process*/
extern continuous **get_profile (char **sequence_temp, int a, int b, int motif_number);
extern continuous **impovre_profle (continuous **scoreM, double  length_local_1);
extern discrete **frequency_matrix (char **sequence_temp, int a, int b, int motif_number);
    
/*from read_file*/
extern discrete *change_AGCT_to_num (char *seq, int length);
#endif
