/************************************************************************/
/* Author: Qin Ma <maqin@csbl.bmb.uga.edu>, Feb. 15, 2010
 * the functions related to printing output to specific files
 */

#include "write_file.h"
/*************************************************************************/
void print_params(FILE *fw1)
{
        fprintf(fw1, "#########################################\n#                                       #\n");
        fprintf(fw1, "#\tBBS version %.2f output\t\t#\n",VER);
        fprintf(fw1, "#                                       #\n#########################################\n");
	fprintf(fw1, "\n****************************************\n");
	fprintf(fw1, "INPUT DATA SUMMARY\n");
        fprintf(fw1, "****************************************\n");
        fprintf (fw1,"Input motif alignment: %s\n", po->AN);
	fprintf (fw1,"Input promoter dataset: %s\n",po->FN);
        fprintf(fw1,"Alphabet: A G C T\n");
        fprintf (fw1,"Promoter Sequence number: %d\nNucleotides number: %d\n",s_rows,sum_markov);
        fprintf (fw1,"Nucleotides composition in Promoter Sequences:\tA: %.2f   G: %.2f   C: %.2f   T: %.2f\n",p_markov[1][0],p_markov[2][0],p_markov[3][0],p_markov[4][0]);
	if (po->zscore)
	{
		fprintf (fw1,"Input Background Genome: %s\n",po->ZN);
	        fprintf (fw1,"Background Genome Nucleotides number: %ld\n\n",sum_genome);
	}

	int i=0;
	fprintf(fw1,"\nPromoter Sequence name\t\tLength\n");
        for (i=0;i<s_rows;i++)
        {
                fprintf (fw1,"%s\t\t%d\n",SequenceInfo[i],s_col[i]);
        }


        fprintf(fw1, "\n****************************************\n");
        fprintf(fw1, "COMMAND LINE SUMMARY\n");
        fprintf(fw1, "****************************************\n");

        fprintf(fw1, "\nParameters: -t %.2f -s %d -e %d -c %d -u %.2f -n %.2f", po->conserve_threshold, po->simu, po->closure_enlarge_times, po->size, po->conserve_background, po->threshold_e2);
	if (po->approximate) fprintf(fw1, "-A ");
	if (po->expansion) fprintf (fw1, "-E");
	fprintf(fw1, "\nMotif conservation level in promoter sequences (-t): %.2f\n",po->conserve_threshold);
	fprintf(fw1, "Simulation times in Pvalue framework (-s): %d\n", po->simu);
	fprintf(fw1, "Enlargement times for initial motif  (-e): %d\n", po->closure_enlarge_times);
	fprintf(fw1, "Enlarge degree base on initial motif (-c): %d\n", po->size);
	fprintf(fw1, "Motif conservation level in background (-u): %.2f\n", po->conserve_background);
	fprintf(fw1, "Threshold of weak-conservered patterns (-n): %.2f\n", po->threshold_e2);
	if (po->approximate)
		fprintf(fw1, "Approximation of pvalue calculation: On\n");
	if (po->expansion)
		fprintf(fw1, "Do further expansion of closures: On\n");
	if (po->IsSorted)
		fprintf(fw1,"Sort the output closures with zscore: On\n");
	if (po->IsCompare)
		fprintf(fw1,"Compare the input motifs: On\n");
	if (po->ChangeAlignment)
		fprintf(fw1, "Change input motif alignment to matrix: On\n");
}
/*************************************************************************/
void report_closures(FILE *fw, Closures** cc, int num)
{
	print_params(fw);
	/*fprintf (fw,"Input promoter dataset: %s\n",po->FN);
        fprintf (fw,"Input motif alignment data: %s\n", po->AN);
        fprintf (fw,"Promoter Sequence number: %d\nNucleotides number: %d\nBackground Genome Nucleotides number: %ld\n\n",s_rows,sum_markov,sum_genome);
        fprintf (fw,"Nucleotides composition:\tA: %.2f   G: %.2f   C: %.2f   T: %.2f\n",p_markov[1][0],p_markov[2][0],p_markov[3][0],p_markov[4][0]);*/
	/* sort the output closures with Pvalue in a increasing order*/
	if (po->IsSorted) sort_closures_list(cc, num);

        /*clean up the closures base on similarity scores*/
        int  ii=0, jj=0,kk=0;
        char **sequences_closures;
        /*num = MIN(num, po->RPT_BLOCK);*/
        while (ii< num )
        {
		if (cc[ii]->closure_rows == 0)
		{
			ii++;
			continue;
		}
		fprintf (fw,"\n\n*********************************************************\n");
                fprintf (fw," %s\n",cc[ii]->name);
	        fprintf (fw,"*********************************************************\n\n");
		fprintf (fw," Consensus: ");
		for (jj=0; jj<cc[ii]->length;jj++)
			fprintf (fw,"%c", cc[ii]->consensus[jj]);
		fprintf (fw, "\n");
        	fprintf (fw," Motif length: %d\n Binding sites number: %d\n Pvalue: %3.2e\n",cc[ii]->length, cc[ii]->closure_rows, cc[ii]->significance);
		if (po->zscore)
	        	fprintf (fw," Zscore: %.2f\n Enrichment: %.2f\n", cc[ii]->zscore, cc[ii]->enrich);
		/*print the matrix*/
                fprintf (fw, "\n ---------------Query position weight matrix:---------------\n");
		for (kk=0;kk<cc[ii]->length;kk++)
                        fprintf(fw,"\t%d",kk+1);
                fprintf (fw,"\n");

                fprintf (fw, " A");
		for (jj=0; jj<cc[ii]->length; jj++)
			fprintf (fw,"\t%d",cc[ii]->frequencyM[1][jj]);
                fprintf (fw, "\n G");
		for (jj=0; jj<cc[ii]->length; jj++)
                        fprintf (fw,"\t%d",cc[ii]->frequencyM[2][jj]);
                fprintf (fw, "\n C");
		for (jj=0; jj<cc[ii]->length; jj++)
                        fprintf (fw,"\t%d",cc[ii]->frequencyM[3][jj]);
                fprintf (fw, "\n T");
		for (jj=0; jj<cc[ii]->length; jj++)
                        fprintf (fw,"\t%d",cc[ii]->frequencyM[4][jj]);
		fprintf (fw, " \n");

                /*fprintf (fw, " A");
		for (jj=0; jj<cc[ii]->length; jj++)
			fprintf (fw,"\t%.2f",cc[ii]->scoreM[1][jj]);
                fprintf (fw, "\n G");
		for (jj=0; jj<cc[ii]->length; jj++)
                        fprintf (fw,"\t%.2f",cc[ii]->scoreM[2][jj]);
                fprintf (fw, "\n C");
		for (jj=0; jj<cc[ii]->length; jj++)
                        fprintf (fw,"\t%.2f",cc[ii]->scoreM[3][jj]);
                fprintf (fw, "\n T");
		for (jj=0; jj<cc[ii]->length; jj++)
                        fprintf (fw,"\t%.2f",cc[ii]->scoreM[4][jj]);
		fprintf (fw, " \n");*/

		fprintf (fw," IC");
                continuous temp_motif_num=0, temp_ic=0;
                for (jj=1;jj<5;jj++)
                        temp_motif_num+=cc[ii]->frequencyM[jj][1];
                for (kk=0;kk<cc[ii]->length;kk++)
                {
                        temp_ic=0;
                        for (jj=1;jj<5;jj++)
                                temp_ic+=(cc[ii]->frequencyM[jj][kk]/temp_motif_num)*cc[ii]->scoreM[jj][kk];
			fprintf (fw,"\t%.2f",temp_ic);
                }
                fprintf (fw, "\n");


		fprintf (fw,"\n----- Searched binding sites  of current Motif ------\n");
	        fprintf (fw,"#Motif\tSeq\tStart\tMotif\t\tEnd\tScore\tInfo\n");
	
        	sequences_closures = alloc2c(cc[ii]->closure_rows,cc[ii]->length);
	        for (jj=0; jj<cc[ii]->closure_rows; jj++)
        	{
                        int kkk=0;
			double positive=0, negative=0;
			/*check whether positive or negative*/
	                for (kk=dsItem(cc[ii]->position,jj); kk< (dsItem(cc[ii]->position,jj)+cc[ii]->length); kk++)
        	        {
                                if (sequences[dsItem(cc[ii]->sequence,jj)][kk] == 'A' || sequences[dsItem(cc[ii]->sequence,jj)][kk] == 'a')
				{
					positive += cc[ii]->frequencyM[1][kkk]; 
					negative += cc[ii]->frequencyM[4][cc[ii]->length-kkk-1];
				}
				else if (sequences[dsItem(cc[ii]->sequence,jj)][kk] == 'T' || sequences[dsItem(cc[ii]->sequence,jj)][kk] == 't')
				{
					positive += cc[ii]->frequencyM[4][kkk]; 
					negative += cc[ii]->frequencyM[1][cc[ii]->length-kkk-1];
				}
				else if (sequences[dsItem(cc[ii]->sequence,jj)][kk] == 'G' || sequences[dsItem(cc[ii]->sequence,jj)][kk] == 'g')
				{
					positive += cc[ii]->frequencyM[2][kkk]; 
					negative += cc[ii]->frequencyM[3][cc[ii]->length-kkk-1];
				}
				else
				{
					positive += cc[ii]->frequencyM[3][kkk]; 
					negative += cc[ii]->frequencyM[2][cc[ii]->length-kkk-1];
				}
				kkk++;
        	        }
			/*printf ("positive\t%.2f\nnegative\t%.2f\n", positive, negative);	*/
			
			kkk=0;
			if (positive >= negative)
                		fprintf (fw,">%s\t%d\t%d\t",cc[ii]->name,dsItem(cc[ii]->sequence,jj)+1,dsItem(cc[ii]->position,jj)+1);
			else
                		fprintf (fw,">%s\t%d\t%d\t",cc[ii]->name,dsItem(cc[ii]->sequence,jj)+1,dsItem(cc[ii]->position,jj)+cc[ii]->length);

	                for (kk=dsItem(cc[ii]->position,jj); kk< (dsItem(cc[ii]->position,jj)+cc[ii]->length); kk++)
        	        {
				if(positive >= negative)
                                {
					fprintf (fw,"%c",sequences[dsItem(cc[ii]->sequence,jj)][kk]);
                	        	sequences_closures[jj][kkk] = sequences[dsItem(cc[ii]->sequence,jj)][kk];
				}
				else
				{
					int temp_posi = (dsItem(cc[ii]->position,jj)+cc[ii]->length); 
                                	if (sequences[dsItem(cc[ii]->sequence,jj)][temp_posi-kkk-1] == 'A' || sequences[dsItem(cc[ii]->sequence,jj)][temp_posi-kkk-1] == 'a')
						fprintf (fw,"T");
					else if (sequences[dsItem(cc[ii]->sequence,jj)][temp_posi-kkk-1] == 'T' || sequences[dsItem(cc[ii]->sequence,jj)][temp_posi-kkk-1] == 't')
						fprintf (fw,"A");
					else if (sequences[dsItem(cc[ii]->sequence,jj)][temp_posi-kkk-1] == 'G' || sequences[dsItem(cc[ii]->sequence,jj)][temp_posi-kkk-1] == 'g')
						fprintf (fw,"C");
					else
						fprintf (fw,"G");
                	        	sequences_closures[jj][kkk] = sequences[dsItem(cc[ii]->sequence,jj)][temp_posi-kkk-1];
				
				}
	                       	kkk++;
        	        }
			if (positive >= negative)
				fprintf (fw,"\t%d",dsItem(cc[ii]->position,jj)+cc[ii]->length);
			else
				fprintf (fw,"\t%d",dsItem(cc[ii]->position,jj)+1);
                        fprintf (fw,"\t%.2f\t",cc[ii]->score[jj]);
                	fprintf (fw,"%s",SequenceInfo[dsItem(cc[ii]->sequence,jj)]);
                	fprintf (fw,"\n");
			if (jj==(cc[ii]->closure_rows_seed-1) && (cc[ii]->closure_rows_seed < cc[ii]->closure_rows))
			{
				fprintf (fw," --------------------------------------------------\n");
				fprintf (fw, " Above %d convinced motif patterns correspond to Pvalue %3.2e\n", cc[ii]->closure_rows_seed, cc[ii]->significance_seed);
				fprintf (fw," --------------------------------------------------\n");
				if (!po->IsPrintSeed)
				{
					break;
				}
			}
                }
		if (cc[ii]->closure_rows_seed == cc[ii]->closure_rows)
		{
			fprintf (fw," ----------------------------------------------------\n");
			fprintf (fw, " Above %d convinced motif patterns correspond to the best Pvalue %3.2e\n", cc[ii]->closure_rows, cc[ii]->significance);
        	        fprintf (fw," ----------------------------------------------------\n");
		}
		else
		{
			if (po->IsPrintSeed)
			{
				fprintf (fw," ----------------------------------------------------\n");
				fprintf (fw, " Above %d motif patterns correspond to the best Pvalue %3.2e\n", cc[ii]->closure_rows, cc[ii]->significance);
                		fprintf (fw," ----------------------------------------------------\n");
			}
		}
                ii++;
        }
	fclose(fw);
}

/************************************************************************/
int block_cmpr_1(const void *a, const void *b)
/*compare function for qsort, decreasing by score*/
{
        return ((*(Closures **)b)->zvalue - (*(Closures **)a)->zvalue);
}

void sort_closures_list(Closures **el, int n)
{
        qsort(el, n, sizeof *el, block_cmpr_1);
}
/************************************************************************/
int block_cmpr_oper(const void *a, const void *b)
/*compare function for qsort, decreasing by score*/
{
        return ((*(Block **)b)->oper_num - (*(Block **)a)->oper_num);
}

void sort_block_list_oper(Block **el, int n)
{
        qsort(el, n, sizeof *el, block_cmpr_oper);
}
/************************************************************************/
