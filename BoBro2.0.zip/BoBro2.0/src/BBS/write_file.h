#ifndef _WRITE_FILE_H
#define _WRITE_FILE_H

#include "struct.h"

/*prototypes*/
void print_params(FILE *fw1);
void report_closures(FILE *fw, Closures **cc, int num_cc);
void sort_closures_list(Closures **el, int n);
int block_cmpr_1(const void *a, const void *b);
#endif


