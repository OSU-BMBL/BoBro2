/************************************************************************/
/* Author: Qin Ma <maqin@csbl.bmb.uga.edu>, Feb. 16, 2010
 * all the functions realted to calculate pvalue
 */
#include "pvalue.h"

/***********************************************************************************/
continuous **markov (char **sequences_r, int seq_num)
{
    size_t i, j, flag_markov=0, length_temp = strlen(sequences_r[0]);
    continuous **markov;

    markov= alloc2dd (5,5);
    sum_markov=0;
    for (i=0;i<5;i++)
    	for (j=0;j<5;j++)
            markov[i][j]=0;

    for (i=0;i<seq_num;i++)
    {
 	/*strlen() return a size_t format so if we compare it with int (for (j=1;j<strlen(sequences_r[i]);j++)), there will be segemental fault
	 * here we set strlen(sequences_r[0]) to a int and do the following steps*/
	length_temp = strlen(sequences_r[i]);
	for (j=1;j<length_temp;j++)
        {
            sum_markov++;
            if (sequences_r[i][j-1]=='A' || sequences_r[i][j-1]=='a') flag_markov=1;
            else if (sequences_r[i][j-1]=='G' || sequences_r[i][j-1]=='g') flag_markov=2;
            else if (sequences_r[i][j-1]=='C' || sequences_r[i][j-1]=='c') flag_markov=3;
            else if (sequences_r[i][j-1]=='T' || sequences_r[i][j-1]=='t') flag_markov=4;
            markov[flag_markov][0]++;
	    if (sequences_r[i][j]=='A' || sequences_r[i][j]=='a') markov[flag_markov][1]++;
            else if (sequences_r[i][j]=='G'||sequences_r[i][j]=='g') markov[flag_markov][2]++;
            else if (sequences_r[i][j]=='C'||sequences_r[i][j]=='c') markov[flag_markov][3]++;
            else if (sequences_r[i][j]=='T'||sequences_r[i][j]=='t') markov[flag_markov][4]++;
        }
    }
    for (i=1;i<5;i++)
    	for (j=1;j<5;j++)
            markov[i][j]=markov[i][j]/markov[i][0];
    for (i=0;i<seq_num;i++)
    {
    	length_temp = strlen(sequences_r[i]);
	if (sequences_r[i][length_temp-1]=='A' || sequences_r[i][length_temp-1]=='a') flag_markov=1;
        else if (sequences_r[i][length_temp-1]=='G' || sequences_r[i][length_temp-1]=='g') flag_markov=2;
        else if (sequences_r[i][length_temp-1]=='C' || sequences_r[i][length_temp-1]=='c') flag_markov=3;
        else if (sequences_r[i][length_temp-1]=='T' || sequences_r[i][length_temp-1]=='t') flag_markov=4;
	markov[flag_markov][0]++;
        sum_markov++;
    }
    for (i=1;i<5;i++)
    	markov[i][0]=markov[i][0]/sum_markov;
    return markov;
}

/***********************************************************************************/
/*generate the transition matrix for given motif alignment*/
continuous **getTransMatrix(char **sequences, int seq_num)
{
    size_t i, j, k, l, flag_trans=0, length_temp = strlen(sequences[0]);
    continuous **trans, **transMatrix;

    trans= alloc2dd (5,5);
    transMatrix= alloc2dd (16,length_temp-1);

    for (i=0;i<5;i++)
    	for (j=0;j<5;j++)
            trans[i][j]=0;
    
    for (i=0;i<16;i++)
    	for (j=0;j<length_temp-1;j++)
            transMatrix[i][j]=0;

    for (j=1;j<length_temp;j++)
    {
    	
	for (k=0;k<5;k++)
    	    for (l=0;l<5;l++)
            	trans[k][l]=0;

        for (i=0;i<seq_num;i++)
        {
            if (sequences[i][j-1]=='A' || sequences[i][j-1]=='a') flag_trans=1;
            else if (sequences[i][j-1]=='G' || sequences[i][j-1]=='g') flag_trans=2;
            else if (sequences[i][j-1]=='C' || sequences[i][j-1]=='c') flag_trans=3;
            else if (sequences[i][j-1]=='T' || sequences[i][j-1]=='t') flag_trans=4;
            trans[flag_trans][0]++;
	    if (sequences[i][j]=='A' || sequences[i][j]=='a') trans[flag_trans][1]++;
            else if (sequences[i][j]=='G'||sequences[i][j]=='g') trans[flag_trans][2]++;
            else if (sequences[i][j]=='C'||sequences[i][j]=='c') trans[flag_trans][3]++;
            else if (sequences[i][j]=='T'||sequences[i][j]=='t') trans[flag_trans][4]++;
        }

    	for (k=1;k<5;k++)
    	    for (l=1;l<5;l++)
	        transMatrix[(4*(k-1)+l-1)][j-1] = trans[k][l];
    }
    /*for (k=0;k<16;k++)
    {
	for (l=0;l<length_temp-1;l++)
	{
	    printf ("%.2f\t", transMatrix[k][l]);
	}
	printf ("\n");  
    }*/
    for (i=0; i<5; i++)
	free (trans[i]);
    free(trans);
    return transMatrix;
}
/***********************************************************************************/
continuous aver_score_closure(char **sequences_2, continuous **scoreM, continuous *score, int motif_number, int length_local_1)
{
    int i,j;	
    continuous AveScore=0;
	
    for (i=0;i<motif_number;i++)
    {
       	score[i]=0;
        for (j=0;j<length_local_1;j++)
	{     	
	    if (sequences_2[i][j]=='A' || sequences_2[i][j]=='a') score[i]=score[i]+scoreM[1][j];
	    else if (sequences_2[i][j]=='G' || sequences_2[i][j]=='g') score[i]=score[i]+scoreM[2][j];
	    else if (sequences_2[i][j]=='C' || sequences_2[i][j]=='c') score[i]=score[i]+scoreM[3][j];
	    else if (sequences_2[i][j]=='T' || sequences_2[i][j]=='t') score[i]=score[i]+scoreM[4][j];
        }
	AveScore = AveScore + score[i];
    }
    AveScore = AveScore / motif_number;		
    return AveScore;
}	
/***********************************************************************************/
continuous aver_score_closure_markov(char **sequences_2, continuous **scoreM, continuous *score, int motif_number, int length_local_1)
{
    int i,j;	
    continuous AveScore=0, **transM;
    discrete **matrix, **frequency;
    
    matrix = alloc2d (motif_number,length_local_1);
    frequency = frequency_matrix (sequences_2, 5, length_local_1, motif_number);
    transM = getTransMatrix (sequences_2, motif_number);
    
    for (i=0;i<motif_number;i++)
        for (j=0;j<length_local_1;j++)
	    matrix[i][j] = 0;

    for (i=0;i<motif_number;i++)
        for (j=0;j<length_local_1;j++)
	{     	
	    if (sequences_2[i][j]=='G' || sequences_2[i][j]=='g') matrix[i][j] = 1; 
	    else if (sequences_2[i][j]=='C' || sequences_2[i][j]=='c') matrix[i][j] = 2; 
	    else if (sequences_2[i][j]=='T' || sequences_2[i][j]=='t') matrix[i][j] = 3; 
        }
	
    for (i=0;i<motif_number;i++)
    {
       	score[i]=0;
        for (j=0;j<length_local_1;j++)
	    score[i] += scoreM[matrix[i][j]+1][j];

        for (j=0;j<length_local_1-1;j++)
	    score[i] += log2((transM[(4*matrix[i][j]+matrix[i][j+1])][j]+p_markov[matrix[i][j]+1][matrix[i][j+1]+1])/(p_markov[matrix[i][j]+1][matrix[i][j+1]+1]*(frequency[matrix[i][j]+1][j]+1)));

	AveScore = AveScore + score[i];
    }
    AveScore = AveScore / motif_number;		
    return AveScore;
}

/***********************************************************************************/
continuous get_trans_score(char **sequences_2, char *seq_temp, int motif_number, int length_local_1)
{
    int j;	
    continuous **transM, transS=0;
    discrete *array, **frequency;
    
    frequency = frequency_matrix (sequences_2, 5, length_local_1, motif_number);
    transM = getTransMatrix (sequences_2, motif_number);
    array = change_AGCT_to_num(seq_temp, length_local_1);
    
    for (j=0;j<length_local_1-1;j++)
        transS += log2((transM[(4*array[j]+array[j+1])][j]+p_markov[array[j]+1][array[j+1]+1])/(p_markov[array[j]+1][array[j+1]+1]*(frequency[array[j]+1][j]+1)));

    for (j=0;j<5;j++)
	free (frequency[j]);
    free (frequency);
    for (j=0; j<16; j++)
	free (transM[j]);
    free (transM);
    free (array); 

    return transS;
}

/***********************************************************************************/
int motif_num_closure (Reference_genome *genome_1, int motif_length, continuous **scoreM, continuous thre)
{
	int i, j, k, motif_number=0;
	continuous score_scan=0;
        for (i=0;i<genome_1->seq_num;i++)
	{	
		for (j=0;j< (genome_1->clo_num[i])-motif_length+1;j++)
                {
	                score_scan=0;
                        for (k=0;k<motif_length;k++)
                        {
                       		if (genome_1->sequences_r[i][k+j]=='A' || genome_1->sequences_r[i][k+j]=='a')
                                	score_scan = score_scan + scoreM[1][k];
                                if (genome_1->sequences_r[i][k+j]=='G' || genome_1->sequences_r[i][k+j]=='g')
                                	score_scan = score_scan + scoreM[2][k];
                                if (genome_1->sequences_r[i][k+j]=='C' || genome_1->sequences_r[i][k+j]=='c')
                                	score_scan = score_scan + scoreM[3][k];
                                if (genome_1->sequences_r[i][k+j]=='T' || genome_1->sequences_r[i][k+j]=='t')
                                	score_scan = score_scan + scoreM[4][k];
                        }
                        if (score_scan>thre && motif_number < CLOSURE_SIZE-10)
                                        motif_number++;
		}
	}
	return motif_number;
}
/***********************************************************************************/
continuous *motif_num_R_closure (Reference_genome *genome_1, int motif_length, continuous **scoreM, continuous thre)
{
	int i,j,k,length_ave=0,numberfore=1,randomNum,simulation=po->simu,Rt,num_all_R=0;
        continuous length_ave_1=0, score_scan, pp[5], motif_num_R_temp=0, *motif_num_R;
        char *randomdata;

	AllocArray (motif_num_R,2);
	motif_num_R[0] = motif_num_R[1] =0;
	for (i=0;i<genome_1->seq_num;i++)
                length_ave_1=length_ave_1+genome_1->clo_num[i];
        length_ave=ceil(length_ave_1/genome_1->seq_num);
        AllocArray (randomdata,length_ave);

        srand((unsigned)time(NULL));
        for (Rt=0;Rt<30*simulation;Rt++)
	{
                for (i=0;i<4;i++)
                {
                        for(j=0;j<length_ave;j++)
                        {
                                num_all_R++;
                                for (k=1;k<5;k++)
                                        pp[k]=genome_1->markov_matrix[numberfore][k];
                                randomNum=rand()%100;
                                if (randomNum<pp[1]*100) {randomdata[j]='A';numberfore=1;}
                                else if (randomNum<(pp[1]+pp[2])*100) {randomdata[j]='G';numberfore=2;}
                                else if (randomNum<(pp[1]+pp[2]+pp[3])*100) {randomdata[j]='C';numberfore=3;}
                                else {randomdata[j]='T';numberfore=4;}
                        }
                        for(j=0;j<length_ave-motif_length+1;j++)
                        {
                                score_scan=0;
                                for (k=0;k<motif_length;k++)
                                {
                                        if (randomdata[k+j]=='A' || randomdata[k+j]=='a')
                                                score_scan=score_scan+scoreM[1][k];
                                        else if (randomdata[k+j]=='G' || randomdata[k+j]=='g')
                                                score_scan=score_scan+scoreM[2][k];
                                        else if (randomdata[k+j]=='C' || randomdata[k+j]=='c')
                                                score_scan=score_scan+scoreM[3][k];
                                        else if (randomdata[k+j]=='T' || randomdata[k+j]=='t')
                                                score_scan=score_scan+scoreM[4][k];
                                }
                                if (score_scan>thre)
                                	motif_num_R_temp++;
                        }
                }
	}
	if (motif_num_R_temp == 0) motif_num_R_temp++;
	motif_num_R[0] = (motif_num_R_temp*genome_1->seq_num)/(4*(Rt));
	motif_num_R[1] = (4*(Rt))/(motif_num_R_temp*genome_1->seq_num);
	/*free(randomdata);*/
	return motif_num_R;
}

/***********************************************************************************/
continuous get_pvalue(Reference_genome *genome_1, int motif_num, continuous *motif_num_R)
{
	int i,j;
	continuous poisson,one_tmp=1,pvalue;
	pvalue=0;
        while (motif_num_R[0] >600)
	{
		motif_num_R[0] = motif_num_R[0]/2;
		motif_num = motif_num/2;
	}
	poisson=one_tmp/exp(motif_num_R[0]);
	if (po->approximate) j=1;
	else j=300;
        for (i=0;i<(int)(motif_num)+j;i++)
        {
        	if (i>(int)(motif_num)-1) pvalue=pvalue+poisson;
                poisson=poisson*motif_num_R[0]/(i+1);
	}
	return pvalue;
}
/***********************************************************************************/
int block_cmpr_g(const void *a, const void *b)
/*compare function for qsort, decreasing by score*/
{
        return ((*(Reference_genome **)b)->score - (*(Reference_genome **)a)->score);
}

void sort_genomes_list(Reference_genome **el, int n)
{
        qsort(el, n, sizeof *el, block_cmpr_g);
}

/************************************************************************************/
