/************************************************************************/
/* Author: Qin Ma <maqin@csbl.bmb.uga.edu>, Feb. 16, 2010
 * all the functions realted to calculate pvalue
 */
#include "pvalue.h"

/***********************************************************************************/
continuous **markov (char **sequences_r, int seq_num)
{
	int i,j;
	continuous **markov;
	markov= alloc2dd (5,5);
        for (i=0;i<5;i++)
                for (j=0;j<5;j++)
                        markov[i][j]=0;
        int flag_markov=0;
        sum_markov=0;
	int length_temp = strlen(sequences_r[0]);
        for (i=0;i<seq_num;i++)
	{
		if (strlen(sequences_r[i]) == 0) continue;
		/*strlen() return a size_t format so if we compare it with int (for (j=1;j<strlen(sequences_r[i]);j++)), there will be segemental fault
		 * here we set strlen(sequences_r[0]) to a int and do the following steps*/
		length_temp = strlen(sequences_r[i]);
		/*printf ("%Zu\t%d\n",strlen(sequences_r[i]),length_temp);*/
		for (j=1;j<length_temp;j++)
                {
                        sum_markov++;
                        if (sequences_r[i][j-1]=='A' || sequences_r[i][j-1]=='a') flag_markov=1;
                        else if (sequences_r[i][j-1]=='G' || sequences_r[i][j-1]=='g') flag_markov=2;
                        else if (sequences_r[i][j-1]=='C' || sequences_r[i][j-1]=='c') flag_markov=3;
                        else if (sequences_r[i][j-1]=='T' || sequences_r[i][j-1]=='t') flag_markov=4;
                        markov[flag_markov][0]++;
			if (sequences_r[i][j]=='A' || sequences_r[i][j]=='a') markov[flag_markov][1]++;
                        else if (sequences_r[i][j]=='G'||sequences_r[i][j]=='g') markov[flag_markov][2]++;
                        else if (sequences_r[i][j]=='C'||sequences_r[i][j]=='c') markov[flag_markov][3]++;
                        else if (sequences_r[i][j]=='T'||sequences_r[i][j]=='t') markov[flag_markov][4]++;
                }
	}
        for (i=1;i<5;i++)
                for (j=1;j<5;j++)
                        markov[i][j]=markov[i][j]/markov[i][0];
        for (i=0;i<seq_num;i++)
        {
                if (strlen(sequences_r[i]) == 0) continue;
		length_temp = strlen(sequences_r[i]);
		if (sequences_r[i][length_temp-1]=='A' || sequences_r[i][length_temp-1]=='a') flag_markov=1;
                else if (sequences_r[i][length_temp-1]=='G' || sequences_r[i][length_temp-1]=='g') flag_markov=2;
                else if (sequences_r[i][length_temp-1]=='C' || sequences_r[i][length_temp-1]=='c') flag_markov=3;
                else if (sequences_r[i][length_temp-1]=='T' || sequences_r[i][length_temp-1]=='t') flag_markov=4;
		markov[flag_markov][0]++;
                sum_markov++;
        }
        for (i=1;i<5;i++)
                markov[i][0]=markov[i][0]/sum_markov;
	return markov;
}

/***********************************************************************************/
