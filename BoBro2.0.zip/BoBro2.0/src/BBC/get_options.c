/************************************************************************/
/* Author: Qin Ma <maqin@csbl.bmb.uga.edu>, Feb. 16, 2010
 * Organize the parameters of ClosureCombine
 */

/***************************************************************************/ 

#include "get_options.h"

/***************************************************************************/ 
/* ./ClosureCombine or ./ClosureCombine -h will pop up the usage of ClosureCombine */
static const char USAGE[] = 
"===================================================================\n\
[Usage]\n\
$ ./ClosureCombine -r closures -g reference_genome [argument list]\n\
===================================================================\n\
[Input]\n\
-r : input file must be standard .closures format which is BOBRO's output format\n\
-g : input file contain the reference promoters for input closures\n\
===================================================================\n\
[Output]\n\
-o : number of combined closures to report (used under a specific input length)\n\
     default: 10\n\
-z : the cutoff of similarity socre between a pair of combined closures\n\
     default: 0.8\n\
-E : the flag to consider the evolustion information\n\
     default: FALSE\n\
===================================================================\n";

/***************************************************************************/ 
/* we assign initial values to the parameters */
static void init_options ()
{
	/* default parameters */
	strcpy(po->CN, " ");
	strcpy(po->GN, " ");
	po->RPT_BLOCK = 10;
	po->SCH_BLOCK = 200;
	po->IS_closure = FALSE;
	po->IS_reference = FALSE;
	po->PvalueInfluence = FALSE;
	po->TopEdges = 1;
	po->expansion = FALSE;
	po->thre = 0.8;
}
/***************************************************************************/ 
/* arrange input parameters */
void get_options (int argc, char* argv[])
{
	int op;
	bool is_valid = TRUE;
        AllocVar(po);
	/* get default value of parameters */
        init_options();
        while ((op = getopt(argc, argv, "r:g:o:z:T:Eh")) >0)
	{
		switch (op)
		{
			case 'r': strcpy(po->CN, optarg); po->IS_closure = TRUE; break;
			case 'g': strcpy(po->GN, optarg);  po->IS_reference = TRUE;break;	  
			case 'o':
				  po->RPT_BLOCK = atoi(optarg); 
			          po->SCH_BLOCK = 10 * po->RPT_BLOCK; break;
			case 'z': po->thre = atof(optarg); break;	 
			case 'T': po->TopEdges = atoi(optarg); break; 
			case 'E': po->expansion = TRUE; break;
			case 'h': puts(USAGE); exit(0); 
			default : is_valid = FALSE;
		}
	}
	/* ./ClosureCombine will pop up the usage */
	if (argc==1) { puts(USAGE); exit(0);}
	/* read the input files  */
	if (po->IS_closure)  po->FC = mustOpen(po->CN, "r");
	if (po->IS_reference) po->FG = mustOpen(po->GN, "r");
	/* option value range check */
        if (po->RPT_BLOCK <= 0)
	{
		err("-o number of blocks to report should be >0");
		is_valid = FALSE;
	}
	if (po->thre <0 || po->thre >1)
	{
		err("-z the similarity between closures should be [0,1]");
		is_valid = FALSE;
	}
	if (!is_valid) errAbort("Type -h to view possible options");
}

/***************************************************************************/ 
