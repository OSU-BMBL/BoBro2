/************************************************************************/
/* Author: Qin Ma <maqin@csbl.bmb.uga.edu>, Feb. 16, 2010
 * read all kinds of input files	
 */

#include "read_file.h"
#define MAXC 100000
#define MAX_SEQUENCE_LENGTH 1000
#define MAX_PROMOTER_NUM 200

static int bb[USHRT_MAX];
static char delims[] = " _>\t\r\n";
static char *atom = NULL;
/***********************************************************************/
/*read the .closures file output by BoBro*/
void read_closures (FILE* fc)
{
	char *buffer;
	double significance=0;
        int i=0,j;
        /*get the number of closures*/
        clo_num=0;
        buffer=(char*)malloc(sizeof(char)*MAXC);
        while(fgets(buffer,MAXC,fc)!=NULL)
                if (buffer[0] == '#')  clo_num++;
        /* we need minus the first five head lines with # at the begining in .closures file */
	clo_num = clo_num-5;
	/* pop up the real number of candidate closures in input .closures file */
        printf ("There are %d candidate closures\n",clo_num);
	AllocArray (IsClosuresSeed,clo_num);
	for (i=0; i<clo_num; i++)
		IsClosuresSeed[i]=FALSE;

        AllocArray(all, clo_num);
        AllocArray(IsCoverTarget, clo_num);
	for (i=0; i<clo_num; i++)
		IsCoverTarget[i] = FALSE;
	/* set the indicator to the begining of the file and skip the first five header rows*/
        rewind(fc);
        for (i=0;i<5;i++)
		fgets(buffer,MAXC,fc);
        discrete *clo_row;
        AllocArray(clo_row, clo_num);
        /*count the number of motif (TFBS) in each closure which are saved in *clo_row*/
        i=0;
        int i_1=0;
        while(fgets(buffer,MAXC,fc)!=NULL)
        {
                if (buffer[0] == '#')
                {
                        j=0;
                        while(fgets(buffer,MAXC,fc)!=NULL)
                        {
                                if (buffer[0] == '-') break;
                                else  j++;
                        }
                        clo_row[i] = j;
                        i++;
                }
		if (buffer[0] == 'D' && buffer[1] == 'a')  i_1++;
        }
        /*read the information of each closure*/
        rewind(fc);
        for (i=0;i<5;i++)
                fgets(buffer,MAXC,fc);
        i=0;
	char *oper_name;
	AllocArray (oper_name,20);
	continuous *position;
        Closures *cctemp;
       	continuous position_ave = 0 , position_var = 0;
        while(fgets(buffer,MAXC,fc)!=NULL)
        {
		if (buffer[0] == 'D' && buffer[1] == 'a')
		{
			AllocArray (oper_name,20);
			atom = strtok(buffer, delims);
			atom = strtok(NULL, delims);
			strcpy(oper_name, atom);	
		}
		/*read in the pvalue of each closure*/
		if (buffer[0] == ' ' && buffer[7] == 'P')
		{
			atom = strtok(buffer, delims);
			atom = strtok(NULL, delims);
			atom = strtok(NULL, delims);
			significance = atof(atom);
		}
		if (buffer[0] == '#')
                {
                        AllocVar(cctemp);
                        int temp = clo_row[i];
                        cctemp->sequence = dsNew(temp);
                        cctemp->position = dsNew(temp);
			AllocArray (position,temp);
                        j=0;
			while(fgets(buffer,MAXC,fc)!=NULL)
                        {
                                if (buffer[0] == '-') break;
                                else
                                {
					/*we update atoi(atom) to atoi(atom)-1 because we count from 1 
					 * in current version of BoBro output*/
                                        atom = strtok(buffer, delims);
					if (atoi(atom)==1)
						IsCoverTarget[i] = TRUE;
                                        dsPush(cctemp->sequence,atoi(atom)-1);
                                        atom = strtok(NULL, delims);
                                        dsPush(cctemp->position,atoi(atom)-1);
					position[j] = atof(atom)-1;
					/*if (atoi(atom)==0)
						IsCoverTarget[i] = TRUE;
                                        dsPush(cctemp->sequence,atoi(atom));
                                        atom = strtok(NULL, delims);
                                        dsPush(cctemp->position,atoi(atom));
					position[j] = atof(atom);*/


                                        atom = strtok(NULL, delims);
					cctemp->length = strlen (atom);
                                        j++;
                                }
                        }
			position_ave = get_average_from_array(position, j);
			position_var = get_variance_from_array(position, position_ave, j);
			cctemp->posi_var = position_var/100;
			AllocArray (cctemp->name,20);
			strcpy(cctemp->name,oper_name);
			cctemp->significance = significance;
                        cctemp->closure_rows = j;
			/* save current closure's information to global **all */
                        all[i] = cctemp;
                        i++;
                }
        }
}
/***********************************************************************/
/*read a combined file containing reference genomes for all the confirmed operons*/
void read_reference_genome (FILE* fp)
{
	char *buffer;
	buffer=(char*)malloc(sizeof(char)*MAX_SEQUENCE_LENGTH);
	int oper_num = 0;
	int  promo_num=0, t, k,i,j;
	/* count the number of operons */
	while(fgets(buffer,MAX_SEQUENCE_LENGTH,fp)!=NULL)
                if ((buffer[0]=='>')&&(buffer[1]=='>')) oper_num++;
        printf ("There are %d sets of reference promoters\n",oper_num-1);
	/* we minus the last >>end from the counter */	
	reference_oper_num = oper_num-1;
	AllocArray (genome,(oper_num-1));
	oper_num_all = oper_num-1;
	Reference_genome *genome_temp;
	AllocVar (genome_temp);
	oper_num=0;

	char **sequences_temp;
	char **species;
	int *clo_length;
	char name[20];
	sequences_temp = alloc2c(MAX_PROMOTER_NUM , MAX_SEQUENCE_LENGTH);
	species = alloc2c(MAX_PROMOTER_NUM , MAX_SEQUENCE_LENGTH);
	AllocArray (clo_length, MAX_PROMOTER_NUM);
	rewind(fp);
	t=0,k=0;
	while(fgets(buffer,MAX_SEQUENCE_LENGTH,fp)!=NULL)
	{
		if ((buffer[0]=='>')&&(buffer[1]=='>')&& (t==0))
		{
			atom = strtok(buffer, delims);
  			strcpy(name, atom);
			AllocVar (genome_temp);
			AllocArray (genome_temp->oper_name, 20);
			promo_num = 0;
			continue;
		}
		if ((buffer[0]=='>')&&(buffer[1]=='>')&&(t==1))
		{
			genome_temp->sequences_r = alloc2c ((promo_num+1), MAX_SEQUENCE_LENGTH);
			genome_temp->species =  alloc2c(MAX_PROMOTER_NUM , MAX_SEQUENCE_LENGTH);
			AllocArray (genome_temp->clo_num,(promo_num+1));
			for (i=0; i<promo_num+1; i++)
				genome_temp->clo_num[i] = clo_length [i];
			for (i=0; i<promo_num+1; i++)
				for (j=0; j<clo_length[i]; j++)
					genome_temp->sequences_r[i][j] = sequences_temp[i][j];
			strcpy (genome_temp->oper_name, name);
		       	genome_temp->seq_num = promo_num+1;	
			genome_temp->markov_matrix = markov(genome_temp->sequences_r,genome_temp->seq_num);
			genome_temp->species = species;
			/* save current reference genome to global **genome */
			genome[oper_num] = genome_temp;
			oper_num++;
			AllocVar (genome_temp);
			AllocArray (genome_temp->oper_name, 20);
			species = alloc2c(MAX_PROMOTER_NUM , MAX_SEQUENCE_LENGTH);
			atom = strtok(buffer, delims);
			strcpy(name, atom);
			promo_num = 0;
			t=0;
			continue;
		}
		/* case insensitive and adopt \n in each sequence */
		if(buffer[0]=='A'||buffer[0]=='T'||buffer[0]=='G'||buffer[0]=='C'||buffer[0]=='a'||buffer[0]=='t'||buffer[0]=='g'||buffer[0]=='c')
                {
                        t=1;
                        for (j=k;j<strlen(buffer)-1+k;j++)
                                sequences_temp[promo_num][j] = buffer[j-k];
                        k=k+strlen(buffer)-1;
			clo_length [promo_num] = strlen(buffer)-1;
                }
                else
                {
                        if (t==0) promo_num = 0;
                        else promo_num++;
	
			atom = strtok(buffer, delims);
                        atom = strtok(NULL, delims);
                        strcpy (species[promo_num], atom);
			
			if (promo_num > MAX_PROMOTER_NUM)
			{
			 	printf ("Sorry, the number of reference promoters are too large\n");	
				exit(1);
			}
                        k=0;
                }
	}
}
/***********************************************************************/
static int charset_add(discrete *ar, discrete s)
{
        int ps = s + SHRT_MAX;
        if (bb[ps]<0)
        {
                bb[ps] = sigma;
                ar[sigma++] = s;
        }
        return bb[ps];
}

/************************************************************************/
void init_dis_operon()
{
        int row, col;
        AllocArray(symbols, USHRT_MAX);
        memset(bb, -1, USHRT_MAX*sizeof(*bb));
        charset_add(symbols, 0);
        arr_c = alloc2d (oper_num_all,oper_num_all);
        z_score = alloc2dd (oper_num_all,oper_num_all);
        z_score_second = alloc2dd (oper_num_all,oper_num_all);
	z_score_search = alloc2dd (oper_num_all,oper_num_all);
        for (row = 0; row < oper_num_all; row++)
        {
                for (col = 0; col < oper_num_all; col++)
                {
                        arr_c[row][col] = 0;
                        arr_c[row][row] = 1;
                        z_score[row][col] = 0.0;
			z_score_search[row][col] = 0.0;
                }
        }
        ver = oper_num_all;
        rows = oper_num_all;
        cols = oper_num_all;
}
/************************************************************************/
