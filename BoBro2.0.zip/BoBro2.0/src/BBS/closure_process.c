/************************************************************************/
/* Author: Qin Ma <maqin@csbl.bmb.uga.edu>, Feb. 16, 2010
 * all the related process of closures are stored in the file        
 */


#include "closure_process.h"
static const int HEAP_SIZE = 3000000;
/************************************************************************/
discrete **frequency_matrix (char **sequence_temp, int a, int b, int motif_number)
/*get the frequency matrix used in caculating profile matrix*/
{
    int i,j=0,k;
    discrete **frequency;
        
    frequency = alloc2d (a,b);

    for (i=0; i<a; i++)
	for (j=0; j<b; j++)
	    frequency[i][j]=0;
    for (i=0; i<motif_number; i++)
    {
        for (k=0;k<b;k++)
        {
            if (sequence_temp[i][k]=='A' || sequence_temp[i][k]=='a') frequency[1][k] += 1;
            else if (sequence_temp[i][k]=='G' || sequence_temp[i][k]=='g') frequency[2][k] += 1;
	    else if (sequence_temp[i][k]=='C' || sequence_temp[i][k]=='c') frequency[3][k] += 1;
	    else if (sequence_temp[i][k]=='T' || sequence_temp[i][k]=='t') frequency[4][k] += 1;
        }
    }
    return frequency;
}
/************************************************************************/
char *get_consensus (discrete **frequency, int a, int b)
/*get the consensus base on a frequency matrix: A-1, G-2, C-3, T-4*/
{
	int i, j, max;
	continuous sum;
	char *concensus;

	AllocArray (concensus, b);

	for (j=0;j<b;j++)
	{
		max = frequency[1][j]; 
		sum = frequency[1][j]+frequency[2][j]+frequency[3][j]+frequency[4][j];
		for (i=2;i<5;i++)
			if (frequency[i][j] > max)
				max = frequency[i][j];
		if ((frequency[1][j] == frequency[2][j])&& (frequency[1][j]>0.33*sum))
		{
			concensus[j] = 'R'; continue; 
		}
		if ((frequency[3][j] == frequency[4][j])&& (frequency[3][j]>0.33*sum))
		{
			concensus[j] = 'Y'; continue;
		}
		if ((frequency[1][j] == frequency[3][j])&& (frequency[1][j]>0.33*sum))
		{
			concensus[j] = 'M'; continue;
		}
		if ((frequency[2][j] == frequency[4][j])&& (frequency[2][j]>0.33*sum))
		{
			concensus[j] = 'K'; continue;
		}
		if ((frequency[3][j] == frequency[2][j])&& (frequency[2][j]>0.33*sum))
		{
			concensus[j] = 'S'; continue;
		}
		if ((frequency[1][j] == frequency[4][j])&& (frequency[1][j]>0.33*sum))
		{
			concensus[j] = 'W'; continue;
		}
		if ((frequency[1][j] == frequency[4][j])&& (frequency[3][j] == frequency[4][j])&&(frequency[1][j]>0.25*sum))
		{
			concensus[j] = 'H'; continue;
		}
		if ((frequency[3][j] == frequency[4][j])&& (frequency[3][j] == frequency[2][j])&&(frequency[2][j]>0.25*sum))
		{
			concensus[j] = 'B'; continue;
		}
		if ((frequency[1][j] == frequency[2][j])&& (frequency[3][j] == frequency[2][j])&&(frequency[1][j]>0.25*sum))
		{
			concensus[j] = 'V'; continue;
		}
		if ((frequency[1][j] == frequency[4][j])&& (frequency[2][j] == frequency[4][j])&&(frequency[1][j]>0.25*sum))
		{
			concensus[j] = 'D'; continue;
		}
		if ((frequency[1][j] == frequency[2][j])&& (frequency[3][j] == frequency[2][j])&&(frequency[3][j] == frequency[4][j]))
		{
			concensus[j] = 'N'; continue;
		}
		if (frequency[1][j] == max)
		{
			concensus[j] = 'A'; continue;
		}
		if (frequency[2][j] == max)
		{
			concensus[j] = 'G'; continue;
		}
		if (frequency[3][j] == max)
		{
			concensus[j] = 'C'; continue;
		}
		if (frequency[4][j] == max)
		{
			concensus[j] = 'T'; continue;
		}
	}
	return concensus;

}
/************************************************************************/
continuous **get_profile (char **sequence_temp, int a, int b, int motif_number)
/*get the profile matrix of a closure*/
{
    continuous **scoreM;
    discrete **frequency;
    int i,j;

    scoreM = alloc2dd (a,b);

    for (i=0; i<a; i++)
	for (j=0; j<b; j++)
  	    scoreM[i][j]=0;

    frequency = frequency_matrix (sequence_temp, a, b, motif_number);

    for (i=1;i<a;i++)
	for (j=0;j<b;j++)
	    scoreM[i][j]= log2((frequency[i][j]+p_markov[i][0])/(p_markov[i][0]*(motif_number+1)));

    for (i=0;i<a;i++)
	free (frequency[i]);
    free (frequency);

    return scoreM;
}
/************************************************************************/
continuous **get_palindromic_profle (continuous **scoreM, int length_local)
/*get the palindromic profile*/
{
    int j;
    continuous **scoreM_panlindromic;

    scoreM_panlindromic = alloc2dd (5,length_local);

    for (j=0;j<length_local;j++)
    {
	scoreM_panlindromic[0][length_local-j-1] = scoreM[0][j];
	scoreM_panlindromic[1][length_local-j-1] = scoreM[4][j];
	scoreM_panlindromic[4][length_local-j-1] = scoreM[1][j];
	scoreM_panlindromic[2][length_local-j-1] = scoreM[3][j];
	scoreM_panlindromic[3][length_local-j-1] = scoreM[2][j];
    }
    return scoreM_panlindromic;
}
/************************************************************************/
char *palindromic_seq (char *consensus, int length)
/*get the palindromic pattern*/        
{
    int i;
    char *palindromic;

    AllocArray(palindromic, length);

    for (i=0;i<length;i++)
    {
    	if (consensus[i]=='A'|| consensus[i]=='a') { palindromic[length-i-1]='T'; consensus[i]='A';}
	if ((consensus[i]=='T')||(consensus[i]=='t')) {palindromic[length-i-1]='A';consensus[i]='T';}
        if ((consensus[i]=='C')||(consensus[i]=='c')) {palindromic[length-i-1]='G';consensus[i]='C';}
        if ((consensus[i]=='G')||(consensus[i]=='g')) {palindromic[length-i-1]='C';consensus[i]='G';}
    }
    return palindromic;
}
/************************************************************************/
continuous **impovre_profle (continuous **scoreM, double  length_local_1)
/*improve the score matrix base on the conserve property of two ends of motif*/
{
	int /*forepart=floor(length_local_1/3),endpart=ceil(length_local_1/3),*/delIndex=0, i, j;
        continuous sum_scoreM=0;

        for (j=0;j<length_local_1;j++)
        {
                scoreM[0][j]=0;
                for (i=1;i<5;i++)
			if (scoreM[i][j] > scoreM[0][j]) scoreM[0][j]=scoreM[i][j];
                sum_scoreM = sum_scoreM + scoreM[0][j];
        }
        for (j=0;j<length_local_1;j++)
	        if (scoreM[0][j]<((sum_scoreM*0.6)/length_local_1))
                {
        	        if (delIndex==1)
                	        for (i=1;i<5;i++)
                        	        scoreM[i][j]=0;
			else
				delIndex=1;
		}
        /*for (j=0;j<forepart;j++)
        {
                scoreM[0][j]=0;
                for (i=1;i<5;i++)
			if (scoreM[i][j] > scoreM[0][j]) scoreM[0][j]=scoreM[i][j];
                sum_scoreM = sum_scoreM + scoreM[0][j];
        }
        for (j=0;j<forepart;j++)
	        if (scoreM[0][j]<((sum_scoreM*0.6)/forepart))
                {
        	        if (delIndex==1)
                	        for (i=1;i<5;i++)
                        	        scoreM[i][j]=0;
			else
				delIndex=1;
                }
	sum_scoreM =0; delIndex=0;
        for (j=length_local_1-1;j>length_local_1-endpart-1;j--)
        {
        	scoreM[0][j]=0;
                for (i=1;i<5;i++)
                	if (scoreM[i][j] > scoreM[0][j]) scoreM[0][j]=scoreM[i][j];
                sum_scoreM = sum_scoreM + scoreM[0][j];
        }
	for (j=length_local_1-1;j>length_local_1-endpart-1;j--)
        	if (scoreM[0][j]<((sum_scoreM*0.6)/forepart))
                {
                	if (delIndex==1)
                        	for (i=1;i<5;i++)
                                	scoreM[i][j]=0;
			else
	                        delIndex=1;
		}
	for (j=forepart;j<length_local_1-endpart;j++)
        	for (i=1;i<5;i++)
			scoreM[i][j]=scoreM[i][j]/2;*/  /*if plalindome, scoreM[i][j]=0*/
	return scoreM;
}
/************************************************************************/
continuous *get_column_IC (int length,  int number, int motif_num)
{
        continuous *I_11;
        int p , q;
        AllocArray (I_11, length);
        for (p = 0; p < length; p++)
        {
                I_11[p] = 0;
                for (q=1; q<5; q++)
                        I_11[p] = I_11[p] + (fre_all[motif_num][q][p]*sco_all[motif_num][q][p])/number;
        }
        return I_11;
}
/************************************************************************/
continuous *get_column_IC_12 (int startpos_1, int startpos_2, int num_a, int num_b, int motif_1, int motif_2, int motif_number)
{
        continuous *I_12, fre_temp=0;
        int p , q;
        int min=MIN((num_a-startpos_1),(num_b-startpos_2));
        AllocArray (I_12, min);
        for (p = 0; p < min; p++)
        {
                I_12[p] = 0;
                for (q=1; q<5; q++)
		{
			fre_temp = fre_all[motif_1][q][startpos_1+p];
                        I_12[p] = I_12[p] + (fre_temp*sco_all[motif_2][q][startpos_2+p])/motif_number;
		}
        }
        return I_12;
}
/************************************************************************/
continuous *get_column_IC_21 (int startpos_1, int startpos_2, int num_a, int num_b, int motif_1, int motif_2, int motif_number)
{
        continuous *I_21;
        int p , q;
        int min = MIN(num_a-startpos_1, num_b-startpos_2);
        AllocArray (I_21, min);
        for (p = 0; p < min; p++)
        {
                I_21[p] = 0;
                for (q=1; q<5; q++)
                        I_21[p] = I_21[p] + (fre_all[motif_2][q][startpos_2+p]*sco_all[motif_1][q][startpos_1+p])/motif_number;
        }
        return I_21;
}

/************************************************************************/
void compare_motif (const char* fn)
{
	FILE *fw = mustOpen(fn, "w");
	char **name;
	int i=0, j=0, k=0, iteration_num=0, *motif_length, *motif_number, min_length=0, startpos[2], start, mos=0, p1=0, p2=0;
	discrete **pos_1, **pos_2;
	continuous *I_11, *I_22,*I_12, *I_21, SimilarityScore=0, IC_1=0, IC_2=0, IC_12=0, IC_21=0, IC_temp=0, IC_final=0, similarity=-10, **matrix_score, score_temp=0;
	if (po->IsAlignment)
	{ 
		iteration_num = alignment_num;
		AllocArray (motif_length, iteration_num);
		AllocArray (motif_number, iteration_num);
		name = alloc2c(iteration_num, 2000);
		for (i=0; i<iteration_num; i++)
		{
			motif_length[i] = Alignment[i]->ColNum;
			motif_number[i] = Alignment[i]->RowNum;
			name[i] = Alignment[i]->motif_name;
		}
	}
	else 
	{ 
		iteration_num = matrix_num;
		AllocArray (motif_length, iteration_num);
		AllocArray (motif_number, iteration_num);
		name = alloc2c(iteration_num, 2000);
                for (i=0; i<iteration_num; i++)
		{
	                motif_length[i] = Matrix[i]->ColNum;
			motif_number[i] = Matrix[i]->RowNum;
			name[i] = Matrix[i]->motif_name;
		}
	}

	fre_all = (discrete***)malloc(sizeof(discrete**)*iteration_num);
	sco_all = (continuous***)malloc(sizeof(continuous**)*iteration_num);

	for (i=0;i<iteration_num;i++)
        {
                fre_all[i] = alloc2d (5, motif_length[i]);
                sco_all[i] = alloc2dd (5, motif_length[i]);
		for (j=0; j<5; j++)
			for (k=0;k<motif_length[i]; k++)
			{
				fre_all[i][j][k] = 0;
				sco_all[i][j][k] = 0;
			}	
        }

	matrix_score = alloc2dd (iteration_num, iteration_num);
	pos_1 = alloc2d (iteration_num, iteration_num);
	pos_2 = alloc2d (iteration_num, iteration_num);
	for (i=0;i<iteration_num;i++)
                for (j=0;j<iteration_num; j++)
		{
			matrix_score[i][j] = 0;
			pos_1[i][j] = 0;
			pos_2[i][j] = 0;
		}

	/*get fre_all and sco_all*/
	for (i=0; i<iteration_num; i++)
	{
		if (po->IsAlignment) 
			fre_all[i] = frequency_matrix (Alignment[i]->sequences, 5, motif_length[i], motif_number[i]);
		else if (po->IsMatrix)
			fre_all[i] = Matrix[i]->matrix;

		for (j=1;j<5;j++)
               		for (k=0;k<motif_length[i];k++)
			{
               	        	score_temp = fre_all[i][j][k];
				if (score_temp > 0)
					sco_all[i][j][k] = log2(4*score_temp/motif_number[i]);
			}
	}

	/*==========================compare each pair of closures=============================================================*/
	for (i=0; i<iteration_num-1; i++, IC_1=0)
	{
		I_11 = get_column_IC (motif_length[i], motif_number[i], i);
		for (k=0; k<motif_length[i]; k++)
                        IC_1 = IC_1 + I_11[k]*I_11[k];
                SimilarityScore = 0;
		for (j=i+1, IC_2=0; j<iteration_num; j++, IC_2=0,similarity = -10)
		{
			I_22 = get_column_IC (motif_length[j], motif_number[j], j);
			for (k=0; k<motif_length[j]; k++)
                                IC_2 = IC_2 + I_22[k]*I_22[k];
			mos=0;
			for(startpos[0]=0,startpos[1]=motif_length[j]-1; startpos[1]>0||startpos[0]<motif_length[i]; mos=0)
			{
				I_12 = get_column_IC_12 (startpos[0], startpos[1], motif_length[i], motif_length[j], i, j, motif_number[i]);
				I_21 = get_column_IC_21 (startpos[0], startpos[1], motif_length[i], motif_length[j], i, j, motif_number[j]);		
				IC_21=IC_12=0;
				min_length = MIN(motif_length[i]-startpos[0], motif_length[j]-startpos[1]);
				
                                for (start = mos; start < mos+min_length; start++)
                                {
                                        if (I_12[start] > 0) IC_12 = IC_12 + I_12[start]*I_22[startpos[1]+start];
                                        if (I_21[start] > 0) IC_21 = IC_21 + I_21[start]*I_11[startpos[0]+start];
                                }
				IC_temp = (IC_12 + IC_21)/(IC_1 + IC_2);
				IC_final = IC_temp*IC_temp*min_length/motif_length[j];
                                if (IC_final > similarity)
				{
					similarity = IC_final;
					p1 = startpos[0]+1;
					p2 = startpos[1]+1;
				}
				/*printf ("%d\t%d\t%.2f\t%.2f\t%d\n", startpos[0]+1, startpos[1]+1, similarity, IC_final,min_length);*/

				if(startpos[1]>0) startpos[1]--;
                                else startpos[0]++;
                                free (I_12);
                                free (I_21);		
			}
			free (I_22);
			matrix_score[i][j] = similarity;
                        matrix_score[j][i] = similarity;
			pos_1[i][j] = p1;
			pos_1[j][i] = p2;
			pos_2[i][j] = p2;
			pos_2[j][i] = p1;
		}
	}
	/*print out the similarity scores*/
        fprintf (fw, "similarity\t");
        for (i=0;i<iteration_num;i++)
                fprintf (fw, "%s\t",name[i]);
        fprintf (fw, "\n");
        for (i=0;i<iteration_num;i++)
        {
                fprintf (fw, "%s\t",name[i]);
                for (j=0;j<iteration_num;j++)
                        fprintf (fw, "%3.2f (%d-%d)\t",matrix_score[i][j], pos_1[i][j], pos_2[i][j]);
                fprintf (fw, "\n");
        }
	fclose (fw);
	 /*========================================free the space=================================================*/
        for (i=0;i< iteration_num;i++)
        {
                for (j=0;j<5;j++)
                {
                        free (fre_all[i][j]);
                        free (sco_all[i][j]);
                }
                free (fre_all[i]);
                free (sco_all[i]);
        }
        free (fre_all);
        free (sco_all);
	uglyTime("The similarity between any pair of motifs are written to %s", fn);
	printf ("\n");
}
/************************************************************************/
