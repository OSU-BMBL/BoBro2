/************************************************************************/
/* Author: Qin Ma <maqin@csbl.bmb.uga.edu>, Feb. 15, 2010
 * the functions related to printing output to specific files
 */

#include "write_file.h"
/*************************************************************************/
void print_params(FILE *fw1)
{
        fprintf(fw1, "#########################################\n#                                       #\n");
        fprintf(fw1, "#\tBregulon version %.3f output\t#\n", VER);
        fprintf(fw1, "#                                       #\n#########################################\n");
        if (po->Low == po->Up)
	{
                fprintf(fw1, "\nParameters: -k %d -c %.2f -o %d -l %d -u %2.2f -e %d -s %d -w %3.2f", po->COL_WIDTH, po->TOLERANCE, po->RPT_BLOCK,po->MOTIFLENGTH, po->closure_threshold, po->closure_enlarge_times, po->simu, po->end_weight);
		if (po->palindromic) fprintf(fw1, " -P");
		if (po->mirror) fprintf(fw1, " -M");
		if (po->IS_global) fprintf(fw1, " -G");
		if (po->IS_local) fprintf(fw1, " -C");
		if (po->IS_reference_H) fprintf(fw1, " -H");
		if (po->IS_microarray) fprintf(fw1, " -m");
		if (po->expansion) fprintf(fw1, " -E");
		if (SequenceWeight) fprintf(fw1, " -W");
		if (po->approximate) fprintf(fw1, " -A");
		if (po->FastVersion) fprintf(fw1, " -F");
	}
        else if (po->Low < po->Up)
	{
                fprintf(fw1, "\nParameters: -k %d -c %.2f -o %d -n %d -L %d -U %d -R %d -u %2.2f -e %d -s %d -w %3.2f", po->COL_WIDTH, po->TOLERANCE, po->RPT_BLOCK, po->number, po->Low, po->Up, po->range, po->closure_threshold, po->closure_enlarge_times, po->simu, po->end_weight);
		if (po->palindromic) fprintf(fw1, " -P");
                if (po->mirror) fprintf(fw1, " -M");
                if (po->IS_global) fprintf(fw1, " -G");
                if (po->IS_local) fprintf(fw1, " -C");
                if (po->IS_reference_H) fprintf(fw1, " -H");
                if (po->IS_microarray) fprintf(fw1, " -m");
                if (po->expansion) fprintf(fw1, " -E");
		if (SequenceWeight) fprintf(fw1, " -W");
		if (po->approximate) fprintf(fw1, " -A");
		if (po->FastVersion) fprintf(fw1, " -F");
	}
        fprintf(fw1, "\n");
}
/*************************************************************************/
int report_closures(FILE *fw1, Closures** cc, int num, Annotation** anno)
{
        fprintf (fw1,"Input data: %s\n",po->FN);
        if (po->IS_SWITCH) fprintf (fw1,"Annotation data: %s\n",po->BN);
        if (po->IS_closure) fprintf (fw1,"Closures file: %s\n",po->CN);
        fprintf (fw1,"Sequences number: %d\nNucleotides number: %d\n",s_rows,sum_markov);
        fprintf (fw1,"Nucleotides composition:\tA: %.2f   G: %.2f   C: %.2f   T: %.2f\n",p_markov[1][0],p_markov[2][0],p_markov[3][0],p_markov[4][0]);
        sort_closures_list(cc, num);

	/*clean up the closures base on similarity scores*/
	bool *IS_duplicate;
	IS_duplicate = clean_up_closures(cc, num, po->closure_threshold);

        int closure_output=0, ii=0, jj=0,kk=0;
        char **clo_TF;
	char **sequences_closures;
	/*num = MIN(num, po->RPT_BLOCK);*/
        while (ii< num && closure_output < po->RPT_BLOCK)
        {
                if (IS_duplicate[ii]) 
		{
		/*	printf ("%d is duplicate\n", ii);*/
			ii++;
			continue;
		}
		closure_output++;
		fprintf (fw1,"\n\n*********************************************************\n");
                fprintf (fw1," Candidate Motif %3d\n",closure_output);
                fprintf (fw1,"*********************************************************\n\n");
                fprintf (fw1," Motif length: %d\n Motif number: %d\n Seed number: %d\n Pvalue: %3.2LG (%d)\n\n",cc[ii]->length, cc[ii]->closure_rows, cc[ii]->size,cc[ii]->significance, cc[ii]->pvalue);
                fprintf (fw1,"------------------- Aligned Motif ------------------\n");
                if (po->ID) fprintf (fw1,"#Seq\tposi\tID\tMotif\t\tScore\tAnnotation\n");
		else fprintf (fw1,"#Seq\tposi\tMotif\t\tScore\n");

                int i3 = get_num_TF (cc[ii]);
                clo_TF =alloc2c (i3,10);
                i3 = 0;
		sequences_closures = alloc2c(cc[ii]->closure_rows,cc[ii]->length);
                for (jj=0; jj<cc[ii]->closure_rows; jj++)
                {
                        int kkk=0;
			if (po->ID) fprintf (fw1,"%d\t%d\t%s\t",dsItem(cc[ii]->sequence,jj),dsItem(cc[ii]->position,jj),locus_id[dsItem(cc[ii]->sequence,jj)]);
			else fprintf (fw1,"%d\t%d\t",dsItem(cc[ii]->sequence,jj),dsItem(cc[ii]->position,jj));
                        for (kk=dsItem(cc[ii]->position,jj); kk< (dsItem(cc[ii]->position,jj)+cc[ii]->length); kk++)
			{
                                fprintf (fw1,"%c",sequences[dsItem(cc[ii]->sequence,jj)][kk]);
				sequences_closures[jj][kkk] = sequences[dsItem(cc[ii]->sequence,jj)][kk];	
				kkk++;
			}
                        fprintf (fw1,"\t%.2f\t",cc[ii]->score[jj]);
			if (po->IS_SWITCH)
                        {
                                int i1=0, i2=0;
                                for (kk = 0; kk<anno[dsItem(cc[ii]->sequence,jj)]->num;kk++)
                                {
                                        i1 = dsItem(anno[dsItem(cc[ii]->sequence,jj)]->init,kk);
                                        i2 = dsItem(anno[dsItem(cc[ii]->sequence,jj)]->end,kk);
                                        if ((dsItem(cc[ii]->position,jj) >= i1)&&(dsItem(cc[ii]->position,jj) <= i2))
                                        {
                                                clo_TF[i3++] = anno[dsItem(cc[ii]->sequence,jj)]->TF[kk];
                                                fprintf (fw1,"%s",anno[dsItem(cc[ii]->sequence,jj)]->TF[kk]);
                                                fprintf (fw1,"_%d",dsItem(anno[dsItem(cc[ii]->sequence,jj)]->init,kk));
                                                fprintf (fw1,"_%d ",dsItem(anno[dsItem(cc[ii]->sequence,jj)]->end,kk));
                                        }

                                }
                        }
                        fprintf (fw1,"\n");
                }
                if (po->IS_SWITCH)  print_frequency_anno (fw1, clo_TF, i3,cc[ii]->closure_rows );
		if (po->IS_reference_H)  
		{
			verboseDot();
			print_operons (fw1, sequences_closures, genome,cc[ii]->closure_rows,oper_num_all);
		}
		ii++;
                fprintf (fw1,"----------------------------------------------------\n");
        }
        return closure_output;
}

/************************************************************************/
int block_cmpr_1(const void *a, const void *b)
/*compare function for qsort, decreasing by score*/
{
        return ((*(Closures **)b)->pvalue - (*(Closures **)a)->pvalue);
}

void sort_closures_list(Closures **el, int n)
{
        qsort(el, n, sizeof *el, block_cmpr_1);
}
/************************************************************************/
int block_cmpr_oper(const void *a, const void *b)
/*compare function for qsort, decreasing by score*/
{
        return ((*(Block **)b)->oper_num - (*(Block **)a)->oper_num);
}

void sort_block_list_oper(Block **el, int n)
{
        qsort(el, n, sizeof *el, block_cmpr_oper);
}
/************************************************************************/
int report_regulon( FILE *fw,  Block** bb, int num)
{
	print_params(fw);
        fprintf (fw,"Input data: %s\n",po->FN);
        if (po->IS_SWITCH) fprintf (fw,"Annotation data: %s\n",po->BN);
        if (po->IS_closure) fprintf (fw,"Closures file: %s\n",po->CN);
        fprintf (fw,"Sequences number: %d\nNucleotides number: %d\n",s_rows,sum_markov);
        fprintf (fw,"Nucleotides composition:\tA: %.2f   G: %.2f   C: %.2f   T: %.2f\n",p_markov[1][0],p_markov[2][0],p_markov[3][0],p_markov[4][0]);
        /* if po->IS_reference is TRUE we should sort the regulons base on their containing operon numbers */
	if (po->IS_reference) sort_block_list_oper (bb,num);
	else sort_block_list(bb, num);

        int i, j,k;
        int n = MIN(num, po->RPT_BLOCK);
        bool flag;
        Block **output;
        AllocArray(output, n);
        Block **bb_ptr = output;
        Closures **cc;
        AllocArray(cc, n);
        Block *b_ptr;
        int cur_rows, cur_cols;
        int inter_rows, inter_cols;
        /* the major post-processing here, filter overlapping blocks*/
        i = 0; j = 0;
        while (i < num && j < n)
        {
                b_ptr = bb[i];
                cur_rows = b_ptr->block_rows;
                cur_cols = b_ptr->block_cols;
                flag = TRUE;
                k = 0;
                while (k < j)
                {
                        inter_rows = dsIntersect(output[k]->genes, b_ptr->genes);
                        inter_cols = dsIntersect(output[k]->conds, b_ptr->conds);
                        if (inter_rows*inter_cols > po->FILTER*cur_rows*cur_cols) flag = FALSE; break;
                        k++;
                }
                i++;
		if (flag)
                {
/*        printf ("%d\t%d\n",dsItem(all[dsItem(b_ptr->genes,0)]->sequence,0),dsItem(all[dsItem(b_ptr->genes,0)]->position,0));*/
                        if (po->IS_reference) print_regulon_vertical (fw,b_ptr,j++);
			else	print_regulon_horizonal (fw,b_ptr,j++);
                        *bb_ptr++ = b_ptr;
			/*verboseDot();*/
                }
        }
        return j;
}

/************************************************************************/
/* Identified clusters are backtraced to the original data, by putting the clustered vectors together, identify common column */
void print_bc (FILE *fw1, Closures **cc, int num_cc, Block* b, int num)
{
        int i;
        int block_rows;

        block_rows = b->block_rows;
        char **sequences_1;
        sequences_1=(char**)malloc(sizeof(char*)*block_rows);
        for(i=0;i<b->score;i++)
                sequences_1[i]=(char*)malloc(sizeof(char)*50);
        char *seq;
        AllocArray(seq,100);
        int *pos,*dd,*dd1;
        continuous  *IC, *IC_sum, *IC_sum1;
        AllocArray (pos,100);
        AllocArray (dd,100);
        AllocArray (IC,4);
        AllocArray (IC_sum,100);
        AllocArray (IC_sum1,20);
        AllocArray (dd1,100);
        int j,k,d=0,d1,left,right;
        for(i=0;i<100;i++)
                dd[i]=0;
	/*print the profile corresponding to the accompany matrix*/
        for (i=0;i<b->score;i++)
        {
                d = profile1[genes[dsItem(b->genes, i)]].x;
                d1 = profile1[genes[dsItem(b->genes, i)]].y;
                k=0;
                if (i==0) dd1[0]=d1;
                else
                {
                        if (dsItem(b->genes, 0) <= dsItem(b->genes, i))
                                dd1[i]=d1+arr_c1[dsItem(b->genes, 0)][dsItem(b->genes, i)];
                        else
                                dd1[i]=d1-arr_c1[dsItem(b->genes, 0)][dsItem(b->genes, i)];
                }
                left = MAX(0,dd1[i]-4);
                int length1=strlen(sequences[d])-1;
                right = MIN(length1,dd1[i]+po->MOTIFLENGTH+4);
                if (dd1[i]<4)
                        for (j=0;j<4-dd1[i];j++)
                        {
                                sequences_1[i][k]='N';
                                k++;
                        }
                for (j=left;j<right;j++)
                {
                        sequences_1[i][k]=sequences[d][j];
                        k++;
                }
                if (length1<dd1[i]+po->MOTIFLENGTH+4)
                        for (j=0;j<(dd1[i]+po->MOTIFLENGTH+4-length1);j++)
                        {
                                sequences_1[i][k]='N';
                                k++;
                        }
                dd1[i]=dd1[i]-4;
        }
	int num1=0,num11=0;
        double num4=0, average1=0,average=0;
        IC[0]=IC[1]=IC[2]=IC[3]=0;
        for (i=0;i< (po->MOTIFLENGTH+8);i++)
        {
                IC[0]=IC[1]=IC[2]=IC[3]=0;
                IC_sum[i]=0;
                for (j=0;j<block_rows;j++)
                {
                        if (sequences_1[j][i]=='A') IC[0]++;
                        if (sequences_1[j][i]=='T') IC[1]++;
                        if (sequences_1[j][i]=='C') IC[2]++;
                        if (sequences_1[j][i]=='G') IC[3]++;
                }
                for (k=0;k<4;k++)
                        if(IC[k]>0)
                        {
                                IC[k]=(IC[k]/block_rows)*log(4*IC[k]/block_rows);
                                IC_sum[i]+=IC[k];
                        }
        }
	/*local optimal of IC*/
        double length, length_local=0,two_end=0;
        left= MAX (po->MOTIFLENGTH,6);
        for (length=left;length<po->MOTIFLENGTH+1;length++)
        {
                for (i=0;i<po->MOTIFLENGTH+8-length;i++)
                {
                        IC_sum1[i]=0;
                        two_end=0;
                        IC_sum1[i]+=po->end_weight*IC_sum[i];
                        two_end+=IC_sum[i];
                        for (j=i+1;j<i+floor(length/3);j++)
                        {
                                IC_sum1[i]+=po->end_weight*IC_sum[j];
                                two_end+=IC_sum[j];
                        }
                        for (j=i+floor(length/3);j<i+length-ceil(length/3);j++)
                                IC_sum1[i]+=IC_sum[j];
                        for (j=i+length-ceil(length/3);j<i+length;j++)
                        {
                                IC_sum1[i]+=po->end_weight*IC_sum[j];
                                two_end+=IC_sum[j];
                        }
                        if (IC_sum1[i] >= num4)
                        {
                                num4=IC_sum1[i];
                                average1=two_end/(floor(length/3)+ceil(length/3));
                                num11=i;
                        }
                }
                if (average1>=average)
                {
                        average=average1;
                        num1=num11;
                        length_local=length;
                }
        }
	/*the information which bingqiang will need*/
        for (i=0; i<dsSize(b->genes); i++)
                d = profile1[genes[dsItem(b->genes, i)]].x;

	/***********************get closures for seed**********************/
        int ii,t;        
        int  seq_number = s_rows; 
        int length_local_1 = length_local, Motif_Scan_V[7];
        /*continuous Motif_R_V[7],pvalue_V[7];*/
	long double Motif_R_V[7],pvalue_V[7];
        continuous pp[5],AveScore_V[7],score_scan=0;
        discrete **frequency;
        continuous **scoreM;
        Motif* c;
        AllocVar(c);
        struct dyStack *gene, *cond;
        struct dyStack *gene2, *cond2 ;
        continuous score[CLOSURE_SIZE];
        int motif_number= b->score,motif_number_2=0;
        long double  pvalue=1; pvalue=1;
        gene = dsNew(CLOSURE_SIZE);
        cond = dsNew(CLOSURE_SIZE);
        gene2 = dsNew(CLOSURE_SIZE);
        cond2 = dsNew(CLOSURE_SIZE);
	if (num==0)  size_closure = motif_number;
        for (i=0; i<motif_number; i++)
	{
                dsPush(gene,dsItem(b->genes,i));
                dsPush(cond,dsItem(b->conds,i));
                score[i]=0;
        }

        frequency = alloc2d (5,length_local_1); scoreM = alloc2dd (5,length_local_1);
        /* 1000: 3 times closure improvement begion : ii */
        for (ii=1;ii< po->closure_enlarge_times+1;ii++)
	{
                /*1100: load current seed or motifs in sequences_2: begin*/
                char **sequences_2;
                sequences_2 = alloc2c (motif_number, length_local_1);
                if (ii==1)
                        for(i=0;i<motif_number;i++)
                                for (j=0; j<length_local_1; j++)
                                        sequences_2[i][j] = sequences_1[i][num1+j];
                else
		{
                        motif_number=motif_number_2;
                        for(i=0;i<motif_number;i++)
                                for (j=0; j<length_local_1; j++)
                                        sequences_2[i][j]=sequences[dsItem(gene2,i)][dsItem(cond2,i)+j];
                }                              
                /*1200: calculate the frequency matrix and log matrix begin*/
                scoreM = get_profile (sequences_2, 5 , length_local_1, motif_number);
                /* 1300: improve the scoring log matrix begin*/
		if (po->palindromic)	scoreM = impovre_profle_palindromic (scoreM, length_local_1,  sequences_2, 5 ,motif_number);
		else if (po->mirror)    scoreM = impovre_profle_mirror (scoreM, length_local_1,  sequences_2, 5 ,motif_number);
		else scoreM = impovre_profle (scoreM, length_local_1);
                /*1400: scoring motifs and calculate threshod for closure begin*/
		continuous AveScore=0;
		AveScore = aver_score_closure(sequences_2,  scoreM, score, motif_number, length_local_1);
/*		printf ("%3.2f\n",AveScore);*/
                for (i=0;i<7;i++)
		{
                        AveScore_V[i]=(0.3+0.1*i)*AveScore;
                        Motif_Scan_V[i]=0; 
			Motif_R_V[i]=0;
                }
                /*1500: scan data to built closures begin*/
                gene = dsNew(CLOSURE_SIZE);
                cond = dsNew(CLOSURE_SIZE);
                motif_number=0;
		for (i=0;i<seq_number;i++)
                        for (j=0;j<strlen(sequences[i])-length_local_1+1;j++)   
			{
                                score_scan=0;
                                for (k=0;k<length_local_1;k++)
				{
                                        if (sequences[i][k+j]=='A' || sequences[i][k+j]=='a')
                                                score_scan = score_scan + scoreM[1][k];
                                        if (sequences[i][k+j]=='G' || sequences[i][k+j]=='g')
                                                score_scan = score_scan + scoreM[2][k];
                                        if (sequences[i][k+j]=='C' || sequences[i][k+j]=='c')
                                                score_scan = score_scan + scoreM[3][k];
                                        if (sequences[i][k+j]=='T' || sequences[i][k+j]=='t')
                                                score_scan = score_scan + scoreM[4][k];
                                }
                                if (score_scan>AveScore_V[po->threshold_e2] && motif_number < CLOSURE_SIZE-10)
				{
                                        for (k=6;k>=0;k--)
                                                if (score_scan>AveScore_V[k])
                                                        Motif_Scan_V[k]++;
                                        dsPush(gene,i);
                                        dsPush(cond,j);
                                        score[motif_number]=score_scan;
                                        motif_number++;
                                }
                        }                       
                /*1600: for first two steps of closure-build only begin*/
		if (ii < po->closure_enlarge_times)
		{
                        gene2 = dsNew(CLOSURE_SIZE);
                        cond2 = dsNew(CLOSURE_SIZE);
                        if (motif_number<size_closure)
			{
                                motif_number_2=motif_number;
                                for (i=0;i<motif_number;i++)
				{
                                        dsPush(gene2,dsItem(gene,i));
                                        dsPush(cond2,dsItem(cond,i));
                                }
                        }
			else
			{
                                int i_max_1=0; continuous score_max_1=0;
                                motif_number_2=size_closure;
                                for (i=0;i<motif_number_2;i++)
				{
                                        i_max_1=0;score_max_1=0;
                                        for (j=0; j<motif_number; j++)
                                                if (score[j]>score_max_1) 
						{
                                                        i_max_1=j;
                                                        score_max_1=score[j];
                                                }
                                        dsPush(gene2,dsItem(gene,i_max_1));
                                        dsPush(cond2,dsItem(cond,i_max_1));
                                        score[i_max_1]=0;
                                }
                        }
                }
        }
        /* 1000: 3 times closure improvement end : ii */

        /* 2000:  simulation on markov data begin */
	int length_ave=0,numberfore=1,randomNum,simulation=po->simu,Rt,num_all_R=0;
        continuous length_ave_1=0;
        for (i=0;i<seq_number;i++)
                length_ave_1=length_ave_1+strlen(sequences[i]);
        length_ave=ceil(length_ave_1/seq_number); 

        srand((unsigned)time(NULL));
        char *randomdata;
        AllocArray (randomdata,length_ave);
        for (Rt=0;Rt<3000*simulation;Rt++)
	{
                for (i=0;i<4;i++)
		{
                        for(j=0;j<length_ave;j++)  
			{
                                num_all_R++;
                                for (k=1;k<5;k++)
                                        pp[k]=p_markov[numberfore][k];
                                randomNum=rand()%100;
                                if (randomNum<pp[1]*100) {randomdata[j]='A';numberfore=1;}
                                else if (randomNum<(pp[1]+pp[2])*100) {randomdata[j]='G';numberfore=2;}
                                else if (randomNum<(pp[1]+pp[2]+pp[3])*100) {randomdata[j]='C';numberfore=3;}
                                else {randomdata[j]='T';numberfore=4;}
                        } 
                        for(j=0;j<length_ave-length_local_1+1;j++)  
			{
                                score_scan=0;
                                for (k=0;k<length_local_1;k++)
				{
                                        if (randomdata[k+j]=='A' || randomdata[k+j]=='a')
                                                score_scan=score_scan+scoreM[1][k];
                                        else if (randomdata[k+j]=='G' || randomdata[k+j]=='g')
                                                score_scan=score_scan+scoreM[2][k];
                                        else if (randomdata[k+j]=='C' || randomdata[k+j]=='c')
                                                score_scan=score_scan+scoreM[3][k];
                                        else if (randomdata[k+j]=='T' || randomdata[k+j]=='t')
                                                score_scan=score_scan+scoreM[4][k];
                                }
				for (k=6;k>=0;k--)
                                        if (score_scan>AveScore_V[k])
                                                Motif_R_V[k]=Motif_R_V[k]+1;
                        } 
                }
	}
	for (t=6;t>=0;t--) 
                Motif_R_V[t]=(Motif_R_V[t]*seq_number)/(4*(Rt));

        /* 2000:  simulation on markov data end   */

        /* 3000:  pvalue calculating begin   */     /*note: 4 corresponding to 0.7; 3 corresponding to 0.6; ...*/
        /*continuous Scan_tmp,R_tmp,poisson,one_tmp=1,iiii;*/
        long double Scan_tmp,R_tmp,poisson,one_tmp=1,iiii;
	int tt=0;
        for (t=po->conserve_threshold;t>=po->threshold_e2;t--)
	{
                pvalue_V[t]=0;
                Scan_tmp=Motif_Scan_V[t];
                R_tmp=Motif_R_V[t];
                while (R_tmp >600) 
		{        
			Scan_tmp=Scan_tmp/2;
			R_tmp=R_tmp/2;
		}
		if (R_tmp == 0) R_tmp++;
/*		printf ("%3.2f\n",R_tmp);*/
                poisson=one_tmp/exp(R_tmp);
		if (po->approximate)
			j=1;
		else 
			j=300;
                for (iiii=0;iiii<(int)(Scan_tmp)+j;iiii++)
		{
                        if (iiii>(int)(Scan_tmp)-1) pvalue_V[t]=pvalue_V[t]+poisson;
                        poisson=poisson*R_tmp/(iiii+1);
                }
                if (pvalue>pvalue_V[t])
		{
                        pvalue=pvalue_V[t];
			tt = t;
		}
        }
/*	printf ("%LG\t%LG\t%LG\t%LG\n",pvalue,pvalue_V[tt],poisson,R_tmp);*/
        /*adjust the output closures because the closure corresponding to the minimal pvalue will be too small*/
	if (po->expansion)
	{
		tt=0;
	        for (t=0;t<4;t++)
                	if ((Motif_Scan_V[t]-Motif_Scan_V[t+1])/(Motif_R_V[t]-Motif_R_V[t+1]) > 1.2)
				{tt=t;	break;}
	}
        /* 3000:  pvalue calculating end   */
	/* 4000:  fix the final closure and write in struct Closure begin  */
        struct dyStack *gene1, *cond1 ;
        continuous score1[CLOSURE_SIZE];
        gene1 = dsNew(CLOSURE_SIZE);
        cond1 = dsNew(CLOSURE_SIZE);
        int i_max=0;
        continuous score_max=AveScore_V[tt];
        int motif_number_1=0;
        for (i=0;i<Motif_Scan_V[tt];i++)
	{
                i_max=0;score_max=AveScore_V[tt];
                for (j=0;j<motif_number;j++)
                        if (score[j]>score_max)
			{
                                score_max=score[j];
                                i_max=j;
                        }
                dsPush(gene1,dsItem(gene,i_max));
                dsPush(cond1,dsItem(cond,i_max));
                score1[motif_number_1]=score[i_max];
                motif_number_1++;
                score[i_max]=0;
        }/*sort and cut closure end*/
        Closures *cctemp;
        AllocVar(cctemp);
        cctemp->sequence = dsNew(motif_number_1);
        cctemp->position = dsNew(motif_number_1);
        cctemp->score = (continuous*)malloc(sizeof(continuous)*motif_number_1);
        int kk;
        for ( kk=0; kk < motif_number_1; kk++)
	{
                dsPush(cctemp->sequence,dsItem(gene1,kk));
                dsPush(cctemp->position,dsItem(cond1,kk));
                cctemp->score[kk] = score1[kk];
                cctemp->closure_rows = motif_number_1;
                cctemp->significance = pvalue;
                cctemp->pvalue = -(100*log(pvalue));
                cctemp->length = po->MOTIFLENGTH;
		cctemp->name = po->FN;
		cctemp->size = b->score;
        }
        cc[num_cc] = cctemp;
}
/******************************************************************/
static void print_regulon_horizonal( FILE *fw,  Block* bb, int num )
{
	/*printf ("%d\t%d\n",dsItem(all[dsItem(bb->genes,0)]->sequence,0),dsItem(all[dsItem(bb->genes,0)]->position,0));*/
	int i,j,kk=0,kk_1;
	long int k=0;
	verboseDot();
	fprintf (fw,"\n\n*********************************************************\n");
	fprintf (fw,"Candidate Regulon %d:\t ",(num+1));
	for (i=0;i< (bb->block_rows); i++)
		 fprintf (fw,"closure %d ",(dsItem(bb->genes,i)+1));
	fprintf (fw, "\n");
	fprintf (fw,"*********************************************************\n\n");
	
	for (i=0;i<(bb->block_rows);i++)
		kk += all[dsItem(bb->genes,i)]->closure_rows;
	/*delete the redundancy*********************************************/	
	bool *isclo;
	AllocArray(isclo, s_rows*strlen(sequences[0]));
	for (i=0;i<s_rows*strlen(sequences[0]);i++)
		isclo[i] = FALSE;	
	bool *isregu;
	AllocArray(isregu,s_rows);
	for (i=0;i<s_rows;i++)
		isregu[i] = FALSE;
	kk = 0,kk_1=0;
	for (i=0;i<(bb->block_rows);i++)	
	{
		for (j=0; j<all[dsItem(bb->genes,i)]->closure_rows; j++)
		{	
			if (!isregu[dsItem(all[dsItem(bb->genes,i)]->sequence,j)])
	                {
        	                isregu[dsItem(all[dsItem(bb->genes,i)]->sequence,j)] = TRUE;
                	        kk_1++;
                	}
			k = strlen(sequences[0])*dsItem(all[dsItem(bb->genes,i)]->sequence,j) + dsItem(all[dsItem(bb->genes,i)]->position,j);
			if (!isclo[k])
			{	
				if (k>0)
                                {
                                        isclo[k-1] = TRUE;
                                        if (k>1)  isclo[k-2] = TRUE;
                                }
                                if (k<s_rows*strlen(sequences[0])-1)
                                {
                                        isclo[k+1] = TRUE;
                                        if (k<s_rows*strlen(sequences[0])-2)  isclo[k+2] = TRUE;
                                }
				isclo[k] = TRUE;
				kk++;
			}
		}
	}
	for (i=0;i<s_rows*strlen(sequences[0]);i++)
		isclo[i] = FALSE;	
/**********************************************/
	fprintf (fw," Motif length: %d\n Motif number: %d\n Operon number: %d\n\n",all[dsItem(bb->genes,0)]->length,kk,kk_1);
	fprintf (fw,"------------------- Aligned Motif ------------------\n");
	if (po->ID) fprintf (fw,"#Seq\tposi\tID\tMotif\t\tAnnotation\n");
	else fprintf (fw,"#Seq\tposi\tMotif\t\tAnnotation\n");
	sequences_regulon = alloc2c (kk,all[dsItem(bb->genes,0)]->length);
	int i3=0;
	int start=0/*, genome_num*/;
	int regulon_row=0,regulon_clo=0;
	for (i=0;i<(bb->block_rows);i++)
		i3 += get_num_TF (all[dsItem(bb->genes,i)]);
	char **reg_TF;
	reg_TF = alloc2c (i3,10);
	i3=0;
	for (i=0;i<(bb->block_rows);i++)
	{
		/*printf ("%d\t%d\n",dsItem(bb->genes,i),clo_matr1[dsItem(bb->genes,i)][0]);*/
/*		genome_num = get_genome_num_from_closure (all[dsItem(bb->genes,i)]);*/
		for (j=0; j<all[dsItem(bb->genes,i)]->closure_rows; j++)
		{
			k = strlen(sequences[0])*dsItem(all[dsItem(bb->genes,i)]->sequence,j) + dsItem(all[dsItem(bb->genes,i)]->position,j);
			if (!isclo[k])
			{
				/*make the scope (-2,2) adjacent to the current position TRUE*/
				isclo[k] = TRUE;
				if (k>0) 
				{
					isclo[k-1] = TRUE;
					if (k>1) isclo[k-2] = TRUE;
				}
				if (k<s_rows*strlen(sequences[0])-1)
				{
					isclo[k+1] = TRUE;
					if (k<s_rows*strlen(sequences[0])-2) isclo[k+2] = TRUE;
				}
				if (po->ID) fprintf (fw,"%d\t%d\t%s\t",dsItem(all[dsItem(bb->genes,i)]->sequence,j),dsItem(all[dsItem(bb->genes,i)]->position,j),locus_id[dsItem(all[dsItem(bb->genes,i)]->sequence,j)]+clo_matr1[dsItem(bb->genes,i)][dsItem(bb->genes,0)]);
				else fprintf (fw,"%d\t%d\t",dsItem(all[dsItem(bb->genes,i)]->sequence,j),dsItem(all[dsItem(bb->genes,i)]->position,j)+clo_matr1[dsItem(bb->genes,i)][dsItem(bb->genes,0)]);
				/*adjsut closures base on p_opt and q_opt*/
/*				printf ("%d\t%d\t%d\t%d\t%d\n",dsItem(bb->genes,i),dsItem(bb->genes,0),clo_matr1[dsItem(bb->genes,i)][dsItem(bb->genes,0)],dsItem(all[dsItem(bb->genes,i)]->sequence,j),dsItem(all[dsItem(bb->genes,i)]->position,j));*/
				if (dsItem(all[dsItem(bb->genes,i)]->position,j)+clo_matr1[dsItem(bb->genes,i)][dsItem(bb->genes,0)] < 0) 
				{
					start = 0;
					for (k=0;k<dsItem(all[dsItem(bb->genes,i)]->position,j)-clo_matr1[dsItem(bb->genes,i)][dsItem(bb->genes,0)];k++)
					{
						fputc ('N',fw);
	                                        sequences_regulon[regulon_row][regulon_clo++] = 'N';
					}
					for (k=dsItem(all[dsItem(bb->genes,i)]->position,j)-clo_matr1[dsItem(bb->genes,i)][dsItem(bb->genes,0)];k<all[dsItem(bb->genes,i)]->length;k++)
					{
						fprintf (fw,"%c",sequences[dsItem(all[dsItem(bb->genes,i)]->sequence,j)][k]);
	                                        sequences_regulon[regulon_row][regulon_clo++] = sequences[dsItem(all[dsItem(bb->genes,i)]->sequence,j)][k];
					}
				}
				else if ((dsItem(all[dsItem(bb->genes,i)]->position,j)+clo_matr1[dsItem(bb->genes,i)][dsItem(bb->genes,0)]+all[dsItem(bb->genes,i)]->length) > strlen(sequences[0]))  
				{
					start =dsItem(all[dsItem(bb->genes,i)]->position,j);
					for (k=(dsItem(all[dsItem(bb->genes,i)]->position,j)+clo_matr1[dsItem(bb->genes,i)][dsItem(bb->genes,0)]);k<strlen(sequences[0]);k++)
					{
						fprintf (fw,"%c",sequences[dsItem(all[dsItem(bb->genes,i)]->sequence,j)][k]);
	                                        sequences_regulon[regulon_row][regulon_clo++] = sequences[dsItem(all[dsItem(bb->genes,i)]->sequence,j)][k];
					}
					for (k=0;k<dsItem(all[dsItem(bb->genes,i)]->position,j)+clo_matr1[dsItem(bb->genes,i)][dsItem(bb->genes,0)]+all[dsItem(bb->genes,i)]->length-strlen(sequences[0]);k++)
					{
						fputc ('N',fw);
                                                sequences_regulon[regulon_row][regulon_clo++]='N';
					}
				}
				else 
				{
					start = dsItem(all[dsItem(bb->genes,i)]->position,j)+clo_matr1[dsItem(bb->genes,i)][dsItem(bb->genes,0)];
					for (k=start; k< start+all[dsItem(bb->genes,i)]->length; k++)
					{
						fprintf (fw,"%c",sequences[dsItem(all[dsItem(bb->genes,i)]->sequence,j)][k]);
						sequences_regulon[regulon_row][regulon_clo++] = sequences[dsItem(all[dsItem(bb->genes,i)]->sequence,j)][k];
					}
				}
				regulon_row++;
				regulon_clo = 0;
				fprintf (fw, "\t");
				if (po->IS_SWITCH)
                	        {
                        	        int i1=0, i2=0;
                                	for (k = 0; k<anno[dsItem(all[dsItem(bb->genes,i)]->sequence,j)]->num;k++)
	                                {
        	                                i1 = dsItem(anno[dsItem(all[dsItem(bb->genes,i)]->sequence,j)]->init,k);
                	                        i2 = dsItem(anno[dsItem(all[dsItem(bb->genes,i)]->sequence,j)]->end,k);
                        	                if ((dsItem(all[dsItem(bb->genes,i)]->position,j)) >= i1&&(dsItem(all[dsItem(bb->genes,i)]->position,j)) <= i2)
                                	        {
                                        	        reg_TF[i3++] = anno[dsItem(all[dsItem(bb->genes,i)]->sequence,j)]->TF[k];
							fprintf (fw,"%s",anno[dsItem(all[dsItem(bb->genes,i)]->sequence,j)]->TF[k]);
                                                	fprintf (fw,"_%d",dsItem(anno[dsItem(all[dsItem(bb->genes,i)]->sequence,j)]->init,k));
	                                                fprintf (fw,"_%d ",dsItem(anno[dsItem(all[dsItem(bb->genes,i)]->sequence,j)]->end,k));
        	                                }
	
        	                        }
                	        }
				fprintf (fw, "\n");
			}
		}
	}
	if (po->IS_SWITCH) 
		print_frequency_anno (fw, reg_TF, i3,kk);
	if (po->IS_reference_H)
		print_operons (fw, sequences_regulon, genome,kk,oper_num_all);
	fprintf (fw,"----------------------------------------------------\n");
/*	for (i=0;i<ver;i++)
		free (arr_c1[i]);
	free (arr_c1);*/
}
/******************************************************************/

static void print_regulon_vertical( FILE *fw,  Block* bb, int num )
{
	int i,j,kk=0;
	long int k=0;
	verboseDot();
	fprintf (fw,"\n\n*********************************************************\n");
	fprintf (fw,"Candidate Regulon %d:\t ",(num+1));
	for (i=0;i< (bb->block_rows); i++)
		 fprintf (fw,"closure %d ",(dsItem(bb->genes,i)+1));
	fprintf (fw, "\n");
	fprintf (fw,"*********************************************************\n\n");
	
	for (i=0;i<(bb->block_rows);i++)
		kk += all[dsItem(bb->genes,i)]->closure_rows;
	fprintf (fw," Motif length: %d\n Motif number: %d\n",all[dsItem(bb->genes,0)]->length,kk);
	fprintf (fw,"------------------- Aligned Motif ------------------\n");
	if (po->ID) fprintf (fw,"#Genome\tSeq\tposi\tID\tMotif\t\tAnnotation\n");
	else fprintf (fw,"#Genome\tSeq\tposi\tMotif\t\tAnnotation\n");
	sequences_regulon = alloc2c (kk,all[dsItem(bb->genes,0)]->length);
	int i3=0;
	int start=0, genome_num;
	int regulon_row=0,regulon_clo=0;
	for (i=0;i<(bb->block_rows);i++)
		i3 += get_num_TF (all[dsItem(bb->genes,i)]);
	char **reg_TF;
	reg_TF = alloc2c (i3,10);
	i3=0;
	for (i=0;i<(bb->block_rows);i++)
	{
		/*printf ("%d\t%d\n",dsItem(bb->genes,i),clo_matr1[dsItem(bb->genes,i)][0]);*/
		genome_num = get_genome_num_from_closure (all[dsItem(bb->genes,i)]);
		for (j=0; j<all[dsItem(bb->genes,i)]->closure_rows; j++)
		{
		/*	if (po->ID) fprintf (fw,"%d\t%d\t%d\t%s\t",genome_num,dsItem(all[dsItem(bb->genes,i)]->sequence,j),dsItem(all[dsItem(bb->genes,i)]->position,j)+clo_matr1[dsItem(bb->genes,i)][dsItem(bb->genes,0)],locus_id[dsItem(all[dsItem(bb->genes,i)]->sequence,j)]);
			else*/ fprintf (fw,"%d\t%d\t%d\t",genome_num,dsItem(all[dsItem(bb->genes,i)]->sequence,j),dsItem(all[dsItem(bb->genes,i)]->position,j)+clo_matr1[dsItem(bb->genes,i)][dsItem(bb->genes,0)]);
			/*adjsut closures base on p_opt and q_opt*/
/*			printf ("%d\t%d\t%d\t%d\t%d\n",dsItem(bb->genes,i),dsItem(bb->genes,0),clo_matr1[dsItem(bb->genes,i)][dsItem(bb->genes,0)],dsItem(all[dsItem(bb->genes,i)]->sequence,j),dsItem(all[dsItem(bb->genes,i)]->position,j));*/
			if (dsItem(all[dsItem(bb->genes,i)]->position,j)+clo_matr1[dsItem(bb->genes,i)][dsItem(bb->genes,0)] < 0) 
			{
				start = 0;
				for (k=0;k<dsItem(all[dsItem(bb->genes,i)]->position,j)-clo_matr1[dsItem(bb->genes,i)][dsItem(bb->genes,0)];k++)
				{
					fputc ('N',fw);
                                        sequences_regulon[regulon_row][regulon_clo++] = 'N';
				}
				for (k=dsItem(all[dsItem(bb->genes,i)]->position,j)-clo_matr1[dsItem(bb->genes,i)][dsItem(bb->genes,0)];k<all[dsItem(bb->genes,i)]->length;k++)
				{
					fprintf (fw,"%c",genome[genome_num]->sequences_r[dsItem(all[dsItem(bb->genes,i)]->sequence,j)][k]);
                                        sequences_regulon[regulon_row][regulon_clo++] = genome[genome_num]->sequences_r[dsItem(all[dsItem(bb->genes,i)]->sequence,j)][k];
				}
			}
			else if ((dsItem(all[dsItem(bb->genes,i)]->position,j)+clo_matr1[dsItem(bb->genes,i)][dsItem(bb->genes,0)]+all[dsItem(bb->genes,i)]->length) > strlen(genome[genome_num]->sequences_r[0]))  
			{
				start =dsItem(all[dsItem(bb->genes,i)]->position,j);
				for (k=(dsItem(all[dsItem(bb->genes,i)]->position,j)+clo_matr1[dsItem(bb->genes,i)][dsItem(bb->genes,0)]);k<strlen(genome[genome_num]->sequences_r[0]);k++)
				{
					fprintf (fw,"%c",genome[genome_num]->sequences_r[dsItem(all[dsItem(bb->genes,i)]->sequence,j)][k]);
                                        sequences_regulon[regulon_row][regulon_clo++] = genome[genome_num]->sequences_r[dsItem(all[dsItem(bb->genes,i)]->sequence,j)][k];
				}
				for (k=0;k<dsItem(all[dsItem(bb->genes,i)]->position,j)+clo_matr1[dsItem(bb->genes,i)][dsItem(bb->genes,0)]+all[dsItem(bb->genes,i)]->length-strlen(genome[genome_num]->sequences_r[0]);k++)
				{
					fputc ('N',fw);
                                        sequences_regulon[regulon_row][regulon_clo++]='N';
				}
			}
			else 
			{
				start = dsItem(all[dsItem(bb->genes,i)]->position,j)+clo_matr1[dsItem(bb->genes,i)][dsItem(bb->genes,0)];
				for (k=start; k< start+all[dsItem(bb->genes,i)]->length; k++)
				{
					fprintf (fw,"%c",genome[genome_num]->sequences_r[dsItem(all[dsItem(bb->genes,i)]->sequence,j)][k]);
					sequences_regulon[regulon_row][regulon_clo++] = genome[genome_num]->sequences_r[dsItem(all[dsItem(bb->genes,i)]->sequence,j)][k];
				}
			}
			regulon_row++;
			regulon_clo = 0;
			fprintf (fw, "\t");
			if (po->IS_SWITCH)
               	        {
                       	        int i1=0, i2=0;
                               	for (k = 0; k<anno[dsItem(all[dsItem(bb->genes,i)]->sequence,j)]->num;k++)
                                {
       	                                i1 = dsItem(anno[dsItem(all[dsItem(bb->genes,i)]->sequence,j)]->init,k);
               	                        i2 = dsItem(anno[dsItem(all[dsItem(bb->genes,i)]->sequence,j)]->end,k);
                       	                if ((dsItem(all[dsItem(bb->genes,i)]->position,j)) >= i1&&(dsItem(all[dsItem(bb->genes,i)]->position,j)) <= i2)
                               	        {
                                       	        reg_TF[i3++] = anno[dsItem(all[dsItem(bb->genes,i)]->sequence,j)]->TF[k];
						fprintf (fw,"%s",anno[dsItem(all[dsItem(bb->genes,i)]->sequence,j)]->TF[k]);
                                               	fprintf (fw,"_%d",dsItem(anno[dsItem(all[dsItem(bb->genes,i)]->sequence,j)]->init,k));
                                                fprintf (fw,"_%d ",dsItem(anno[dsItem(all[dsItem(bb->genes,i)]->sequence,j)]->end,k));
       	                                }	
       	                        }
               	        }
			fprintf (fw, "\n");
		}
	}
	if (po->IS_SWITCH) 
		print_frequency_anno (fw, reg_TF, i3,kk);
	if (po->IS_reference)
		print_operons (fw, sequences_regulon, genome,kk,oper_num_all);	
	fprintf (fw,"----------------------------------------------------\n");
/*	for (i=0;i<ver;i++)
		free (arr_c1[i]);
	free (arr_c1);*/
}
/******************************************************************/
