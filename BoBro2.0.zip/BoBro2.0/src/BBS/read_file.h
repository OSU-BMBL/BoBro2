#ifndef _CLOSURE_PROCESS_H
#define _CLOSURE_PROCESS_H

#include "struct.h"
/* prototypes  */
void read_sequences(FILE* fp1 );
void read_reference_genome (FILE* fp);
void read_motif_matrix(FILE* fm);
void read_motif_consensus (FILE* fp);
int scan_genome (continuous **scoreM, continuous AveScore, int motif_length, FILE* fp);
int scan_genome_markov (char **sequences,int motif_number, continuous **scoreM, continuous AveScore, int motif_length, FILE* fp);
discrete *change_AGCT_to_num (char *seq, int length);

/*from pvalue*/
extern continuous **markov (char **sequences, int seq_num);
extern continuous **getTransMatrix(char **sequences, int seq_num);
extern continuous get_trans_score(char **sequences_2, char *seq_temp, int motif_number, int length_local_1);

/*from closure_process*/
extern continuous **get_palindromic_profle (continuous **scoreM, int length_local);
extern discrete **frequency_matrix (char **sequence_temp, int a, int b, int motif_number);
extern char *get_consensus (discrete **frequency, int a, int b);
extern char *palindromic_seq (char *consensus, int length);
#endif
