#!/usr/bin/perl
use strict;
use warnings;
use Data::Dumper;
use Getopt::Std;
# this version adds a score for each promoter
sub manual {
	print "For each Ecoli gene, get its orthologs in all ref specises and the\
	corresponding promoters.\n
	Usage:\
	perl generate_ortholog_gene_promoter\
	-a Target.opr\
	-b Target.prt\
	-p Ref_prt_dir\
	-r Ref_opr_dir\
	-g ortholog_dir\
	-o output_dir\
	(option)
	-f (base on operon level, use the first gene to stand for an operon)
	\n";
	die;
}

manual unless defined $ARGV[0];

my %opt;
getopt("a:b:p:r:g:o:f", \%opt);
manual unless exists $opt{a} and exists $opt{b} and exists $opt{p} and exists $opt{r} and exists $opt{g};# and exists $opt{o};


# store gene information, use gi as the key
my %id2info;
my %id2prt;
my %id2start;
my %id2chain;
my %id2operon;
my %id2first_gene_in_operon;

# store ortholog gene relation, as a hash of hash, or spase matrix
my $ortholog_map;

open TARPRT, "$opt{'b'}" or die "Cannot open $opt{'b'}: $!";
my $gi = ''; # the gi being processing
my @gi_target; # contains all the gis of target in order
print "Start reading $opt{'b'}\n";
while(<TARPRT>) {
	chomp;
	if (s/^>//) {
		my ($NC, $gi_now, $chain, $start,$name) = (split /_/, $_)[1,2,6,9,10];
		my $info ="NC_$NC\_$chain\_$gi_now\_$start\_$name";
		$gi = $gi_now;
		$start =~ s/\.\..*//;
		$id2info{$gi} = $info;
		$id2start{$gi} = $start;
		$id2chain{$gi} = $chain;
		push @gi_target, $gi;
	} else {
		$id2prt{$gi} = $_;
	}
}
close TARPRT;
$gi = '';
print "End reading $opt{'b'}\n";


open TAR, "$opt{'a'}" or die "Cannot open $opt{'a'}: $!";
print "Start reading $opt{'a'}\n";
my @opr_target;	#contains all target oprs, element is a ref to an array
while(<TAR>) {
	chomp;
	my @opr = split;
	shift @opr;
	push @opr_target, [ @opr ];
	my $first = first_gene(@opr);
	foreach (@opr) {
		$id2operon{$_} = [ @opr ];
		$id2first_gene_in_operon{$_} = $first;
	}
}
close TAR;
print "End reading $opt{'a'}\n";


chdir "$opt{'p'}" or die "Cannot chdir to $opt{'p'}: $!";
print "Start reading ref promoter files\n";
my @ref_list =  <*>;
my $ref_num = @ref_list;
print "$ref_num promoter files found\n";
foreach my $ref (@ref_list) {
#	print "$ref\n";
	open PRT, "$ref" or die "Cannot open $ref: $!";
	while(<PRT>) {
		chomp;
		if(s/^>//) {
			my $info = $_;
			my ($gi_now, $start, $chain) = (split /_/, $info)[3,4,2];
			$gi = $gi_now;
			$start =~ s/\.\..*//;
			$id2info{$gi} = $info;
			$id2start{$gi} = $start;
			$id2chain{$gi} = $chain;
#			print "$info\n";
		} else {
			$id2prt{$gi} = $_;
		}
	}
	close PRT;
}
chdir $ENV{'PWD'} or die "Cannot chdir to $ENV{'PWD'} : $!";
print "End reading ref promoter files\n";

chdir "$opt{'r'}" or die "Cannot chdir to $opt{'r'}: $!";
print "Start reading ref operon files\n";
@ref_list = <*>;
$ref_num = @ref_list;
print "$ref_num operon files found\n";
foreach my $ref (@ref_list) {
#	print "$ref\n";
	open OPR, "$ref" or die "Cannot open $ref: $!";
	while(<OPR>) {
		chomp;
		my @opr = split;
		shift @opr;
		my $first = first_gene(@opr);
		foreach (@opr) {
			$id2operon{$_} = [ @opr ];
			$id2first_gene_in_operon{$_} = $first;
		}
	}
	close OPR;
}
chdir "$ENV{'PWD'}" or die "Cannot chdir to $ENV{'PWD'}: $!";
print "End reading ref operon files\n";


chdir "$opt{'g'}" or die "Cannot chdir to $opt{'g'}: $!";
print "Start reading ortholog files\n";
@ref_list = <*>;
$ref_num = @ref_list;
print "$ref_num ortholog files found\n";
foreach my $ref (@ref_list) {
#	print "$ref\n";
	open ORT, "$ref" or die "Cannot open $ref: $!";
	while(<ORT>) {
		chomp;
		my $g2o = (split)[0];
		my ($gene, $ortholog) = split /,/, $g2o;
		$ortholog_map->{$gene}{$ortholog} = 1;
	}
	close ORT;
}
chdir "$ENV{'PWD'}" or die "Cannot chdir to $ENV{'PWD'}: $!";
print "End reading ortholog files\n";
#print Dumper $ortholog_map;

if( exists $opt{o}) {
# begin to output
	chdir "$opt{o}" or die "Cannot chdir to $opt{o}: $!";
	print "Start writing ortholog promoter files\n";
	if( exists $opt{f} ) {
# with -f option, use the first gene to stand for operon
# when consider a promoter of a gene, get the first gene's promoter of the operon
# it lies in.

		foreach my $opr (@opr_target) {
			my $first = $id2first_gene_in_operon{${$opr}[0]};
#			print "$first\n";
			my @orthologs = ();
			foreach my $g (@$opr) {
				push @orthologs,( keys %{$ortholog_map->{$g}} );
			}
			@orthologs = map( $id2first_gene_in_operon{$_}, @orthologs);
			@orthologs = unique_ele(@orthologs);

			open OUT, ">$first" or die "Cannot open $first: $!";
			print OUT ">$id2info{$first}_2\n";
			print OUT "$id2prt{$first}\n";

			foreach (@orthologs) {
				my ($match_score, $match_num, $t_num,$r_num);
				$t_num = @$opr;
				$r_num = @{$id2operon{$_}};
				foreach my $a (@$opr) {
					foreach my $b (@{$id2operon{$_}}) {
						$match_num += $ortholog_map->{$a}{$b} if exists $ortholog_map->{$a}{$b};
					}
				}
				$match_score = $match_num/($t_num+$r_num-$match_num);
				print OUT ">$id2info{$_}_$match_score\n";
				print OUT "$id2prt{$_}\n";
			}
			close OUT;
		}


	} else {
		#for each gene, its real promoter is the promoter of the operon it lies in

		foreach (@gi_target) {
#	print "$_\n";
			open OUT, ">$_" or die "Cannot open $_: $!";
			print OUT ">$id2info{$_}\n";
			print OUT "$id2prt{$id2first_gene_in_operon{$_}}\n";

			my @ort = keys %{$ortholog_map->{$_}};
			@ort = map($id2first_gene_in_operon{$_}, @ort);
			foreach my $ort_id (@ort) {
				print OUT ">$id2info{$ort_id}\n";
				print OUT "$id2prt{$ort_id}\n";
			}

			close OUT;
		}
	}
	chdir "$ENV{'PWD'}" or die "Cannot chdir to $ENV{'PWD'} :$!";
	print "End writing ortholog promoter files\n";

}
###################################### sub ##################################
sub first_gene {
	# this sub return the first gene of an operon with the asumation that
	# all genes are on the same chain
	my @genes = @_;

	if(@genes == 1) {
		return $genes[0];
	}

	@genes = sort { $id2start{$a} <=> $id2start{$b} } @genes;
	my $chain = $id2chain{$genes[0]};
	if($chain eq '+') {
		return shift @genes;
	} else {
		return pop @genes;
	}
}

sub unique_ele {
	# for an array, need not to be sorted, this sub removes the duplicate
	# elements in it then return the array
	my %saw;
	my @ret = grep(!$saw{$_}++, @_); # remove duplicate
	return @ret;
}

