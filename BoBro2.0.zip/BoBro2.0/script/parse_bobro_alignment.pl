#!/usr/bin/perl
#
# parse out the bobor motif finding result, generate a alignment file ready for BBS
# reading stdin, write stdout

use strict;
use warnings;

my $motif_now ;
my $seed_flag = 0;
my @seeds;

while(<>) {
    chomp;
    if( /Candidate Motif\s*([0-9]+)$/ ) {
	
	#print map {"$_\n"} @seeds;
	conditional_seed_output();
	$motif_now = "Motif-$1";
	print "$motif_now\n";

    } elsif ( /Motif Seed/ ) {
	#print "$_\n";
	$seed_flag = 1;
    } elsif ( /^$/ ) {
	$seed_flag = 0;
    } elsif( $seed_flag ) {
	#print "$_\n";
	push @seeds, $_;
    } else {
	next;
    }

}

conditional_seed_output();


sub conditional_seed_output {
    #my $seed_num = @seeds;
    if (@seeds) {
	open OUT, ">$motif_now" or die "Cannot open $motif_now: $!";
	print OUT ">$motif_now\n";
	print OUT map {"$_\n"} @seeds;
	print OUT ">end\n";

	undef @seeds;
    }
}

