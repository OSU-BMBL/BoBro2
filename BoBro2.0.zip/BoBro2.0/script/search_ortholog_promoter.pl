#!/usr/bin/perl
#
#Description: pick out the orthology genes of each gene in a closure and search with the corresponding seed
#
#

use strict;
use warnings;
use Data::Dumper;
use File::Basename;

my $closuer_dir = ".";
my @seed_list = @ARGV;

my $promoter_dir = $ARGV[0];
my $fna_dir = $ARGV[1];

my $promoter_hash;
# $promoter_hash->{$spe}{$gene} = promoter;
my @promoter_list = <$promoter_dir/*>;

foreach my $gene (@promoter_list) {
    #print $gene, "\n";
    open IN, "$gene" or die "Cannot open $gene: $!";

    my $spe_now;
    while(<IN>) {
	chomp;
	if (/>(NC_[0-9]+)_/) {
	    $spe_now = $1;
	} else {
	    my $g = basename($gene);
	    $promoter_hash->{$spe_now}{$g} = $_;
	}
    }
    close IN;
}
#print Dumper $promoter_hash;

#delete $promoter_hash->{"NC_000913"};
my @specise = keys (%{$promoter_hash});

foreach my $seed (@seed_list) {

    open OUT, ">$seed.result" or die "Cannot open $seed.result: $!";

    my $closure_file = "$closuer_dir/inter_operonic_region_300_$seed.motifinfo";
    my @gene_list;
    open IN, $closure_file or die "Cannot open $closure_file: $!";
    while(<IN>) {
	chomp;
	next unless />/;
	my $info = (split)[6];
	my $id = (split /_/, $info)[1];
	push @gene_list, $id;
    }
    close IN;

    foreach my $spe (@specise) {

	my @orth_gene_list = grep { defined $promoter_hash->{$spe}{$_} } @gene_list;

	### control 
	next unless (@orth_gene_list > @gene_list / 2 or @orth_gene_list > 20);

	open PRO, ">$seed\_$spe" or die "Cannot open $seed\_$spe: $!";
	foreach my $g (@orth_gene_list) {
	    #next unless defined $promoter_hash->{$spe}{$g};
	    print PRO ">$g\n";
	    print PRO $promoter_hash->{$spe}{$g}, "\n";
	}
	close PRO;

	## run BBS ###
	system( "BBS -i $seed\_$spe -j $seed -z $fna_dir/$spe.fna -E");

	## parse score
	my ($pvalue, $zscore, $escore) = read_zscore("$seed\_$spe\_$seed.motifinfo");
	if($pvalue and $zscore) {
	print OUT "$spe\t$pvalue\t$zscore\t$escore\n";
    } else {
	print OUT "$spe\t-\t-\t-\n";
    }

	### clean up ####
	unlink("$seed\_$spe");
	unlink("$seed\_$spe\_$seed.motifinfo");


    }
    close OUT;

}

#### sub ####
sub read_zscore {
    my ($file) = @_;

    my ($p, $z, $e);

    open IN, $file or warn "Cannot open $file: $!";
    while(<IN>) {
	chomp;
	if(/Zscore:/) {
	    $z = $_;
	} elsif(/Enrichment:/) {
	    $e = $_;
	} elsif (/Pvalue:/) {
	    $p = $_;
	} else {
	    next;
	}
    }

    return ($p, $z, $e);
}
