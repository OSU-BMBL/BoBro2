#ifndef _CLOSURE_PROCESS_H
#define _CLOSURE_PROCESS_H

#include "struct.h"
/*prototypes*/
discrete **frequency_matrix (char **sequence_temp, int a, int b, int motif_number);
continuous **get_profile (char **sequence_temp, int a, int b, int motif_number);
continuous **impovre_profle (continuous **scoreM, double length_local_1);
continuous **get_palindromic_profle (continuous **scoreM, int length_local);
char *get_consensus (discrete **frequency, int a, int b);
void compare_motif (const char* fn);
continuous *get_column_IC (int length,  int number, int motif_num);
continuous *get_column_IC_12 (int startpos_1, int startpos_2, int num_a, int num_b, int motif_1, int motif_2, int motif_number);
continuous *get_column_IC_21 (int startpos_1, int startpos_2, int num_a, int num_b, int motif_1, int motif_2, int motif_number);
char *palindromic_seq (char *consensus, int length);

/* global data */
int col_width;
Edge **edge_list;
Edge *edge_ptr;
extern bits16 **profile;
#endif
