# the script is used to combine the operon files of a same species
#! /usr/bin/perl -w
use strict;

my ($file_list, $operondir, $outputdir);
if (!$ARGV[0]) { print "the script is used to combine the operon files of a same species\nperl combine_operonfile.pl -i files_list_faa -j operondir -o combined_operondir\n"; die ;}
for (my $i=0; $i<@ARGV; ++$i) {
        if ($ARGV[$i] eq "-i") {if ($ARGV[$i+1]) {$file_list = $ARGV[$i+1];}         else {print "wrong input format (-i)\n"; printmanul(); die "exit.\n";} }
        if ($ARGV[$i] eq "-j") {if ($ARGV[$i+1]) {$operondir = $ARGV[$i+1];}         else {print "wrong input format (-j)\n"; printmanul(); die "exit.\n";} }
        if ($ARGV[$i] eq "-o") {if ($ARGV[$i+1]) {$outputdir = $ARGV[$i+1];}         else {print "wrong input format (-o)\n"; printmanul(); die "exit.\n";} }
}

open (fp, "$file_list") || die "$!";
chomp (my @operon_list = <fp>);
close fp;

my ($operon_max, $operon_max_NC);
for (my $i = 0; $i < @operon_list; $i++){
	chomp (my @operon_temp = split (/\t/,$operon_list[$i]));
	if ($i ==0 ){
		$operon_max = $operon_temp[0];
		$operon_max_NC = $operon_temp[2];
		if (-e "$outputdir/$operon_max_NC"){
			system ("$outputdir/$operon_max_NC");
		}
		print "$operon_temp[2].opr\n";
		system ("cat $operondir/$operon_temp[2].opr > $outputdir/$operon_temp[2].opr");
	}else{
		if ($operon_temp[0] eq $operon_max){
			system ("cat $operondir/$operon_temp[2].opr >> $outputdir/$operon_max_NC.opr");
		}else{
			system ("cat $outputdir/$operon_max_NC.opr | wc -l > temp_num");
			open(fp2,'temp_num')|| die "$!";
			chomp (my $operon_num = <fp2>);
			close fp2;
			system ("seq $operon_num | paste -d '\t' - $outputdir/$operon_max_NC.opr |cut -d '\t' -f1,3 > $outputdir/$operon_max_NC.opr.new; mv $outputdir/$operon_max_NC.opr.new $outputdir/$operon_max_NC.opr; rm temp_num");
			$operon_max = $operon_temp[0];
			$operon_max_NC = $operon_temp[2];
			if (-e "$outputdir/$operon_max_NC"){
	                        system ("$outputdir/$operon_max_NC");
        	        }
			print "$operon_temp[2].opr\n";
			system ("cat $operondir/$operon_temp[2].opr > $outputdir/$operon_temp[2].opr");
		}
	}
}
system ("cat $outputdir/$operon_max_NC.opr | wc -l > temp_num");
open(fp2,'temp_num')|| die "$!";
chomp (my $operon_num = <fp2>);
close fp2;
system ("seq $operon_num | paste -d '\t' - $outputdir/$operon_max_NC.opr |cut -d '\t' -f1,3 > $outputdir/$operon_max_NC.opr.new; mv $outputdir/$operon_max_NC.opr.new $outputdir/$operon_max_NC.opr; rm temp_num");
