#ifndef _MOTIF_SEARCH_H
#define _MOTIF_SEARCH_H

#include "struct.h"

/*prototypes*/
void validation_motif(const char* fn);

/*from write_file*/
extern void report_closures(FILE *fw, Closures** cc, int num);

/*from closure_process*/
extern continuous **get_profile (char **sequence_temp, int a, int b, int motif_number);
extern discrete **frequency_matrix (char **sequence_temp, int a, int b, int motif_number);
extern continuous **impovre_profle (continuous **scoreM, double length_local_1);
extern char *get_consensus (discrete **frequency, int a, int b);
extern continuous **get_palindromic_profle (continuous **scoreM, int length_local);
extern char *palindromic_seq (char *consensus, int length);

/*from pvalue*/
extern continuous aver_score_closure(char **sequences_2, continuous **scoreM, continuous *score, int motif_number, int length_local_1);
extern continuous aver_score_closure_markov(char **sequences_2, continuous **scoreM, continuous *score, int motif_number, int length_local_1);
extern continuous get_trans_score(char **sequences_2, char *seq_temp, int motif_number, int length_local_1);

/*from read_file*/
extern int scan_genome (continuous **scoreM, continuous AveScore, int motif_length, FILE* fp);
extern int scan_genome_markov (char **sequences,int motif_number, continuous **scoreM, continuous AveScore, int motif_length, FILE* fp);
extern discrete *change_AGCT_to_num (char *seq, int length);
#endif
