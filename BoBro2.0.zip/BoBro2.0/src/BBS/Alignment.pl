#!/usr/local/bin/perl -w

if (!$ARGV[0]) {
        die "perl Alignment.pl InputSeq PredictedMotif Result\n";
}


system "./clustalw -infile=$ARGV[0] -outorder=input >temp_screen";

my $Align_file=$ARGV[0].".aln";
my $Motif_file=$ARGV[1];
my $Result_file=$ARGV[2];

open (fp1, "<$Motif_file") or die "Can not open datafile $Motif_file ....exit\n";
my @motif=<fp1>;close fp1;



my @data;                  #which store the motif position information;
my $motif_rank=0; 
my $signal_1=0;
my @array;
my $line;

for ($i=0;$i<@motif;$i++){
	$line=$motif[$i]; chomp $line;
	if ($line =~ /Alignment/){
		$motif_rank++; #$motif_num=0;
		#print "$line\n";
	}
	if ($line =~ /----/){
		$signal_1=0;
	}
	if ($signal_1==1){
		#print "$line\n";
		@array=split (/ |\t/,$line);
		for (my $j=0;$j<length($array[2]);$j++){
			$data[$array[0]][$array[1]+$j]=$motif_rank unless $data[$array[0]][$array[1]+$j];
		}
	}
	if ($line =~ /#Seq/){
		$signal_1=1;
	}

}

open (fp1, "<$Align_file") or die "Can not open datafile $Align_file ....exit\n";
my @Align=<fp1>;close fp1;

open (fp1, ">$Result_file") or die "Can not open datafile $Result_file ....exit\n";
print fp1 "\nAligned input sequences with predicted motifs marked:";

$signal_1=0;
my $signal_2=0;
my $signal_3=0;
my @posi;
my $seq;

for ($i=0;$i<@Align;$i++){
	$line=$Align[$i]; chomp $line;
	if ($line =~ /CLUSTAL/){next;}
	print fp1 "$line\n";
	$signal_1=1 unless $line;
	next unless $line;
	
	if ($signal_1==1) {
		$signal_1=0;
		$seq=0;
	}else{
		$seq++;
	} 
	
	$posi[0][$seq]=0 unless $posi[0][$seq];
	$posi[1][$seq]=0 unless $posi[1][$seq];
	$signal_2=0;
	$signal_3=0;
	for (my $j=0;$j<length($line);$j++){
		if (substr($line,$j,1) eq " "){$signal_2=1;}
		if ($signal_2==1 && substr($line,$j,1) ne " "){
			$signal_3=1;
			if ($data[$seq][$posi[1][$seq]] && $data[$seq][$posi[1][$seq]]<10 && substr($line,$j,1) ne "-"){
				print fp1 "$data[$seq][$posi[1][$seq]]";
			}else{
				print fp1 " ";
			}
			$posi[0][$seq]++;
			$posi[1][$seq]++ unless (substr($line,$j,1) eq "-");
		}else{
			print fp1 " ";
		}	
	}
	print fp1 "\t$posi[1][$seq]\t$posi[0][$seq]\n" if $signal_3;

}
close fp1;
