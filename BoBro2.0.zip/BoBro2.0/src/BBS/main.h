#ifndef _MAIN_H
#define _MAIN_H

#include "struct.h"
extern void read_sequences (FILE* fp1);
extern int get_options (int argc, char* argv[]);
extern void read_motif_alignment(FILE* fa);
extern void validation_motif(const char* fn);
extern void read_motif_matrix(FILE* fm);
extern void read_motif_consensus (FILE* fp);
extern void compare_motif (const char* fn);
#endif
