#!/usr/local/bin/perl -w
#
if (!$ARGV[0]) {
	print "USAGE: perl BBC.pl SequenceFile [MotifFile TypeOfMotif background] ....\n\n";
	print "Only have sequences? please type:\n\n\tperl BBC.pl SequenceFile 0 0\n\n";
	print "Motifs provided? please type:\n\n\tperl BBC.pl SequenceFile MotifFile TypeOfMotif[1/2/3] \n";
	print "\t(TypeOfMotif: 0:BOBRO 1:alignment; 2:matrix; 3:consensus)\n";
	print "\nIf want to change thresholds T1 and T2 (Defaults: 0.88 and 0.95) in clustering, please add the numbers you prefer to the end of the command. e.g.\n";
	print "\n\tperl BBC.pl SequenceFile MotifFile TypeOfMotif[1/2/3] 0.89 0.96\n";
	print "\nPlease go to README-BBC file for further details.\n";
	exit(1); 

}

mkdir "$ARGV[0].BBC" unless -e "$ARGV[0].BBC";

#1. to generate the similarity score matrix of all the known TFs in RegulonDB
#	perl BBC.pl TFBS_formated.txt 1
#2. BBC...         promoters_motif_alignment.motifinfo

my $T1=0.88; my $T2= 0.95;if ($ARGV[3]){$T1=$ARGV[3];} if ($ARGV[4]){$T2=$ARGV[4];}
if ($ARGV[1]) {
print "\n----------------------------\nWelcome to use BBC Annotation!!\n----------------------------\n\n";

if ($ARGV[2]) {
	print "\nKnown database motifs provided, will run BBS to search firstly:\n\nRunning BBS....\n";
	system ("perl BBS.pl $ARGV[1] $ARGV[0] $ARGV[2] > temp_screen");
	$name=$ARGV[0]."_".$ARGV[1].".motifinfo";
	system ("perl  bin/Format.pl $name BBS >$ARGV[0].BBC/$ARGV[0].$ARGV[1]");
}else{
	print "\nBoBro output motifs provided, will directly run BBC:\n";
	system ("perl bin/Format.pl $ARGV[1] BoBro >$ARGV[0].BBC/$ARGV[0].$ARGV[1]");
}


print "\nRunning BBC to compare motifs....\n";
system ("perl  bin/BBC.pl $ARGV[0].BBC/$ARGV[0].$ARGV[1] 1 >temp_screen");

print "\nRunning MST to cluster motifs...\n";
system ("perl bin/BBC1_motifClu.pl $ARGV[0].BBC/$ARGV[0].$ARGV[1].similarity $ARGV[0].BBC/$ARGV[0].$ARGV[1].MC $T1 $T2 >temp_screen");

print "\nRunning ClustalW and final annotation...\n\n";
system ("perl bin/BBC2_clu_Anno.pl $ARGV[0] $name $ARGV[0].BBC/$ARGV[0].$ARGV[1].BBC $ARGV[0].BBC/$ARGV[0].$ARGV[1].MC BBS");

print "The Result about motif comparison is in '$ARGV[0].BBC/$ARGV[0].$ARGV[1].similarity'\n";
print "The Result about motif cluster and annotation is in '$ARGV[0].BBC/$ARGV[0].$ARGV[1].BBC'\n\n";
system ("mv $name $ARGV[0].BBC/");
exit;
}


#my $input=$ARGV[0];  #matrix
#my $output=$ARGV[1];	#clusters

#open (fp1, "<$input") or die "Can not open datafile $input ....exit\n";
#my @data=<fp1>;close fp1;

#my @m_s; #matrix_score
#my @m_s1=@m_s; #matrix_score_changea


#exit;

print "\n----------------------------\nWelcome to use BBC!!\n----------------------------\n\nNo motif files input, will run BoBro in default parameters to predict firstly:\n\nRunning BoBro....\n";

system ("./bin/BoBro -i $ARGV[0] -o 10  > temp_screen");

system ("perl bin/Format.pl $ARGV[0].closures BoBro >$ARGV[0].BBC/$ARGV[0]");

print "\nRunning BBC to compare motifs....\n";
system ("perl bin/BBC.pl $ARGV[0].BBC/$ARGV[0] 1 >temp_screen");

print "\nRunning BBC1 to cluster motifs...\n";
system ("perl bin/BBC1_motifClu.pl $ARGV[0].BBC/$ARGV[0].similarity $ARGV[0].BBC/$ARGV[0].MC $T1 $T2> temp_screen");

print "\nRunning ClustalW and final annotation...\n\n";
system ("perl bin/BBC2_clu_Anno.pl $ARGV[0] $ARGV[0].closures $ARGV[0].BBC/$ARGV[0].BBC $ARGV[0].BBC/$ARGV[0].MC BoBro");

system ("mv $ARGV[0].closures $ARGV[0].BBC/");
print "The Result about motif prediction is in '$ARGV[0].BBC/$ARGV[0].$ARGV[0].closures'\n";
print "The Result about motif comparison is in '$ARGV[0].BBC/$ARGV[0].similarity'\n";
print "The Result about motif cluster and annotation is in '$ARGV[0].BBC/$ARGV[0].BBC'\n\n";




