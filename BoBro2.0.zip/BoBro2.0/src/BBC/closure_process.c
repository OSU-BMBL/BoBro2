/************************************************************************/
/* Author: Qin Ma <maqin@csbl.bmb.uga.edu>, Feb. 16, 2010
 * all the related process of closures are stored in the file        
 */


#include "closure_process.h"
static const int HEAP_SIZE = 3000000;
/************************************************************************/
void combine_closures(Closures **aa, int closure_id, continuous threshold, const char* fn, const char* fn1)
/*in order to reduce time complexity*/
{
	FILE *fw = mustOpen(fn, "w");
	FILE *fw1 = mustOpen(fn1, "w");

	/*==========================state the initail variables and memory===========================================================*/
	bool *IS_duplicate; /*remove duplicate from the closures which are corresponding to a common operon*/
	AllocArray (IS_duplicate,closure_id);
	clo_matr1 = alloc2d (closure_id,closure_id);
	discrete **matrix;/*store the 0-1 matrix used to find clique*/
        matrix = alloc2d (closure_id,closure_id);
	continuous **matrix_score;
	matrix_score = alloc2dd (closure_id,closure_id);
	int i,j,ii,jj,num_a,num_b;
	continuous *species_overlap_num, species_per;
	AllocArray(species_overlap_num,2);
	species_overlap_num[0]=species_overlap_num[1]=0;

	for (i=0;i<closure_id;i++)
		IS_duplicate[i] = FALSE;

	int p_opt=0,q_opt=0;
	for (ii=0;ii<(closure_id);ii++)
        {
                for (jj=0;jj<closure_id; jj++)
		{
                        matrix[ii][jj] = 0;
			matrix_score[ii][jj] = 0;
			clo_matr1[ii][jj] = 0;
		}
                matrix[ii][ii]=1;
        }
	int p,q;
	continuous IC_1=0,IC_2=0,IC_12=0,IC_21=0,IC_temp =0,similarity=-10;
	/*fre corresponding to frequency matirx and sco corresponding to PWM*/
	fre_all = (discrete***)malloc(sizeof(discrete**)*closure_id);
	fre2_all = (discrete***)malloc(sizeof(discrete**)*closure_id);
	sco_all = (continuous***)malloc(sizeof(continuous**)*closure_id);
	sco2_all = (continuous***)malloc(sizeof(continuous**)*closure_id);
	char **sequence_aa_1, **sequence_aa_2;
	for (i=0;i<closure_id;i++)
	{
		fre_all[i] = alloc2d (5, aa[i]->length);
		fre2_all[i] = alloc2d (5, 2*aa[i]->length);
		sco_all[i] = alloc2dd (5, aa[i]->length);
		sco2_all[i] = alloc2dd (5, 2*aa[i]->length);
	}
	for (i=0;i<closure_id;i++)
	{
		sequence_aa_1 = get_sequences_from_closures (aa[i]);
		sequence_aa_2 = get_2L_sequeces_from_closures (aa[i]);
		fre_all[i] = frequency_matrix (sequence_aa_1, 5, aa[i]->length, aa[i]->closure_rows);
		fre2_all[i] = frequency_matrix (sequence_aa_2, 5, 2*aa[i]->length, aa[i]->closure_rows);
		num_a = get_genome_num_from_closure (aa[i]);
		sco_all[i] = get_profile (sequence_aa_1,genome[num_a]->markov_matrix, 5, aa[i]->length, aa[i]->closure_rows);
		/*improve the profile by decreasing the middle part of motif*/
		sco_all[i] = impovre_profle (sco_all[i],aa[i]->length);
		sco2_all[i] = get_profile (sequence_aa_2, genome[num_a]->markov_matrix, 5, 2*aa[i]->length, aa[i]->closure_rows);
	}

	int forepart, endpart;
	double length_local_1;
	int min_length = 0;
	continuous *I_11, *I_22;
	continuous SimilarityScore = 0;
	int top_closures=0;
	/*====================================================================================================================*/

	/*==========================compare each pair of closures=============================================================*/
	for (ii=0,IC_1=0;ii<(closure_id-1);ii++,IC_1=0)
        {
		if (IS_duplicate[ii]) continue;
		
		length_local_1 = aa[ii]->length;
		num_a = get_genome_num_from_closure (aa[ii]);
		forepart=floor(length_local_1/3),endpart=ceil(length_local_1/3);
		
		I_11 = get_column_IC (aa, ii, num_a);
		for (j=floor(length_local_1/2); j<floor(length_local_1/2)+length_local_1;j++)
		{
			IC_1 = IC_1 + 2*I_11[j]*I_11[j];
		}
		SimilarityScore = 0;

		/*loop for the other clousres*/
		for (jj=ii+1,IC_2=0;jj<closure_id; jj++,IC_2=0,similarity = -10)
                {
			
			/*here, we just compare the closures with same length, of courese can extend to compare different length omitting the following line*/
	                if (ABS(aa[jj]->length - aa[ii]->length)>2) continue;

                        min_length = MIN(aa[jj]->length, aa[ii]->length);
			num_b = get_genome_num_from_closure (aa[jj]);

			/*calculate the evolution information*/
			species_overlap_num = get_species_overlap_num (ii,jj,num_a, num_b);

			length_local_1 = aa[jj]->length;	
			I_22 = get_column_IC (aa, jj, num_b);
	                for (j=floor(length_local_1/2); j<floor(length_local_1/2)+length_local_1;j++)
			{        
				IC_2 = IC_2 + 2*I_22[j]*I_22[j];
			}

			int startpos[2], start, mos=0;
			continuous *I_12, *I_21;
			for(startpos[0]=0,startpos[1]=aa[jj]->length; startpos[1]>0||startpos[0]<aa[ii]->length; mos=0)
                        {
				/*printf ("1: %d\t%d\t%d\t%d\t%.2f\t%.2f\t%.2f\t%.2f\n", ii, jj , startpos[0], startpos[1], IC_1, IC_2, IC_12, IC_21);*/
				I_12 = get_column_IC_12 (aa, ii, jj, startpos[0], startpos[1] ,num_a,num_b);
				I_21 = get_column_IC_21 (aa, ii, jj, startpos[0], startpos[1], num_a, num_b);
				IC_21=IC_12=0;
                                for (start = mos; start < mos+min_length; start++)
				{
					if (I_12[start] > 0) 
						IC_12 = IC_12 + 2*I_12[start]*I_22[startpos[1]+start];
                                        else 
						IC_12 = IC_12 + I_12[start]*I_22[startpos[1]+start];
                                        if (I_21[start] > 0) 
						IC_21 = IC_21 + 2*I_21[start]*I_11[startpos[0]+start];
                                        else 
						IC_21 = IC_21 + I_21[start]*I_11[startpos[0]+start];
					/*we just consider the positions with IC > 0*/
					/*if (I_12[start] > 0) IC_12 = IC_12 + 2*I_12[start]*I_22[startpos[1]+start];
					if (I_21[start] > 0) IC_21 = IC_21 + 2*I_21[start]*I_11[startpos[0]+start];*/
					/*if (I_12[start] > 0) IC_12 = IC_12 + I_12[start]*I_22[startpos[1]+start];
                                        else IC_12 = IC_12 + I_12[start]*I_22[startpos[1]+start];
                                        if (I_21[start] > 0) IC_21 = IC_21 + I_21[start]*I_11[startpos[0]+start];
                                        else IC_21 = IC_21 + I_21[start]*I_11[startpos[0]+start];*/
				}
				IC_temp = (IC_12 + IC_21)/(IC_1 + IC_2);
				if (IC_temp > similarity)
				{
					similarity = IC_temp;
                                        p_opt = startpos[0] + mos;
                                        q_opt = startpos[1] + mos;
				}
				/*printf ("4: %d\t%d\t%d\t%d\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\n", ii, jj , startpos[0], startpos[1], IC_1, IC_2, IC_12, IC_21, IC_temp, similarity);*/
				/*slide the windows when the overlap region is longer than min_length*/
				for(p=startpos[0]+1,q=startpos[1]+1, IC_21=IC_12=0;p< aa[ii]->length+1 && q< aa[jj]->length+1;p++,q++,IC_21=IC_12=0)
                                {
                                	mos++;
					for (start = mos; start < mos+min_length; start++)
                                	{
                	                	if (I_12[start] > 0) IC_12 = IC_12 + 2*I_12[start]*I_22[startpos[1]+start];
	                                        else IC_12 = IC_12 + I_12[start]*I_22[startpos[1]+start];
        	                                if (I_21[start] > 0) IC_21 = IC_21 + 2*I_21[start]*I_11[startpos[0]+start];
                	                        else IC_21 = IC_21 + I_21[start]*I_11[startpos[0]+start];
						/*we just consider the positions with IC > 0*/
				/*		if (I_12[start] > 0) IC_12 = IC_12 + 2*I_12[start]*I_22[startpos[1]+start];
						if (I_21[start] > 0) IC_21 = IC_21 + 2*I_21[start]*I_11[startpos[0]+start];					*/
						/*if (I_12[start] > 0) IC_12 = IC_12 + I_12[start]*I_22[startpos[1]+start];
	                                        else IC_12 = IC_12 + I_12[start]*I_22[startpos[1]+start];
        	                                if (I_21[start] > 0) IC_21 = IC_21 + I_21[start]*I_11[startpos[0]+start];
                	                        else IC_21 = IC_21 + I_21[start]*I_11[startpos[0]+start];*/
					}
					IC_temp = (IC_12 + IC_21)/(IC_1 + IC_2);
					if (IC_temp > similarity)
                                	{
                                        	similarity = IC_temp;
	                                        p_opt = startpos[0] + mos;
        	                                q_opt = startpos[1] + mos;
                	                }		
				}
                                if(startpos[1]>0) startpos[1]--;
                                else startpos[0]++;
				free (I_12);
				free (I_21);
                        }
			free (I_22);
			/*update the matrix and clo_matr1 which save 0-1 and relative position, respectively*/
			/*consider the evolution information by species_per -E*/
			if (po->expansion)
			{
				if (sameString(all[ii]->name, all[jj]->name))
					species_per = 0.05;
				else
					species_per = species_overlap_num[0]/species_overlap_num[1];		
				matrix_score[ii][jj] = similarity*similarity*species_per;
				matrix_score[jj][ii] = similarity*similarity*species_per;
			}
			else
			{
				matrix_score[ii][jj] = similarity;
	                        matrix_score[jj][ii] = similarity;
			}

			if (similarity > SimilarityScore)
				SimilarityScore = similarity;

			/*consider the position variance of each closures, we suppose the good closures should have a low variance of motif positions*/
			/*matrix_score[ii][jj] = matrix_score[ii][jj]/(all[ii]->posi_var + all[jj]->posi_var);
			matrix_score[jj][ii] = matrix_score[ii][jj];*/
			clo_matr1[ii][jj] = p_opt - q_opt;
	                clo_matr1[jj][ii] = q_opt - p_opt;
                }
		free (I_11);
		/*print the SimilarityScore of top 3 closures for each operon*/
		if (ii>0 && sameString(all[ii]->name, all[ii-1]->name) && top_closures<1)
		{
			top_closures++;
		}
		if (top_closures==1 && !sameString(all[ii]->name, all[ii-1]->name))
		{
			top_closures = 0;
			top_closures++;
		}	
		if ((ii+1)%10==0) verboseDot();
        }
	/*=============================================================================================================*/

	/*build the operon matrix base on matrix_score*/
	get_z_score_matrix (matrix_score, closure_id, oper_num_all, fw, species_name, species_overlap_num[0]);

	/*========================================redundant code========================================================*/
	/*print out the similarity scores*/
	fprintf (fw1, "similarity\t");
	for (i=0;i<closure_id;i++)
		fprintf (fw1, "%d\t",i+1);
	fprintf (fw1, "\n");
	for (i=0;i<closure_id;i++)
	{
		fprintf (fw1, "%d\t",i+1);
		for (j=0;j<closure_id;j++)
			fprintf (fw1, "%3.2f\t",matrix_score[i][j]);
		fprintf (fw1, "\n");
	}
	/*==============================================================================================================*/
	/*print out the matrix*/
	/*printf ("\no\t");
        for (i=0;i<closure_id;i++)
                printf ("%d\t",i);
        printf ("\n");
        for (i=0;i<closure_id;i++)
        {
                printf ("%d\t",i);
                for (j=0;j<closure_id;j++)
   		        printf ("%d\t",clo_matr1[i][j]);
                printf ("\n");
        }*/
	
	/*========================================free the space=================================================*/
	for (i=0;i<closure_id;i++)
	{
		for (j=0;j<5;j++)
		{
			free (fre_all[i][j]);
			free (sco_all[i][j]);
		}
		free (fre_all[i]);
                free (sco_all[i]);
	}
	free (fre_all);
        free (sco_all);
	for (i=0;i<closure_id;i++)
        {
                for (j=0;j<5;j++)
                {
                        free (fre2_all[i][j]);
                        free (sco2_all[i][j]);
                }
                free (fre2_all[i]);
                free (sco2_all[i]);
        }
        free (fre2_all);
        free (sco2_all);
	free (IS_duplicate);
	free (species_overlap_num);
	fclose (fw);
	fclose (fw1);
	/*=========================================================================================================*/
}
/************************************************************************/
void get_z_score_matrix (continuous **matrix_score, int closure_id, int oper_num_all, FILE *fw1, char **species_name, int species_num)
{
	/*==========================state the initail variables and memory===========================================================*/
	int i,j,i1,j1,edge_num;
        char operon_name[20];
        Annotation *operon;
        AllocVar(operon);
        operon->init = dsNew(oper_num_all+1);
        operon->TF = alloc2c (oper_num_all ,10);
        strcpy(operon->TF[0],all[0]->name);
        j=1;
        strcpy(operon_name,all[0]->name);
        dsPush(operon->init,0);
        for (i=1;i<closure_id; i++)
        {
                if (sameString(all[i]->name,operon_name)) continue;
                else
                {
                        strcpy(operon->TF[j],all[i]->name);
                        dsPush(operon->init,i);
                        strcpy(operon_name,all[i]->name);
                        j++;
                }
        }
        dsPush(operon->init , closure_id);
        int max_edge_v1 = 0 , max_edge_v2 = 0, top =0 , top_index = 0, second_edge_v1 = 0, second_edge_v2 = 0;

	discrete **max_v1, **max_v2;
	max_v1 = alloc2d (oper_num_all, oper_num_all);
	max_v2 = alloc2d (oper_num_all, oper_num_all);

	discrete **second_v1, **second_v2;
	second_v1 = alloc2d (oper_num_all, oper_num_all);
	second_v2 = alloc2d (oper_num_all, oper_num_all);
        
	init_dis_operon();
        continuous *edge_weight, matrix_score_temp=0, edge_max=0,edge_average = 0,edge_var, /*edge_var_max = 0,*/ pvalue_1=0 , pvalue_2=0/*, rank =0 , pvalue_weight = 0*/;
	/*=======================================================================================================================*/

	/*=========================================compair each pair of operons===================================================*/
        for (i=0;i<oper_num_all-1;i++,edge_max=0)
        {
                for (j=i+1;j<oper_num_all;j++,edge_max=0)
                {
                        pvalue_1 = -(100*log(all[dsItem(operon->init,i)]->significance)) - (100*log(all[dsItem(operon->init,j)]->significance));
			AllocArray (edge_weight,(dsItem(operon->init,i+1)-dsItem(operon->init,i))*(dsItem(operon->init,j+1)-dsItem(operon->init,j)));
                        edge_num = 0;
			for (i1=dsItem(operon->init,i);i1<dsItem(operon->init,i+1);i1++)
                        {
                                for (j1=dsItem(operon->init,j);j1<dsItem(operon->init,j+1);j1++)
                                {
					/*we do not consider matrix_score[i][j] where closure i and j have different length*/
					if (matrix_score[i1][j1]==0) continue;
					/*consider the pvalue of the two closures with max similarity score*/
					pvalue_2 = -(100*log(all[i1]->significance)) - (100*log(all[j1]->significance));
					/*matrix_score[i1][j1] = matrix_score[i1][j1]*pvalue_2/pvalue_1;*/
					/*consider the rank of the two closures with max similarity score*/
					/*rank = (dsItem(operon->init,j+1)+dsItem(operon->init,i+1)-i1-j1)/(dsItem(operon->init,j+1)+dsItem(operon->init,i+1)-dsItem(operon->init,j)-dsItem(operon->init,i));*/

					/*we enhance the closures which cover the motif on target genome*/
					if (!po->PvalueInfluence)
					{
						if (IsCoverTarget[i1] && IsCoverTarget[j1])
							matrix_score_temp =2*matrix_score[i1][j1];
						else
							matrix_score_temp = matrix_score[i1][j1];
					}
					else
					{
						if (IsCoverTarget[i1] && IsCoverTarget[j1]) 
							matrix_score_temp = 2*matrix_score[i1][j1]*pvalue_2/pvalue_1;
						else
							/*we consider the influence of pvalue*/
							matrix_score_temp = matrix_score[i1][j1]*pvalue_2/pvalue_1;
					}
					if (matrix_score_temp > edge_max)
                                        {
                                                edge_max = matrix_score_temp;
						second_edge_v1 = max_edge_v1;
						second_edge_v2 = max_edge_v2;
						max_edge_v1 = i1;
                                                max_edge_v2 = j1;
                                        }
                                        edge_weight[edge_num++] = matrix_score_temp;
                                }
                        }

			/*store the closures id corresponding max edge*/
			max_v1[i][j] = max_edge_v1;
			max_v2[i][j] = max_edge_v2;
			second_v1[i][j] = second_edge_v1;
			second_v2[i][j] = second_edge_v2;

                        /*represent the max edge by the average of top edges*/
			qsort(edge_weight, edge_num , sizeof *edge_weight, compare_continuous);
			top = po->TopEdges;
			/*edge_max is the average of top scores before the outlier process*/
                        for (top_index = edge_num-1, edge_max = 0; top_index > edge_num-1-top; top_index--)
                        {
                                edge_max += edge_weight[top_index];
                        }
			edge_max = edge_max/top;

			/*set the similarity score cutoff of different length*/
			continuous cutoff_1=0, cutoff_2 =0;
			if (po->MOTIFLENGTH <= 12) { cutoff_1 = 0.65; cutoff_2 = 0.5;}
			if (po->MOTIFLENGTH == 14) { cutoff_1 = 0.6; cutoff_2 = 0.424;}
			if (po->MOTIFLENGTH == 16) { cutoff_1 = 0.55; cutoff_2 = 0.4;}
			if (po->MOTIFLENGTH >= 18) { cutoff_1 = 0.5; cutoff_2 = 0.35;}
			
			int num_large_edges = 0;
			/*find out the outlier score of edge_weight*/
			for (top_index = edge_num-1; top_index > 0; top_index--)
			{
				if (edge_weight[top_index] <= 0.2)
					break;
				if (num_large_edges >= floor((edge_num-1)/2))
					break;
				if (((edge_weight[edge_num-1] - edge_weight[top_index])/edge_weight[edge_num-1] < 0.5) ||  edge_weight[top_index] >= cutoff_2 )
					num_large_edges++;
			}
			/*redefine the top*/
			top = num_large_edges;
                        /*recalculate the edge_average and edge_var by omitting the largest top edges*/
			edge_average = get_average_from_array (edge_weight,(edge_num-top));
                        edge_var = get_variance_from_array (edge_weight,edge_average,(edge_num-top));
			
			/*get the first level edges*/
			if (edge_weight[edge_num-1] >= cutoff_1) 
			{
				z_score[i][j] += edge_max*20;
				z_score[j][i] += edge_max*20;
				z_score_second[i][j] += edge_weight[edge_num-2]*20;
				z_score_second[j][i] += edge_weight[edge_num-2]*20;
			}
			else if (edge_weight[edge_num-2] >= cutoff_2)
			{
				z_score[i][j] += edge_max*20;
				z_score[j][i] += edge_max*20;
				z_score_second[i][j] += edge_weight[edge_num-2]*20;
                                z_score_second[j][i] += edge_weight[edge_num-2]*20;
			}
			else if (edge_max <= 0.3)
			{
				z_score[i][j] += 0;
				z_score[j][i] += 0;
			}
			else 
			{
				z_score[i][j] += (edge_max-edge_average)/edge_var/* + edge_var + edge_max + edge_average*/;
                     	   	z_score[j][i] += (edge_max-edge_average)/edge_var/* + edge_var + edge_max + edge_average*/;
				z_score_second[i][j] += (edge_weight[edge_num-2]-edge_average)/edge_var;
				z_score_second[j][i] += (edge_weight[edge_num-2]-edge_average)/edge_var;
			}

			/*represent the z_score by edge_max because we found that max edge is a good predictor of real motif*/
			/*z_score[i][j] = edge_max;
			z_score[j][i] = edge_max;
			z_score_second[i][j] = edge_weight[edge_num-2];
			z_score_second[j][i] = edge_weight[edge_num-2];*/

                }
        }
	/*======================================================================================================================*/

	/*================================parse the z_score matrix==============================================================*/
	/*update the z_score matrix base on searching current alignment on NC_000913_promoter*/
	Zscore **z_score_all;
	Zscore *z_score_temp;
	int id=0;
	AllocArray (z_score_all, oper_num_all*oper_num_all);

	for (i=0;i<oper_num_all-1;i++)
        {
		for (j=i+1;j<oper_num_all;j++)
		{
			AllocVar (z_score_temp);
			z_score_temp->score = 100*z_score[i][j];
			z_score_temp->v1 = max_v1[i][j];
			z_score_temp->v2 = max_v2[i][j];
			z_score_all[id] = z_score_temp;
			id++;
		}
	}
	for (i=0;i<oper_num_all-1;i++)
        {
                for (j=i+1;j<oper_num_all;j++)
                {
                        AllocVar (z_score_temp);
                        z_score_temp->score = 100*z_score_second[i][j];
                        z_score_temp->v1 = second_v1[i][j];
                        z_score_temp->v2 = second_v2[i][j];
                        z_score_all[id] = z_score_temp;
                        id++;
                }
        }
	/*sort the edges by their zscore*/
	sort_zscore_list(z_score_all, id);
	bool IsClosureAppear = FALSE;

	int top_edge_num = 0; 
	for (i=0; i< id; i++)
	{
		if (!IsCoverTarget[z_score_all[i]->v1] && !IsCoverTarget[z_score_all[i]->v2])
			continue;
		if (IsClosuresSeed[z_score_all[i]->v1] || IsClosuresSeed[z_score_all[i]->v2])
			continue;
		
		/*check whether the current closure has been used*/
		IsClosureAppear = FALSE;
		for (j=0; j<i ;j++)
		{
			if (IsClosuresSeed[z_score_all[j]->v1] && matrix_score[z_score_all[j]->v1][z_score_all[i]->v1]>po->thre)	
			{
				IsClosureAppear = TRUE;
				break;
			}
			if (IsClosuresSeed[z_score_all[j]->v2] && matrix_score[z_score_all[j]->v2][z_score_all[i]->v1]>po->thre)	
			{
				IsClosureAppear = TRUE;
				break;
			}
				
		}
		if (IsClosureAppear)
			continue;

		/*get the combined closures*/
		get_alignment_from_two_closures(z_score_all[i]->v1, z_score_all[i]->v2, all,fw1, matrix_score[z_score_all[j]->v2][z_score_all[i]->v1], z_score_all[i]->score);

		IsClosuresSeed[z_score_all[i]->v1] = TRUE;
		IsClosuresSeed[z_score_all[i]->v2] = TRUE;
		top_edge_num++;
		if (top_edge_num >= po->RPT_BLOCK)
			break;
	}
	if (top_edge_num < po->RPT_BLOCK)
		po->RPT_BLOCK = top_edge_num;	
	fprintf (fw1,">end\n");
	/*======================================================================================================================*/

	/*==========================================redundant code==============================================================*/
	/*printf ("\no\t");
        for (i=0;i<oper_num_all;i++)
                printf ("%s\t",genome[i]->oper_name);
        printf ("\n");
        for (i=0;i<oper_num_all;i++)
        {
                printf ("%s\t",genome[i]->oper_name);
                for (j=0;j<oper_num_all;j++)
                {
                        printf ("%2.5f\t",z_score[i][j]);
                }
                printf ("\n");
        }*/
	/*======================================================================================================================*/

	/*free the memory*/
	for (id =0 ; id <oper_num_all; id++)
	{
		free (max_v1[id]);
		free (max_v2[id]);
	}
	free (max_v1);
        free (max_v2);
}
/***********************************************************************/
continuous get_average_from_array(continuous *edge_weight, int edge_num)
{
        int i;
        continuous average=0;
        for (i=0; i<edge_num;i++)
                average += edge_weight[i];
        average = average/(float)edge_num;
        return average;
}
/***********************************************************************/
continuous get_variance_from_array (continuous *edge_weight, continuous edge_average, int edge_num)
{
        int i;
        continuous variance=0;
        for (i=0; i<edge_num; i++)
                variance += (edge_average-edge_weight[i])*(edge_average-edge_weight[i]);
        variance = sqrt (variance/(float)(edge_num-1));
        return variance;
}
/************************************************************************/
continuous *get_species_overlap_num (int c_1, int c_2, int g_1, int g_2)
/* get the number of overlap species from closures c_1 c_2 and genomes g_1 g_2*/
{
	int i,j;
	continuous *num;
	int num_1=0,num_2=0;
	AllocArray (num, 2);
	num[0]=num[1]=0;
	bool *IsOverlap_1, *IsOverlap_2;
	AllocArray (IsOverlap_1, all[c_1]->closure_rows);
	AllocArray (IsOverlap_2, all[c_2]->closure_rows);

	/*species_name = alloc2c (100,all[c_1]->closure_rows+all[c_2]->closure_rows);*/
	/* initailation of IsOverlap */
	for (i=0;i<all[c_1]->closure_rows;i++)
                IsOverlap_1[i]=FALSE;
	for (i=0;i<all[c_2]->closure_rows;i++)
                IsOverlap_2[i]=FALSE;
	/*annotate duplation of IsOverlap*/
	for (i=0;i<all[c_1]->closure_rows-1;i++)
	{
		if (IsOverlap_1[i]) continue;
		for (j=i+1;j<all[c_1]->closure_rows;j++)
		{
			if (dsItem(all[c_1]->sequence,i) == dsItem(all[c_1]->sequence,j))
			{
				IsOverlap_1[j] = TRUE;
				num_1++;
			}
		}
	}
	for (i=0;i<all[c_2]->closure_rows-1;i++)
	{
		if (IsOverlap_2[i]) continue;
		for (j=i+1;j<all[c_2]->closure_rows;j++)
		{
			if (dsItem(all[c_2]->sequence,i) == dsItem(all[c_2]->sequence,j))
			{
				IsOverlap_2[j] = TRUE;
				num_2++;
			}
		}
	}
	/* calculate the overlap*/
	for (i=0;i<all[c_1]->closure_rows;i++)
	{
		if (IsOverlap_1[i]) continue;
		for (j=0;j<all[c_2]->closure_rows;j++)
		{
			if (IsOverlap_2[i]) continue;
			if (sameString(genome[g_1]->species[dsItem(all[c_1]->sequence,i)],genome[g_2]->species[dsItem(all[c_2]->sequence,j)]))
			{
				num[0]++;
				break;
			}
		}
	}
	num[1]=all[c_1]->closure_rows+all[c_2]->closure_rows-num[0]-num_1-num_2;
	free (IsOverlap_1);
	free (IsOverlap_2);
	return num;
}
/************************************************************************/
int get_genome_num_from_closure (Closures *aa)
{
	int i, genome_num=0;
	bool flag;
	for (i=0;i<reference_oper_num;i++)
        {
                if (sameString(genome[i]->oper_name,aa->name))
                {
                        flag = TRUE;
                        genome_num = i;
                        break;
                }
        }
	return genome_num;
}
/************************************************************************/
/* Comparison function for GNU qsort */
static int compare_continuous (const void *a, const void *b)
{
    const continuous *da = a;
    const continuous *db = b;
    /*make qsort in the increasing order*/
    return (*da < *db)?-1:(*da != *db);
}
/************************************************************************/
int zscore_cmpr(const void *a, const void *b)
	/* compare function for qsort, descending by score */
{
        return ((*(Zscore **)b)->score - (*(Zscore **)a)->score);
}

void sort_zscore_list(Zscore **z_score_all, int id)
{
        qsort(z_score_all, id, sizeof *z_score_all, zscore_cmpr);
}

/************************************************************************/
discrete **frequency_matrix (char **sequence_temp, int a, int b, int motif_number)
/*get the frequency matrix used in caculating profile matrix*/
{
	int i,j=0,k;
	discrete **frequency;
        frequency = alloc2d (a,b);
        for (i=0; i<a; i++)
                for (j=0; j<b; j++)
                        frequency[i][j]=0;
/*printf ("%d\t%d\t%d\n",a,b,motif_number);*/
        for (i=0; i<motif_number; i++)
                for (k=0;k<b;k++)
                {
                        if (sequence_temp[i][k]=='A' || sequence_temp[i][k]=='a') frequency[1][k]=frequency[1][k]+1;
                        else if (sequence_temp[i][k]=='G' || sequence_temp[i][k]=='g') frequency[2][k]=frequency[2][k]+1;
                        else if (sequence_temp[i][k]=='C' || sequence_temp[i][k]=='c') frequency[3][k]=frequency[3][k]+1;
                        else if (sequence_temp[i][k]=='T' || sequence_temp[i][k]=='t') frequency[4][k]=frequency[4][k]+1;
                }
	return frequency;
}
/************************************************************************/
continuous **get_profile (char **sequence_temp, continuous **markov_matrix, int a, int b, int motif_number)
/*get the profile matrix of a closure*/
{
	continuous **scoreM;
	discrete **frequency;
	scoreM = alloc2dd (a,b);
	int i,j;
	for (i=0; i<5; i++)
		for (j=0; j<b; j++)
			scoreM[i][j]=0;
	frequency = frequency_matrix (sequence_temp, a, b, motif_number);
	for (i=1;i<a;i++)
		for (j=0;j<b;j++)
			scoreM[i][j]= log((frequency[i][j]+markov_matrix[i][0])/(markov_matrix[i][0]*(motif_number+1)));
	for (i=0;i<a;i++)
		free (frequency[i]);
	free (frequency);
	return scoreM;
}

/************************************************************************/
continuous **get_profile_new (continuous **markov_matrix, discrete **frequency, int a, int b, int motif_number)
/*get the profile matrix of a closure*/
{
	continuous **scoreM;
	scoreM = alloc2dd (a,b);
	int i,j;
	for (i=0; i<5; i++)
		for (j=0; j<b; j++)
			scoreM[i][j]=0;
	for (i=1;i<a;i++)
		for (j=0;j<b;j++)
			scoreM[i][j]= log((frequency[i][j]+markov_matrix[i][0])/(markov_matrix[i][0]*(motif_number+1)));
	return scoreM;
}
/************************************************************************/
continuous **impovre_profle (continuous **scoreM, double  length_local_1)
/*improve the score matrix base on the conserve property of two ends of motif*/
{
	int forepart=floor(length_local_1/3),endpart=ceil(length_local_1/3),delIndex=0;
        continuous sum_scoreM=0;
	int i,j;
        for (j=0;j<forepart;j++)
        {
                scoreM[0][j]=0;
                for (i=1;i<5;i++)
			if (scoreM[i][j] > scoreM[0][j]) scoreM[0][j]=scoreM[i][j];
                sum_scoreM = sum_scoreM + scoreM[0][j];
        }
        for (j=0;j<forepart;j++)
	        if (scoreM[0][j]<((sum_scoreM*0.6)/forepart))
                {
        	        if (delIndex==1)
                	        for (i=1;i<5;i++)
                        	        scoreM[i][j]=0;
			else
				delIndex=1;
                }
	sum_scoreM =0; delIndex=0;
        for (j=length_local_1-1;j>length_local_1-endpart-1;j--)
        {
        	scoreM[0][j]=0;
                for (i=1;i<5;i++)
                	if (scoreM[i][j] > scoreM[0][j]) scoreM[0][j]=scoreM[i][j];
                sum_scoreM = sum_scoreM + scoreM[0][j];
        }
	for (j=length_local_1-1;j>length_local_1-endpart-1;j--)
        	if (scoreM[0][j]<((sum_scoreM*0.6)/forepart))
                {
                	if (delIndex==1)
                        	for (i=1;i<5;i++)
                                	scoreM[i][j]=0;
			else
	                        delIndex=1;
		}
	for (j=forepart;j<length_local_1-endpart;j++)
        	for (i=1;i<5;i++)
			scoreM[i][j]=scoreM[i][j]/2;  /*if plalindome, scoreM[i][j]=0*/
	return scoreM;
}

/************************************************************************/
char **get_sequences_from_closures (Closures *aa)
{
	int i,j,k,genome_num=0;
	char **sequence_aa;
	bool flag = FALSE;
	for (i=0;i<reference_oper_num;i++)
	{
		/*printf ("%s\t%s\n",genome[i]->oper_name,aa->name);*/
		if (sameString(genome[i]->oper_name,aa->name))
		{
			flag = TRUE;
			genome_num = i;
			break;
		}	
	}
        sequence_aa = alloc2c (aa->closure_rows,aa->length);
	for (i=0; i<aa->closure_rows; i++)
	{
		k=0;
	/*	printf ("\t%d\t%d\t%d\n", i, dsItem(aa->sequence,i), dsItem(aa->position,i));*/
		for (j=dsItem(aa->position,i);j< (dsItem(aa->position,i)+aa->length); j++)
		{
			if (flag) sequence_aa[i][k] = genome[genome_num]->sequences_r[dsItem(aa->sequence,i)][j];
			else 
			{
				printf ("Sorry, we can not find corresponding sequences for operon %s, please check it out\n",aa->name);
				exit(1);
			}
			k++;
		}
	}
	/*for (i=0; i<aa->closure_rows; i++ )
		printf ("%s\n",sequence_aa[i]);*/
	return sequence_aa;
}

/************************************************************************/
char **get_2L_sequeces_from_closures (Closures *aa)
/*get sequences with 2L base on a closure*/
{
	int i,j,k, left, right, left_1, right_1, length1;
	char **sequence_aa;
	int genome_num = 0;
	bool flag = FALSE;
	for (i=0;i<reference_oper_num;i++)
        {
                if (sameString(genome[i]->oper_name,aa->name))
                {
                        flag = TRUE;
                        genome_num = i;
                        break;
                }
        }
	sequence_aa = alloc2c (aa->closure_rows,2*aa->length);
	for (i=0; i<aa->closure_rows; i++)
        {
                k=0;
                left_1 = dsItem(aa->position,i) - floor(aa->length/2);
                left = MAX(0,left_1);
		if (flag) length1= strlen(genome[genome_num]->sequences_r[dsItem(aa->sequence,i)])-1;
		else 
		{
			printf ("Sorry, we can not find corresponding sequences for operon %s, please check it out\n",aa->name);
			exit(1);
		}
                right_1 = dsItem(aa->position,i) + aa->length + ceil(aa->length/2);
                right = MIN(length1,right_1);
                if (left_1<0)
                {
                        for (j=0; j< ABS(left_1); j++)
                        {
                                sequence_aa[i][k] = 'N';
                                k++;
                        }
                }
                for (j=left; j< right; j++)
                {
                        sequence_aa[i][k] = genome[genome_num]->sequences_r[dsItem(aa->sequence,i)][j];
                        k++;
                }
                if (right_1 > length1)
                        for (j=0;j<(right_1 - length1);j++)
                        {
                                sequence_aa[i][k] = 'N';
                                k++;
                        }
        }
	return sequence_aa;
}
/************************************************************************/
continuous *get_column_IC_12 (Closures **aa, int clos_1, int clos_2, int startpos_1, int startpos_2, int num_a, int num_b)
{
	continuous *I_12;
	int p , q;
	int min = MIN(aa[clos_1]->length, aa[clos_2]->length);
        int length = 2*min;
	AllocArray (I_12, length);
	int pos_max = MAX (startpos_1,startpos_2);
	int length_new = length-pos_max;
	for (p = 0; p < length_new; p++)
	{
		I_12[p] = 0;
		for (q=1; q<5; q++)
		{
			I_12[p] = I_12[p] + ((fre2_all[clos_1][q][startpos_1+p]+genome[num_a]->markov_matrix[q][0])*sco2_all[clos_2][q][startpos_2+p])/(aa[clos_1]->closure_rows+1);
		}
		fflush(stdout);
	}
	fflush(stdout);
	return I_12;
}
/************************************************************************/
continuous *get_column_IC_21 (Closures **aa, int clos_1, int clos_2, int startpos_1, int startpos_2, int num_a, int num_b)
{
	continuous *I_21;
	int p , q;
	int min = MIN(aa[clos_1]->length, aa[clos_2]->length);
	int length = 2*min;
	AllocArray (I_21, length);
	int pos_max = MAX (startpos_1,startpos_2);
	int length_new = length-pos_max;
	for (p = 0; p < length_new; p++)
	{
		I_21[p] = 0;
		for (q=1; q<5; q++)
		{
			I_21[p] = I_21[p] + ((fre2_all[clos_2][q][startpos_2+p]+genome[num_b]->markov_matrix[q][0])*sco2_all[clos_1][q][startpos_1+p])/(aa[clos_2]->closure_rows+1);
		}
	        startpos_1=startpos_1; startpos_2=startpos_2;
		fflush(stdout);			
	}
	fflush(stdout);			
	return I_21;
}
/************************************************************************/
continuous *get_column_IC (Closures **aa, int clos,  int num)
{
	continuous *I_11;
	int p , q;
	int length = 2*aa[clos]->length;
	AllocArray (I_11, length);
	for (p = 0; p < length; p++)
	{
		I_11[p] = 0;
		/*if (p>=floor(aa[clos]->length/2) && p<(floor(aa[clos]->length/2)+aa[clos]->length))
		{*/
			for (q=1; q<5; q++)
			{
				I_11[p] = I_11[p] + ((fre2_all[clos][q][p]+genome[num]->markov_matrix[q][0])*sco2_all[clos][q][p])/(aa[clos]->closure_rows+1);
			}
		/*}*/
	}
	return I_11;
}
/************************************************************************/
void get_alignment_from_two_closures (int num_1, int num_2, Closures **aa, FILE *fw1, double similarity_score, double z_score)
{
	int i,j,num_a,num_b,start, end, start_new=0, end_new = 0;
       	discrete **frequency_new;
	int p,q;
	continuous **markov_new, **profile, *IC;
	char **sequence_a, **sequence_b, **sequence_aa, **sequence_bb, **sequence_new, **sequence_final;
	num_a = get_genome_num_from_closure (aa[num_1]);
	num_b = get_genome_num_from_closure (aa[num_2]);
	sequence_a = get_sequences_from_closures (aa[num_1]);
	sequence_b = get_sequences_from_closures (aa[num_2]);
	sequence_aa = get_2L_sequeces_from_closures (aa[num_1]);
	sequence_bb = get_2L_sequeces_from_closures (aa[num_2]);
	sequence_new = alloc2c (aa[num_1]->closure_rows+aa[num_2]->closure_rows,aa[num_1]->length+aa[num_2]->length);
	sequence_final = alloc2c (aa[num_1]->closure_rows+aa[num_2]->closure_rows,aa[num_1]->length+aa[num_2]->length);
	if (clo_matr1[num_1][num_2] >= 0)
	{
		start = clo_matr1[num_1][num_2];
		end = MIN(2*aa[num_1]->length, clo_matr1[num_1][num_2]+2*aa[num_2]->length);
		for (i=0; i<aa[num_1]->closure_rows; i++)
		{
			for (j=start; j<end; j++)
			{
				sequence_new[i][j-start] = sequence_aa[i][j];
			}
			sequence_new[i][end-start] = '\0';
		}
		for (i=0; i<aa[num_2]->closure_rows; i++)
		{
			for (j=start; j<end; j++)
			{
				sequence_new[i+aa[num_1]->closure_rows][j-start] = sequence_bb[i][j-clo_matr1[num_1][num_2]];
			}
			sequence_new[i][end-start] = '\0';
		}
	}
	else
	{
		start = -clo_matr1[num_1][num_2];
                end = MIN(2*aa[num_2]->length, -clo_matr1[num_1][num_2]+2*aa[num_1]->length);
                for (i=0; i<aa[num_1]->closure_rows; i++)
                {
                        for (j=start; j<end; j++)
                        {
                                sequence_new[i][j-start] = sequence_aa[i][j+clo_matr1[num_1][num_2]];
                        }
			sequence_new[i][end-start] = '\0';
                }
                for (i=0; i<aa[num_2]->closure_rows; i++)
                {
                        for (j=start; j<end; j++)
                        {
                                sequence_new[i+aa[num_1]->closure_rows][j-start] = sequence_bb[i][j];
                        }
			sequence_new[i][end-start] = '\0';
                }
	}

	markov_new = alloc2dd(5,5);
	for (i=0;i<5;i++)
                for (j=0;j<5;j++)
                        markov_new[i][j] = (genome[num_a]->markov_matrix[i][j]+genome[num_b]->markov_matrix[i][j])/2;
	
	frequency_new = frequency_matrix (sequence_new, 5, end-start, (aa[num_1]->closure_rows+aa[num_2]->closure_rows));
	profile = get_profile_new (markov_new, frequency_new, 5, end-start, aa[num_1]->closure_rows+aa[num_2]->closure_rows);
	
	AllocArray (IC,end-start);
	for (p=0; p<(end-start); p++)
	{
		IC[p] = 0;
		for (q=1;q<5;q++)
		{
			IC[p] += ((frequency_new[q][p]+markov_new[q][0])*profile[q][p])/(aa[num_1]->closure_rows+aa[num_2]->closure_rows+1);
		}
	}
	bool IsInit = FALSE;
	for (p=0; p<end-start-1; p++)
	{
		start_new = 0;
		if (IC[p]<0.1 && IC[p+1]<0.1)
			continue;
		if (IC[p] >=0.2)
		{
			start_new = p;
			IsInit = TRUE;
                        break;
		}
		if(IC[p]<0.5*IC[p+1] && IC[p+1]>0)
		{
			start_new = p+1;
			break;
		}
	}	
	if (start_new == 0 && IsInit == FALSE)
	{
		/*return sequence_new;*/
	}
	else
	{
		for (p=end-start-1; p>start_new;p--)
		{
			end_new = end-start-1;
			if (IC[p]<0.1 && IC[p-1]<0.1)
				continue;
			if (IC[p] >=0.2)
	                {
        	                end_new = p;
                	        break;
                	}
			if (IC[p] < 0.5*IC[p-1] && IC[p-1]>0)
			{
				end_new = p-1;
				break;
			}
		}
		/*current alignment is not good enough to search motif if end_new-start_new <4*/
		if (end_new-start_new+1 >= 4)
		{
			fprintf (fw1, ">CombinedClosure-%d-%s-%s-%d-%d-%.2f-%.2f",aa[num_1]->closure_rows+aa[num_2]->closure_rows,all[num_1]->name,all[num_2]->name,num_1+1,num_2+1,similarity_score,z_score/100);
			print_species_overlap (num_1, num_2, fw1);
			fprintf (fw1,"\n");		
			for (i=0; i<aa[num_1]->closure_rows+aa[num_2]->closure_rows; i++)
			{
				for (j=0; j<end_new-start_new+1; j++)
				{
					sequence_final[i][j] = sequence_new[i][j+start_new];
					fprintf (fw1,"%c",sequence_new[i][j+start_new]);
				}
				fprintf (fw1,"\n");
				sequence_final[i][end_new-start_new+1] = '\0';
			}
		}
	}
}
/********************************************************************************/
void print_species_overlap (int c_1, int c_2, FILE *fw1)
/* get the number of overlap species from closures c_1 c_2 and genomes g_1 g_2*/
{
	int i,j;
	int num=0;
	int num_1=0,num_2=0;
	bool *IsOverlap_1, *IsOverlap_2;
	AllocArray (IsOverlap_1, all[c_1]->closure_rows);
	AllocArray (IsOverlap_2, all[c_2]->closure_rows);

	int num_a,num_b;
	num_a = get_genome_num_from_closure(all[c_1]);
	num_b = get_genome_num_from_closure(all[c_2]);
	/*species_name = alloc2c (100,all[c_1]->closure_rows+all[c_2]->closure_rows);*/
	/* initailation of IsOverlap */
	for (i=0;i<all[c_1]->closure_rows;i++)
                IsOverlap_1[i]=FALSE;
	for (i=0;i<all[c_2]->closure_rows;i++)
                IsOverlap_2[i]=FALSE;
	/*printf ("%s\t%s\t%d\t%d\n",all[c_1]->name,all[c_2]->name,c_1,c_2);*/
	/*annotate duplation of IsOverlap*/
	for (i=0;i<all[c_1]->closure_rows-1;i++)
	{
		if (IsOverlap_1[i]) continue;
		for (j=i+1;j<all[c_1]->closure_rows;j++)
		{
			if (dsItem(all[c_1]->sequence,i) == dsItem(all[c_1]->sequence,j))
			{
				IsOverlap_1[j] = TRUE;
				num_1++;
			}
		}
	}
	for (i=0;i<all[c_2]->closure_rows-1;i++)
	{
		if (IsOverlap_2[i]) continue;
		for (j=i+1;j<all[c_2]->closure_rows;j++)
		{
			if (dsItem(all[c_2]->sequence,i) == dsItem(all[c_2]->sequence,j))
			{
				IsOverlap_2[j] = TRUE;
				num_2++;
			}
		}
	}
	/* calculate the overlap*/
	for (i=0;i<all[c_1]->closure_rows;i++)
	{
		if (IsOverlap_1[i]) continue;
		for (j=0;j<all[c_2]->closure_rows;j++)
		{
			if (IsOverlap_2[i]) continue;
			if (sameString(genome[num_a]->species[dsItem(all[c_1]->sequence,i)],genome[num_b]->species[dsItem(all[c_2]->sequence,j)]))
			{
				fprintf (fw1, "-%s",genome[num_a]->species[dsItem(all[c_1]->sequence,i)]);
				num++;
				break;
			}
		}
	}
	fprintf (fw1,"--%d",num);
	free (IsOverlap_1);
	free (IsOverlap_2);
}
/************************************************************************/
