/************************************************************************/
/* Author: Qin Ma <maqin@uga.edu>, Feb. 15, 2010
 * the functions related to printing output to specific files
 */
/************************************************************************/

#include "motif_search.h"
#define INF 1000000

void validation_motif(const char* fn)
/* validation of the motifs in current promoter file*/
{

    /*adjust the uplimit size of motif closures*/	
    /*printf ("%d\n",CLOSURE_SIZE_D);*/
    continuous CLOSURE_SIZE_D1 = s_rows*s_cols/(100*po->threshold_e2);
    if (CLOSURE_SIZE_D1 > CLOSURE_SIZE_D)
    {
	CLOSURE_SIZE_D = floor (CLOSURE_SIZE_D1);
    	/*printf ("%d\n",CLOSURE_SIZE_D);*/
    }
    CLOSURE_SIZE_D = MIN (CLOSURE_SIZE_D, 600000);

    /*Part I =======================================================================*/
    FILE *fw = mustOpen(fn, "w");
    	/*define the variables*/
    int al, i=0, j=0, k=0, iteration_num=0, ii, t, seq_number=s_rows, length_local_1=0, Motif_Scan_V[90], motif_number=0, motif_current=0, motif_number_2=0, kk=0, i_max_1=0, i_max=0, motif_number_1=0, tt=0, length_ave=0, numberfore=1, randomNum, simulation=po->simu, Rt, num_all_R=0, t_max=0, range=10;
    int ccc=po->threshold_e2*100-10;
    continuous var_max=0, length_ave_1=0, score_max_1=0, Motif_R_V[90], pvalue_V[10], pp[5], AveScore_V[90], score_scan=0, score_scan_RC,  **scoreM, **scoreM_RC, score[CLOSURE_SIZE_D], pvalue=1, zscore=0,enrichment=0, log2enrichment=0, motif_background=0,motif_known=0, fre_value=0, AveScore=0, score1[CLOSURE_SIZE_D], Scan_tmp, R_tmp, poisson, one_tmp=1, iiii;
    discrete **frequency;
    char *consensus, **sequences_2, *randomdata;
    struct dyStack *gene, *cond, *gene1, *cond1, *gene2, *cond2;
    Motif* c;

	/*set memory*/
    AllocVar(c);
    gene = dsNew(CLOSURE_SIZE_D);
    cond = dsNew(CLOSURE_SIZE_D);
    gene1 = dsNew(CLOSURE_SIZE_D);
    cond1 = dsNew(CLOSURE_SIZE_D);
    gene2 = dsNew(CLOSURE_SIZE_D);
    cond2 = dsNew(CLOSURE_SIZE_D);
    Closures **cc;
    if (po->IsAlignment){ AllocArray (cc,alignment_num); iteration_num = alignment_num;}
    else if (po->IsMatrix) { AllocArray (cc, matrix_num); iteration_num = matrix_num;}
    else { AllocArray (cc,MAX(alignment_num,matrix_num)); iteration_num = MAX(alignment_num,matrix_num);}
    /*=======================================================================*/
	
    /*Part II scan motif for each motif candidate============================*/
    for (al=0; al<iteration_num; al++)
    {
	/*print output message*/
	if (po->IsMatrix){ printf("%s (motif length: %d) is in process...\n",Matrix[al]->motif_name, Matrix[al]->ColNum);}
	else if (po->IsAlignment){ printf("%s (motif length: %d) is in process...\n",Alignment[al]->motif_name, Alignment[al]->ColNum);}
	/*set memory*/
       	AllocVar(c);
	/*set initial values*/	
	length_local_1=0; motif_number=0; motif_number_2=0; kk=0; score_scan=0; score_scan_RC=0; pvalue=1; zscore=0; enrichment=0; motif_background=0; motif_known=0; fre_value=0; AveScore=0;
	if (po->IsAlignment){ length_local_1= Alignment[al]->ColNum; motif_number= Alignment[al]->RowNum;}
	else if (po->IsMatrix){ length_local_1 = Matrix[al]->ColNum; motif_number= Matrix[al]->RowNum; motif_number = MIN(motif_number,s_rows);}
	size_closure = motif_number;
	frequency = alloc2d (5,length_local_1);
	AllocArray (consensus, length_local_1);
       	sequences_2 = alloc2c (motif_number, length_local_1);
        scoreM = alloc2dd (5,length_local_1);
        scoreM_RC = alloc2dd (5,length_local_1);
        if (po->IsAlignment){ frequency = frequency_matrix (Alignment[al]->sequences, 5, length_local_1, motif_number);}
	else if (po->IsMatrix){	frequency = Matrix[al]->matrix;	}
	consensus = get_consensus(frequency, 5 , length_local_1);
	for (i=0; i<motif_number; i++)	{score[i]=0;}
        for (i=0; i<5; i++)
            for (j=0; j<length_local_1; j++)
	    {
		scoreM[i][j]=0;
		scoreM_RC[i][j]=0;
	    }
        	
	Closures *cctemp;
	AllocVar(cctemp);
	cctemp->scoreM = alloc2dd (5,length_local_1);

	/*Part II.1 three-time enlargement of each motif============================*/
       	/* 1000: 3 times closure improvement begion : ii */
       	for (ii=1;ii< po->closure_enlarge_times+1;ii++)
	{
             	/*1100: load current seed or motifs in sequences_2: begin*/
            if (ii==1)
	    {
               	for(i=0;i<motif_number;i++)
	 	    for (j=0; j<length_local_1; j++)
		    {	
                    	if (po->IsAlignment){ sequences_2[i][j] = Alignment[al]->sequences[i][j];}
			else {sequences_2[i][j] = sequences[i][j];}
		    }
		if (po->IsMatrix)
		{
                    for (i=1;i<5;i++)
                        for (j=0;j<length_local_1;j++)
                       	{
                            fre_value = Matrix[al]->matrix[i][j];
	                    scoreM[i][j]= log2((fre_value+p_markov[i][0])/(p_markov[i][0]*(Matrix[al]->RowNum+1)));
			    scoreM_RC = get_palindromic_profle (scoreM, length_local_1) ;
			    cctemp->scoreM[i][j] = log2((fre_value+p_markov[i][0])/(p_markov[i][0]*(Matrix[al]->RowNum+1)));
                	}
                    for (i=1;i<5;i++)
                        for (j=0;j<length_local_1;j++)
                       	    AveScore = AveScore + scoreM[i][j]*Matrix[al]->matrix[i][j];
        	    AveScore = AveScore/Matrix[al]->RowNum;
		}
		else if (po->IsAlignment)
		{
		    scoreM = get_profile (sequences_2, 5 , length_local_1, motif_number);
		    scoreM_RC = get_palindromic_profle (scoreM, length_local_1) ;
		    for (i=1;i<5;i++)
			for (j=0;j<length_local_1;j++)
		   	    cctemp->scoreM[i][j] = scoreM[i][j];
	            if(po->twoendweight)
		    {
			scoreM = impovre_profle (scoreM, length_local_1);
			scoreM_RC = get_palindromic_profle (scoreM, length_local_1) ;
		    }
		    if (po->IsMarkov)
			AveScore = aver_score_closure_markov(sequences_2,  scoreM, score, motif_number, length_local_1);
		    else
		    	AveScore = aver_score_closure(sequences_2,  scoreM, score, motif_number, length_local_1);
		}
		motif_current = motif_number;
	    }
            else
	    {
		motif_number=motif_number_2;
               	for(i=0;i<motif_number;i++)
               	    for (j=0; j<length_local_1; j++)
                       	sequences_2[i][j]=sequences[dsItem(gene2,i)][dsItem(cond2,i)+j];
                        /*1200: calculate the frequency matrix and log matrix begin*/
                scoreM = get_profile (sequences_2, 5 , length_local_1, motif_number);
		scoreM_RC = get_palindromic_profle (scoreM, length_local_1) ;
                        /* 1300: improve the scoring log matrix begin*/
		if (po->twoendweight)
		{
               	    scoreM = impovre_profle (scoreM, length_local_1);
		    scoreM_RC = get_palindromic_profle (scoreM, length_local_1) ;
		}
		if (po->IsMarkov)
		    AveScore = aver_score_closure_markov(sequences_2,  scoreM, score, motif_number, length_local_1);
		else
		    AveScore = aver_score_closure(sequences_2,  scoreM, score, motif_number, length_local_1);
		motif_current = motif_current;
            }

            for (i=ccc;i<91;i++)
	    {
       		AveScore_V[i]=(0.1+0.01*i)*AveScore;
                Motif_Scan_V[i]=0; 
		Motif_R_V[i]=0;
            }

	    /*******************************************************************************/
	    /*1500: scan data to built closures begin*/
            gene = dsNew(CLOSURE_SIZE_D);
            cond = dsNew(CLOSURE_SIZE_D);
	    motif_number=0;
	    for (i=0;i<seq_number;i++)
	    {
		/*printf ("%d\t%.2f\n",i,AveScore_V[0]);*/
		if (strlen(sequences[i]) < length_local_1) continue;
		for (j=0;j<strlen(sequences[i])-length_local_1+1;j++)   
		{
                    score_scan = 0;
		    score_scan_RC = 0;
                    for (k=0;k<length_local_1;k++)
		    {
			score_scan += scoreM[seq_matrix[i][k+j]+1][k];
			score_scan_RC += scoreM_RC[seq_matrix[i][k+j]+1][k];
		    }
		    if (po->IsMarkov)
		    {
			char *current_seq, *current_seq_palindromic;
			continuous trans_score=0, trans_score_RC=0;
        		AllocArray (current_seq, length_local_1);
			for (k=0;k<length_local_1;k++)
			    current_seq[k] = sequences[i][k+j];
			trans_score = get_trans_score(sequences_2, current_seq, motif_current, length_local_1);
		    	score_scan += trans_score;
			current_seq_palindromic = palindromic_seq (current_seq, length_local_1); 
			trans_score_RC = get_trans_score(sequences_2, current_seq_palindromic, motif_current, length_local_1);
			score_scan_RC += trans_score_RC;
			free (current_seq);
			free (current_seq_palindromic);
		    }	
                    if ((score_scan>AveScore_V[ccc] || score_scan_RC>AveScore_V[ccc]) && motif_number < CLOSURE_SIZE_D-10)
		    {
                      	for (k=ccc;k<91;k++)
                       	    if (score_scan>AveScore_V[k] || score_scan_RC>AveScore_V[k])
                               	Motif_Scan_V[k]++;
	                dsPush(gene,i);
        	        dsPush(cond,j);
                	score[motif_number]=MAX(score_scan, score_scan_RC);
                        motif_number++;
                    }
	        }      
	    }
	    /*******************************************************************************/
	    if(motif_number==0)
	    {
		if(po->IsAlignment)
		    printf("Sorry,there exist no significant searched TFBSs base on %s in current file %s\n",Alignment[al]->motif_name,po->FN);
		if(po->IsMatrix)
		    printf("Sorry,there exist no significant searched TFBSs base on %s in current file %s\n",Matrix[al]->motif_name,po->FN);
		ii=po->closure_enlarge_times+1;
		continue;
	    }
	    /*scan the background and get the motif number in whole gemone*/
	    if(po->zscore)
	    {
		/*continuous zscore,enrichment,motif_background,motif_known;*/
		if (po->IsMarkov)
		{
		    motif_known=scan_genome_markov(sequences_2, motif_current, scoreM,AveScore,length_local_1,po->FP);
		    background_num=scan_genome_markov(sequences_2, motif_current,scoreM,AveScore,length_local_1,po->FZ);
		}
		else
		{
		    motif_known=scan_genome(scoreM,AveScore,length_local_1,po->FP);
		    background_num=scan_genome(scoreM,AveScore,length_local_1,po->FZ);
		}
		if(background_num==0)
		{
	 	    printf("Do not find any instances in background\n");
		    enrichment=INF;zscore=INF;
		    log2enrichment=INF;
		}
		else
		{
		    motif_background=background_num;
		    enrichment=((motif_known+1)*sum_genome)/((sum_markov+1)*motif_background);
		    log2enrichment=log2(((motif_known+1)*sum_genome)/((sum_markov+1)*motif_background));
		    printf("MotifNum:\t%.2f\t%.2f\n",motif_known,motif_background);
		    zscore=(motif_known-sum_markov*motif_background/sum_genome)/sqrt(sum_markov*motif_background/sum_genome);
		}
		    /*printf("%d\t%d\t%ld\t%d\t%.2f\t%.2f\n",background_num,motif_number,sum_genome,sum_markov,enrichment,zscore);*/
	    }

	    /*1600:for first two steps of closure-build only begin*/
	    if(ii<po->closure_enlarge_times)
	    {
		i_max_1=0;
		score_max_1=0;
		gene2=dsNew(CLOSURE_SIZE_D);
		cond2=dsNew(CLOSURE_SIZE_D);
		if(motif_number<size_closure)
		{
		    motif_number_2=motif_number;
		    for(i=0;i<motif_number;i++)
		    {
			dsPush(gene2,dsItem(gene,i));
			dsPush(cond2,dsItem(cond,i));
		    }
		}
		else
		{
		    motif_number_2=size_closure;
		    for(i=0;i<motif_number_2;i++)
		    {
			i_max_1=0;score_max_1=0;
			for(j=0;j<motif_number;j++)
			    if(score[j]>score_max_1)
			    {
				i_max_1=j;
				score_max_1=score[j];
			    }	
			dsPush(gene2,dsItem(gene,i_max_1));
			dsPush(cond2,dsItem(cond,i_max_1));
			score[i_max_1]=0;
		    }
		}
	    }
	}
	/*1000:3 times closure improvement end:ii*/
	if(Motif_Scan_V[ccc]==0)
	{
	    printf("There are no significant occurrences for the %dth motif\n",al+1);
	    Closures*cctemp;
	    AllocVar(cctemp);
	    cctemp->closure_rows=0;
	    cc[al]=cctemp;
	    continue;
	}
	/*2000:simulation on markov data begin*/
	length_ave=0;numberfore=1;num_all_R=0;length_ave_1=0;
	for(i=0;i<seq_number;i++)
	    length_ave_1=length_ave_1+strlen(sequences[i]);
	length_ave=ceil(length_ave_1/seq_number);

	srand((unsigned)time(NULL));
	AllocArray(randomdata,length_ave);

	discrete *randomdata_number;
	randomdata_number=change_AGCT_to_num(randomdata,length_ave);
	    
	int run = 3000;
	/*current Markov transition is time-consuming in the for loop, we need to speed up by fewer Rt*/
	if (po->IsMarkov)
	    run = 300;
	for(Rt=0;Rt<run*simulation;Rt++)
	{
	    for(i=0;i<4;i++)
	    {
		for(j=0;j<length_ave;j++)
		{
		    num_all_R++;
		    for(k=1;k<5;k++)
	  	    	pp[k]=p_markov[numberfore][k];
		    randomNum=rand()%100;
		    if(randomNum<pp[1]*100){randomdata[j]='A';numberfore=1;}
		    else if(randomNum<(pp[1]+pp[2])*100){randomdata[j]='G';numberfore=2;}
		    else if(randomNum<(pp[1]+pp[2]+pp[3])*100){randomdata[j]='C';numberfore=3;}
	  	    else{randomdata[j]='T';numberfore=4;}
		}
		randomdata_number=change_AGCT_to_num(randomdata,length_ave);
		for(j=0;j<length_ave-length_local_1+1;j++)
		{
		    score_scan=0;
		    score_scan_RC=0;
		    for(k=0;k<length_local_1;k++)
		    {
		        score_scan+=scoreM[randomdata_number[k+j]+1][k];
			score_scan_RC += scoreM_RC[randomdata_number[k+j]+1][k];
		    }
			
		    if (po->IsMarkov)
                    {
			char *current_seq, *current_seq_palindromic;
			continuous trans_score=0, trans_score_RC=0;
        		AllocArray (current_seq, length_local_1);
                        for (k=0;k<length_local_1;k++)
                            current_seq[k] = randomdata[k+j];
                        trans_score = get_trans_score(sequences_2, current_seq, motif_current, length_local_1);
                        score_scan += trans_score;
                        current_seq_palindromic = palindromic_seq (current_seq, length_local_1);
                        trans_score_RC = get_trans_score(sequences_2, current_seq_palindromic, motif_current, length_local_1);
                        score_scan_RC += trans_score_RC;
			free (current_seq);
			free (current_seq_palindromic);
                    }

		    for(k=ccc;k<91;k++)
			if(score_scan>AveScore_V[k] || score_scan_RC>AveScore_V[k])
			    Motif_R_V[k]+=1;
	     	}	
	    }
	}
	for(t=ccc;t<91;t++)
	    Motif_R_V[t]=(Motif_R_V[t]*seq_number)/(4*(Rt));

	/*get the interval in which has the most significant variance compared to random*/
	t_max=po->threshold_e2*100-10;
	range=MIN((po->conserve_threshold-po->threshold_e2)*100,10);
	var_max=0;
	for(t=po->conserve_threshold*100-10;t>=po->threshold_e2*100-10;t=t-range)
	{
	    if((Motif_Scan_V[t]-Motif_Scan_V[t+range])/(Motif_R_V[t]-Motif_R_V[t+range])>var_max)
	    {
		var_max=(Motif_Scan_V[t]-Motif_Scan_V[t+range])/(Motif_R_V[t]-Motif_R_V[t+range]);
		t_max=t;
	    }
	}
	/*2000:simulation on markov data end*/

	/*3000:pvalue calculating begin*/ 
	one_tmp=1;
	for(t=MAX(ccc,t_max-range);t<=MIN(t_max+range,po->conserve_threshold*100-10);t++)
	{
	    pvalue_V[t]=0;
	    Scan_tmp=Motif_Scan_V[t];
	    R_tmp=Motif_R_V[t];
 	    while(R_tmp>600)
	    {
		Scan_tmp=Scan_tmp/2;
		R_tmp=R_tmp/2;
  	    }
	    if(R_tmp==0)R_tmp++;
	    poisson=one_tmp/exp(R_tmp);
	    if(po->approximate)
		j=1;
	    else
		j=300;
	    for(iiii=0;iiii<(int)(Scan_tmp)+j;iiii++)
	    {
		if(iiii>(int)(Scan_tmp)-1)
		    pvalue_V[t]=pvalue_V[t]+poisson;
		poisson=poisson*R_tmp/(iiii+1);
	    }
	    if(pvalue>pvalue_V[t])
	    {
		pvalue=pvalue_V[t];
		tt=t;
	    }
	}
	one_tmp=1;
	cctemp->significance_seed=pvalue_V[80];
	cctemp->closure_rows_seed=Motif_Scan_V[80];
	if(tt==0)
	    tt=t_max;
	one_tmp=1;
	/*adjust the output closures because the closure corresponding to the minimal pvalue will be too small*/
	if(po->expansion)
	{
	    tt=0;
	    for(t=70;t>20;t=t-range)
		if((Motif_Scan_V[t]-Motif_Scan_V[t+range])/(Motif_R_V[t]-Motif_R_V[t+range])>1.2)
		{
		    tt=t;	
		    break;
		}
	}
	if(tt==0) tt=t_max;

	one_tmp=1;
	cctemp->significance_extend=pvalue_V[tt];
	cctemp->closure_rows_extend=Motif_Scan_V[tt];
	/*3000:pvalue calculating end*/
	/*4000:fix the final closure and write in struct Closure begin*/
	continuous score_max=AveScore_V[tt];
	gene1=dsNew(CLOSURE_SIZE_D);
	cond1=dsNew(CLOSURE_SIZE_D);
	i_max=0;
	motif_number_1=0;
	/*printf ("%d\t%d\t%.2f\t%d\t111111111111\n", tt, Motif_Scan_V[tt], AveScore_V[tt], motif_number);*/
	for(i=0;i<Motif_Scan_V[tt];i++)
	{
	    i_max=0;
	    score_max=AveScore_V[tt];
	    for(j=0;j<motif_number;j++)
	    {
		if(score[j]>score_max)
		{
		    score_max=score[j];
		    i_max=j;
	 	}
	    }
	   /* printf ("%d\t%.2f\t%d\n",i,score_max,i_max );*/
	    dsPush(gene1,dsItem(gene,i_max));
	    dsPush(cond1,dsItem(cond,i_max));
	    score1[motif_number_1]=score[i_max];
	    motif_number_1++;
	    score[i_max]=0;
	}/*sort and cut closure end*/

	/*setup current closure:cc[al]*/
	/*Closures *cctemp;
	AllocVar(cctemp);*/
	cctemp->frequencyM=alloc2d(5,length_local_1);
	AllocArray(cctemp->consensus,length_local_1);

	if(po->IsAlignment)
	{
	    cctemp->length=Alignment[al]->ColNum;
	    cctemp->name=Alignment[al]->motif_name;	
	    /*we control the size of closures using the parameter -c base on the original size of the motif profile seed*/
	    if(po->size==0)
	 	cctemp->closure_rows=motif_number_1;
	    else
		cctemp->closure_rows=MIN(motif_number_1,po->size*Alignment[al]->RowNum);
	}
	else
	{
	    cctemp->length=Matrix[al]->ColNum;
	    cctemp->name=Matrix[al]->motif_name;
	    /*we control the size of closures using the parameter -c base on the original size of the motif profile seed*/
	    if(po->size==0)
		cctemp->closure_rows=motif_number_1;
	    else
		cctemp->closure_rows=MIN(motif_number_1,po->size*Matrix[al]->RowNum);
	}
	cctemp->sequence=dsNew(cctemp->closure_rows);
	cctemp->position=dsNew(cctemp->closure_rows);
	cctemp->score=(continuous*)malloc(sizeof(continuous)*cctemp->closure_rows);
	cctemp->consensus=consensus;
	cctemp->frequencyM=frequency;
	if(po->zscore){cctemp->zscore=zscore;cctemp->zvalue=100*zscore;cctemp->enrich=log2enrichment;cctemp->evalue=100*enrichment;}
	cctemp->significance=pvalue;
	cctemp->pvalue=-(100*log(pvalue));
	for(kk=0;kk<cctemp->closure_rows;kk++)
	{
	    dsPush(cctemp->sequence,dsItem(gene1,kk));
	    dsPush(cctemp->position,dsItem(cond1,kk));
	    cctemp->score[kk]=score1[kk];
	}
	cc[al]=cctemp;
    }

    /*report the identified closures*/
    report_closures(fw,cc,iteration_num);
    free(cc);
    /*free(gene);
    free(cond);
    free(gene1);
    free(cond1);
    free(gene2);
    free(cond2);
    free(score);
    free(score1);*/
    uglyTime("\nThe significance of motif alignments are written to %s",fn);
}
/******************************************************************/
