/* Author: Qin Ma <maqin@csbl.bmb.uga.edu>, Feb. 12, 2010
 * Usage: This is part of bicluster package. Use, redistribution, modify without limitations
 * show how does the whole program work
 */

/***********************************************************************/

#include "main.h"

/***********************************************************************/

int main(int argc, char* argv[])
{
	/* Start the timer */
	uglyTime(NULL);
	/* get the program options defined in get_options.c */
	get_options(argc, argv);
	/*change consensus to matrix format*/
	if (po->IsConsensus)
	{
		read_motif_consensus (po->Fp);
		exit(1);
	}
	/* pop up the information of Bregulon */
	printf("\nBBS%.2f: BoBro-based motif scanning tool (compiled "__DATE__" "__TIME__")\n\n",VER);
	CLOSURE_SIZE_D = 6000;
	/* scanning: read the fasta file and aligned motif file*/	
	if (po->ToBeSearched)
		read_sequences(po -> FP);
	if (po->IsAlignment)
	{
		read_motif_alignment(po->FA);
		if (po->IsCompare)
		{
                        compare_motif(addSuffix(po->AN,".similarity"));
                        exit(1);
		}
		if (po->output)
			validation_motif(po->ON);
		else
			validation_motif(addSuffix(addSuffix(addSuffix(po->FN,"_"),po->AN), ".motifinfo"));
	}
	else if (po->IsMatrix)
	{
		read_motif_matrix(po->FM);
		if (po->IsCompare)
		{
                        compare_motif(addSuffix(po->MN,".similarity"));
                        exit(1);
		}
		if (po->output)
			validation_motif(po->ON);
		else
			validation_motif(addSuffix(addSuffix(addSuffix(po->FN,"_"),po->MN), ".motifinfo"));
	}
	free(po);
	return 0;
}
/***********************************************************************/
