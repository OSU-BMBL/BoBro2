#ifndef _CLOSURE_PROCESS_H
#define _CLOSURE_PROCESS_H

#include "struct.h"
/*prototypes*/
void combine_closures(Closures **aa, int closure_id, continuous threshold, const char* fn, const char* fn1);
discrete **frequency_matrix (char **sequence_temp, int a, int b, int motif_number);
continuous **get_profile (char **sequence_temp, continuous **markov_matrix, int a, int b, int motif_number);
continuous **impovre_profle (continuous **scoreM, double length_local_1);
char **get_sequences_from_closures (Closures *aa);
char **get_2L_sequeces_from_closures (Closures *aa);
int get_genome_num_from_closure (Closures *aa);
continuous *get_column_IC (Closures **aa, int clos,  int num);
continuous *get_column_IC_12 (Closures **aa, int clos_1, int clos_2, int startpos_1, int startpos_2, int num_a, int num_b);
continuous *get_column_IC_21 (Closures **aa, int clos_1, int clos_2, int startpos_1, int startpos_2, int num_a, int num_b);
continuous *get_species_overlap_num (int c_1, int c_2, int g_1, int g_2);
void get_z_score_matrix (continuous **matrix_score, int closure_id, int oper_num_all, FILE *fw1, char **species_name,int species_num);
continuous get_average_from_array(continuous *edge_weight, int edge_num);
continuous get_variance_from_array (continuous *edge_weight, continuous edge_average, int edge_num);
void get_alignment_from_two_closures (int num_1, int num_2, Closures **aa, FILE *fw1, double similarity_score, double z_score);

static int compare_continuous (const void *a, const void *b);
int zscore_cmpr(const void *a, const void *b);
void sort_zscore_list(Zscore **z_score_all, int id);
continuous **get_profile_new (continuous **markov_matrix, discrete **frequency, int a, int b, int motif_number);
void print_species_overlap (int c_1, int c_2, FILE *fw1);

/* global data */
int col_width;
Edge **edge_list;
Edge *edge_ptr;
extern bits16 **profile;

/*from read_file*/
extern void init_dis_operon();
#endif
