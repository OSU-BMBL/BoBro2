# used to generate all the promoters in a species based on .ptt file and .fna file
#!/usr/bin/perl
#File: gene_info.pl
#Description: collect the gene info from ptt and fna files; mainly the promoter
#

use strict;
use warnings;
use Data::Dumper;
use Getopt::Std;


#my $ptt_file = "NC_000913.ptt";
#my $fna_file = "NC_000913.fna";
if(!$ARGV[0]){
	print "perl $0 .ptt .fna output\n";
	exit(1);
}
my ($ptt_file, $fna_file, $output_file) = @ARGV;

#############################################
# the structure for all genes
#############################################
# hash %species {
# 		  "gi" => "49175990",
# 		  "ref" => "NC_000913.2",
# 		  "name" => "Eschericha...",
# 		  "genome" => "AGCTTT...",
# 		  }
# array @genes [
# 	hash {
# 		"start" => 190,
# 		"end" => 255,
# 		"strand" => '+',
# 		"length" => 21,
# 		"PID" => 16127995,
# 		"gene" => "thrL",
# 		"synonym" => "b001"
# 		}
# 	...
# 	];
############################################ 	

my %species;
my @genes;

open PTT, "$ptt_file" or die "Cannot open $ptt_file: $!";
while(<PTT>) {
    chomp;
    next unless /^([0-9]+)\.\.([0-9]+)\t/;
    my $start = $1;
    my $end = $2;
    my ($start_end, $strand, $length, $PID, $gene, $synonym) = split;

    push @genes, {
	"start" => $start,
	"end" => $end,
	"strand" => $strand,
	"length" => $length,
	"PID" => $PID,
	"gene" => $gene,
	"synonym" => $synonym,
    };
}
close PTT;

open FNA, "$fna_file" or die "Cannot open $fna_file: $!";
while(<FNA>) {
    chomp;
    if (/^>/) {
	my ($gi, $ref, $name) = (split /\|/)[1,3,4];

	%species = (
	    "gi" => $gi,
	    "ref" => $ref,
	    "name" => $name
	);

    } else {
	$species{"genome"} .= $_;
    }
}
close FNA;

#print Dumper \%species;
#print Dumper \@genes;
################ reading leading and lagging information #########
# for each gene, there is a leading or lagging character, reading in
# this and combind with output_intergenic_region_with_gd()
#my $gd_file = "Ecoli_leading_lagging.txt";
#my %gd;
#open GD, "$gd_file" or die "Cannot open $gd_file: $!";
#
#while (<GD>) {
#    chomp;
#    my ($gi, $info) = (split)[0, 3];
#    if ($info == 1 or $info == 3) {
#	$info = "d";
#    } else {
#	$info = "g";
#    }
#
#    $gd{$gi} = $info;
#}
#close GD;
#

# SHOW
output_intergenic_promoter($output_file);
#output_gene_sequence("Ecoli_gene_seq.txt");
#output_intergenic_region_with_gd(); 
######################### sub ############################

# print the gene sequence
sub output_gene_sequence {
    my ($output_file) = @_;
    my $genome = $species{"genome"};
    #print "$genome\n";

    open GOUT, ">$output_file" or die " Cannot open $output_file: $!";
    foreach my $g (@genes) {
	my $s = $g->{"start"};
	my $e = $g->{"end"};
	my $strand = $g->{"strand"};
	my $pid = $g->{"PID"};
	my $g_name = $g->{"gene"};
	my $synonym = $g->{"synonym"};

	my $length = $e-$s+1;
	print "$length\n";
	my $seq = substr($genome, $s-1, $length);

	if ($strand eq '-') {
	    $seq = revcom ($seq);
	}

	print GOUT ">$s\.\.$e\t$strand\t$pid\t$g_name\t$synonym\n";
	print GOUT "$seq\n";

    }

    close GOUT;
}


# output_intergenic_promoter, consider direction
sub output_intergenic_promoter {
    my ($output_file) = @_; 

    #set a maximum length if needed
    my $max_length = 300;

    open OUT, ">>$output_file" or die "Cannot open $output_file: $!";

    my $gene_num = $#genes;
    my ($pro_end, $pro_start, $pro_seq);

    #consider the first gene separately
    if($genes[0]->{"strand"} eq '+') {
	$pro_end = $genes[0]->{"start"} -1;
	$pro_start = $genes[-1]->{"end"} +1;
	$pro_seq = substr($species{"genome"}, $pro_start -1);
	$pro_seq .= substr($species{"genome"}, 0, $pro_end);
    } else {
	$pro_start = $genes[0]->{"end"} +1;
	$pro_end = $genes[1]->{"start"} -1;
	$pro_seq = substr($species{"genome"}, $pro_start-1, $pro_end-$pro_start+1);
	$pro_seq = revcom($pro_seq);
    }
    print OUT ">$genes[0]->{'PID'}\n";
    #print OUT ">$genes[0]->{'PID'}\_$pro_start\.\.$pro_end\_$genes[0]->{'strand'}\_$genes[0]->{'gene'}\_$genes[0]->{'synonym'}\n";
    print OUT "$pro_seq\n";

    #output other promoter
    for(my $i=1; $i<$gene_num; $i++) {
	if($genes[$i]->{"strand"} eq '+') {
	    $pro_end = $genes[$i]->{"start"}-1;
	    $pro_start = $genes[$i-1]->{"end"}+1;
	    next if $pro_start > $pro_end;   #gene overlap

	    # cut long promoter short
	    if($pro_end-$pro_start+1 > $max_length) {
		$pro_start = $pro_end - $max_length +1;
	    }

	    $pro_seq = substr($species{"genome"}, $pro_start-1, $pro_end-$pro_start+1);
	} else {
	    $pro_start = $genes[$i]->{"end"}+1;
	    $pro_end = $genes[$i+1]->{"start"}-1;
	    next if $pro_start > $pro_end;

	    #cut long promoter short
	    if($pro_end-$pro_start+1 > $max_length) {
		$pro_end = $pro_start + $max_length -1;
	    }
	    $pro_seq = substr($species{"genome"}, $pro_start-1, $pro_end-$pro_start+1);
	    $pro_seq = revcom($pro_seq);
	}
	print OUT ">$genes[$i]->{'PID'}\n";
	#print OUT ">$genes[$i]->{'PID'}\_$pro_start\.\.$pro_end\_$genes[$i]->{'strand'}\_$genes[$i]->{'gene'}\_$genes[$i]->{'synonym'}\n";
	print OUT "$pro_seq\n";
    }

    #deal the last one
    if($genes[-1]->{"strand"} eq '-') {
	$pro_end = $genes[0]->{"start"} -1;
	$pro_start = $genes[-1]->{"end"} +1;
	$pro_seq = substr($species{"genome"}, $pro_start -1);
	$pro_seq .= substr($species{"genome"}, 0, $pro_end);
	$pro_seq = revcom($pro_seq);
    } else {
	$pro_start = $genes[-2]->{"end"} +1;
	$pro_end = $genes[-1]->{"start"} -1;
	$pro_seq = substr($species{"genome"}, $pro_start-1, $pro_end-$pro_start+1);
    }
    #print OUT ">$genes[-1]->{'PID'}\_$pro_start\.\.$pro_end\_$genes[-1]->{'strand'}\_$genes[-1]->{'gene'}\_$genes[-1]->{'synonym'}\n";
    print OUT ">$genes[-1]->{'PID'}\n";
    print OUT "$pro_seq\n";

    close OUT;

}

# revcom 
#
# A subroutine to compute the reverse complement of DNA sequence

sub revcom {

    my($dna) = @_;

    # First reverse the sequence
    my $revcom = reverse $dna;

    # Next, complement the sequence, dealing with upper and lower case
    # A->T, T->A, C->G, G->C
    $revcom =~ tr/ACGTacgt/TGCAtgca/;

    return $revcom;
}

# print out the inter genetic region and the genes beside this region
sub output_inter_genetic_region {


    # print for the 0th inter region
    my $pos_s = 1;
    my $pos_e = ($genes[0]->{"start"}) - 1;
    my $gene = ($genes[0]->{"PID"})."_".($genes[0]->{"strand"});
    print ">1..$pos_e\t-\t$gene\n";
    print substr($species{"genome"}, $pos_s-1, $pos_e - $pos_s + 1), "\n";

    my $inter_n = 1;


    while ( defined $genes[$inter_n] ) {

	$pos_s = ($genes[$inter_n - 1]->{"end"}) + 1;
	$pos_e = ($genes[$inter_n ]->{"start"}) - 1;
	my $left_gene = ($genes[$inter_n -1]->{"PID"})."_".($genes[$inter_n]->{"strand"});
	my $right_gene = ($genes[$inter_n]->{"PID"})."_".($genes[$inter_n]->{"strand"});

	if($pos_e - $pos_s + 1>0) {
	    print ">$pos_s..$pos_e\t$left_gene\t$right_gene\n";
	    print substr($species{"genome"}, $pos_s-1, $pos_e - $pos_s +1), "\n";
	} else {
	    print ">$pos_s..$pos_e\t$left_gene\t$right_gene\n";
	    print "\n";
	}

	$inter_n++;
    }

    # print for the last inter region
    $pos_s = $genes[$inter_n -1]->{"end"} +1;
    $gene = ($genes[$inter_n -1]->{"PID"}) ."_". ($genes[$inter_n-1]->{"strand"});
    $pos_e = length ($species{"genome"});

    print ">$pos_s..$pos_e\t$gene\t-\n";
    print substr($species{"genome"}, $pos_s-1, $pos_e - $pos_s +1), "\n";

}


# print out the inter genetic region and the genes beside this region and make the
# gene with leading or lagging information
#sub output_intergenic_region_with_gd {
#
#
#    # print for the 0th inter region
#    my $pos_s = 1;
#    my $pos_e = ($genes[0]->{"start"}) - 1;
#
#    my $tmp_gid = $genes[0]->{"PID"};
#    my $gd_info = $gd{$tmp_gid};
#    my $gene = ($genes[0]->{"PID"})."_".($genes[0]->{"strand"})."_".$gd_info;
#
#    print ">1..$pos_e\t-\t$gene\n";
#    print substr($species{"genome"}, $pos_s-1, $pos_e - $pos_s + 1), "\n";
#
#    my $inter_n = 1;
#
#
#    while ( defined $genes[$inter_n] ) {
#
#	$pos_s = ($genes[$inter_n - 1]->{"end"}) + 1;
#	$pos_e = ($genes[$inter_n ]->{"start"}) - 1;
#
#	$tmp_gid = $genes[ $inter_n -1 ]->{"PID"};
#	$gd_info = $gd{$tmp_gid};
#
#	my $left_gene = ($genes[$inter_n -1]->{"PID"})."_".($genes[$inter_n -1]->{"strand"})."_".$gd_info;
#
#	$tmp_gid = $genes[ $inter_n  ]->{"PID"};
#	$gd_info = $gd{$tmp_gid};
#	my $right_gene = ($genes[$inter_n]->{"PID"})."_".($genes[$inter_n]->{"strand"})."_".$gd_info;
#
#	if($pos_e - $pos_s + 1>0) {
#	    print ">$pos_s..$pos_e\t$left_gene\t$right_gene\n";
#	    print substr($species{"genome"}, $pos_s-1, $pos_e - $pos_s +1), "\n";
#	} else {
#	    print ">$pos_s..$pos_e\t$left_gene\t$right_gene\n";
#	    print "\n";
#	}
#
#	$inter_n++;
#    }
#
#    # print for the last inter region
#    $pos_s = $genes[$inter_n -1]->{"end"} +1;
#
#    $tmp_gid = $genes[ $inter_n -1 ]->{"PID"};
#    $gd_info = $gd{$tmp_gid};
#    $gene = ($genes[$inter_n -1]->{"PID"}) ."_". ($genes[$inter_n-1]->{"strand"})."_".$gd_info;
#
#
#    $pos_e = length ($species{"genome"});
#
#    print ">$pos_s..$pos_e\t$gene\t-\n";
#    print substr($species{"genome"}, $pos_s-1, $pos_e - $pos_s +1), "\n";
#
#}
