#ifndef _GET_OPTIONS_H
#define _GET_OPTIONS_H

#include <getopt.h>
#include "struct.h"

/* prototypes */
void get_options (int argc, char* argv[]);

#endif
