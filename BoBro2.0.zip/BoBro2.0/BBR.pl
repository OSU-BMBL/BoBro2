#!/usr/bin/perl
# do the bobro job
#
use strict;
#use warnings; # don't use warnings because of second law of thermodynamics

my $manual =  <<HERE;
De-nove Motif finding in a fasta-format promoter file with length 14:
	perl BBR.pl 1 promoters 14
De-nove Motif finding with background sequences (if have) in fasta format:
	perl BBR.pl 2 promoters backgroud_file 14
Motif finding with a comparative genomic framework:
	perl script/bbr_cmp_method.pl 

	if you use multigenomic compare:
	foreach sequence in the promoters file, there should be a corresponting ortholog gene promoter file( fasta format and species NC id after the '>' ) named with the gene's id same as the promoter file. In the ortholog_background_directory, there should be a backgroud file (fasta format) named with the specise's NC id.


HERE
#Motif finding with multigenomic compare (without background):
#perl BBR 4 promoters backgroud_file

print "$manual" and die unless $ARGV[0];

if($ARGV[0] == 1) {
    system("bin/BoBro -i $ARGV[1] -F -l $ARGV[2]");
    system ("cat $ARGV[1].closures  | perl ./script/parse_bobro_alignment.pl");
    my @motifs = <Motif-*>;
    foreach (@motifs) {
	system ("bin/BBS -i $ARGV[1] -j $_ -E");
    }
    system("cat $ARGV[1]\_Motif-*.motifinfo > $ARGV[1].motifinfo");
    system("rm Motif-* $ARGV[1]\_Motif-*");
    print "\nThe final results can be found in $ARGV[1].motifinfo\n";

} elsif ($ARGV[0] == 2) {
    system ("bin/BoBro -i $ARGV[1] -Z $ARGV[2] -F -o 100 -l $ARGV[2]");
    system("cat $ARGV[1].closures | perl ./script/parse_bobro_alignment.pl");
    my @motifs = <Motif-*>;
    foreach (@motifs) {
	system ("bin/BBS -i $ARGV[1] -j $_ -z $ARGV[2] -E");
    }
    system("cat $ARGV[1]\_Motif-*.motifinfo > $ARGV[1].motifinfo");
    system("rm Motif-* $ARGV[1]\_Motif-*");

} elsif ($ARGV[0] == 3) {
    system ("perl ./script/bbr_cmp_method.pl");
#    system ("bin/BoBro -i $ARGV[1] -Z $ARGV[2] -F | perl ./script/parse_bobro_alignment.pl");
#    my @motifs = <Motif-*>;
#    foreach (@motifs) {
#	system ("bin/BBS -i $ARGV[1] -j $_ -z $ARGV[2] -E");
#    }
#    system("cat $ARGV[1]\_Motif-*.motifinfo > $ARGV[1].motifinfo");
#    system("perl search_ortholog_promoter.pl $ARGV[3] $ARGV[4]");
#    system("rm Motif-* $ARGV[1]\_Motif-*");
} elsif ($ARGV[0] == 4) {
#    system ("bin/BoBro -i $ARGV[1]  | perl parse_bobro_alignment.pl");
#    my @motifs = <Motif-*>;
#    foreach (@motifs) {
#	system ("bin/BBS -i $ARGV[1] -j $_ -E");
#    }
    #### add
} else {
    print "$manual" and die;
}


