# facilities for ncbi bacteria genome data

1;
