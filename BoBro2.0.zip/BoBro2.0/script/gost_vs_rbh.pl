#!/usr/bin/perl
#
#Description: basic compare between rbh and gost
#

use strict;
use warnings;
use Data::Dumper;

unless (@ARGV == 2) {
    print "perl $0 gost_result rbh_result\n";
    die;
}

my ($gost_f, $rbh_f) = @ARGV;

my %gost = read_data($gost_f);

my %rbh = read_data($rbh_f);

my $g_n = keys %gost;
my $r_n = keys %rbh;
my $common = 0;
foreach (keys %gost) {
    $common++ if $rbh{$_};
}

print "RBH pairs: $r_n\n", "GOST pairs: $g_n\n", "Common pairs: $common\n";


sub read_data {
    my ($file) = pop;
    my %h;
    open IN, $file or die "Cannot open $file: $!";
    while(<IN>) {
	chomp;
	my $pair = (split)[0];
	$h{$pair} = 1;
    }
    close IN;
    return %h;
}


