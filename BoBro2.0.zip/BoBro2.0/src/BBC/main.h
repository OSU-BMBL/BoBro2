#ifndef _MAIN_H
#define _MAIN_H

#include "struct.h"
/* compare_sequence subroutine prototypes  */
extern void read_closures (FILE* fc);
extern void read_reference_genome (FILE* fp);
extern int get_options (int argc, char* argv[]);
extern void combine_closures (Closures **aa, int closure_id, continuous threshold, FILE *fw1, FILE *fw);
#endif
