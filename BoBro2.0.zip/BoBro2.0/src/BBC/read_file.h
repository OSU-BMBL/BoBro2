#ifndef _CLOSURE_PROCESS_H
#define _CLOSURE_PROCESS_H

#include "struct.h"
/* prototypes  */
void read_closures (FILE* fc);
void read_reference_genome (FILE* fp);
static int charset_add(discrete *ar, discrete s);
void init_dis_operon();

/*from closure_process*/
extern discrete **get_closure_matrix_1 (Closures **aa, int closure_id, continuous threshold, FILE *fw1);
extern continuous get_average_from_array(continuous *edge_weight, int edge_num);
extern continuous get_variance_from_array (continuous *edge_weight, continuous edge_average, int edge_num);
extern char **get_alignment_from_two_closures (int num_1, int num_2, Closures **aa);

/*from pvalue*/
extern continuous **markov (char **sequences, int seq_num);

#endif
