#!/usr/bin/perl
#
#	
#

use strict;
#use warnings;
use Data::Dumper;
use lib "script";
use fast_io;
use bbrs;

my $usage = <<HERE;
Input format:
species_directory: the directory containing the species information downloaded from NCBI
operon (combinedXXX)

format:
1: 16077069 
2: 16077070 
3: 16077071 16077072 255767014 
4: 16077074 
...

orthology (stanard output of GOST)
format:
145698239,187933779	5e-90,6e-90
145698257,187933775	2e-05,3e-05
145698262,187935634	1e-27,6e-27
145698268,187932476	2e-25,9e-23
145698269,187933610	5e-05,7e-05

Usage:
\$ perl $0 gi_list target_spe target_opr ref_spe_dir ref_opr_dir orthlog_dir output_dir

Example:
\$ perl $0 ./example/target_list ./example/Escherichia_coli_K_12_substr__MG1655_uid57779 ./example/Ecoli.opr ./example/ncbi_data ./example/operon ./example/ortholog ./example_output

HERE

my $debug = 0;

unless (@ARGV == 7) {
    print $usage;
    die;
}

my ($gi_list,# the gi list from the target species, from which to find the motif
    $spe1,   # target spe dir
    $opr1,   # target operon file
    $ref_spes_dir,   # ref spe
    $ref_opr_dir,   # ref operon file
    $orth_dir,   # orthlogy file target to ref
    $output_dir, 
) = @ARGV;


my $tmp_dir;
if ($debug) {
    $tmp_dir = "cache";
} else {
    $tmp_dir = "cache".$$;
}

### mkdir for tmp data  and output###
mkdir $tmp_dir unless -e $tmp_dir;

mkdir $output_dir unless -e $output_dir;

### info for all spe ###
my %spe2nc;
my %gi2first_gene;

### target info ###
my @target_gis = read_list($gi_list);


my %target_spe_prt = promoter_of_spe($spe1, $opr1);
my $target_spe_nc = $spe2nc{$spe1};

#my %target_spe_prt = fasta2hash("$tmp_dir/$target_spe_nc.prt");

#print Dumper \%target_spe_prt;

my %target_prt;
foreach (@target_gis) {
    $target_prt{$_} = $target_spe_prt{$_};
}
hash2fasta("$tmp_dir/target.prt", \%target_prt);
#my $cmd = bbr_cmd("$tmp_dir/target.prt", "$spe1/$target_spe_nc.fna");
#print "$cmd\n";
system (bbr_cmd("$tmp_dir/target.prt", "$spe1/$target_spe_nc.fna"));
my $target_motifs = read_bbs_motif("$tmp_dir/target.prt.motifinfo");
#print Dumper $target_motifs;
my $target_motifs_score = read_bbs_stat("$tmp_dir/target.prt.motifinfo");
#print Dumper $target_motifs_score;


### prepare ref promoter ####
my @ref_spes = glob ("$ref_spes_dir/*");
@ref_spes = grep {!($_ eq $spe1)} @ref_spes;
my @ref_ncs;
foreach my $rs (@ref_spes) {
    my $nc = get_main_nc("$rs");
    push @ref_ncs, $nc;
    $spe2nc{$rs} = $nc;

    promoter_of_spe("$rs", "$ref_opr_dir/$nc.opr");
}

### prepare ref otholog info ###
my $ortholog;
foreach my $rs (@ref_spes) {
    my $nc = $spe2nc{"$rs"};
    my %orth = ortholog2hash("$orth_dir/$target_spe_nc.$nc.gost");
    $ortholog->{$nc} = { %orth };
}



### check each original motif in the reference genomes ###
my $ortholog_seq_ratio_cutoff = 0.5;
foreach my $m (keys %{$target_motifs}) {
    my @from = @{$target_motifs->{$m}{'from'}};
    my @motifs = @{$target_motifs->{$m}{'motif'}};
    write_motif("$tmp_dir/$m.motif", $m, @motifs);

    foreach my $rs (@ref_spes) {
	my $nc = $spe2nc{$rs};
	my %promoter = fasta2hash("$tmp_dir/$nc.prt");
	my %orth = %{$ortholog->{$nc}};

	my %ref_prt;

	my $count = 0;
	foreach (@from) {
	    if( $orth{$_} ) {
		$ref_prt{$orth{$_}} = $promoter{$orth{$_}};
		$count++;
	    }
	}


	if ($count > @from * $ortholog_seq_ratio_cutoff) {

	    hash2fasta("$tmp_dir/$m.$nc.refprt", \%ref_prt);
	    chdir("$tmp_dir");
	    my $bbs = bbs_cmd("$m.motif", "$m.$nc.refprt", "../$rs/$nc.fna");
	    system($bbs);

	    my $info = read_single_bbs_stat("$m.$nc.refprt_$m.motif.motifinfo");
	    $target_motifs->{$m}{$nc} = $info if defined $info;
	    chdir("..");

	}
    }
}
#print Dumper $target_motifs;

#### motif finding end, collect result and out put #####
my $total_spe_num = 1 +  @ref_ncs;
foreach my $m (keys %{$target_motifs_score}) {
    my $zscore_sum = $target_motifs_score->{$m}{'zscore'};

    foreach my $ref (@ref_ncs) {
	$zscore_sum += $target_motifs->{$m}{"$ref"}{'zscore'} if defined $target_motifs->{$m}{"$ref"};
    }
my $average_zscore = sprintf "%.2f", ($zscore_sum / $total_spe_num);
    $target_motifs_score->{$m}{'average_zscore'} = $average_zscore;
}


my @final_motif_order = reverse sort {$target_motifs_score->{$a}{'average_zscore'} <=> $target_motifs_score->{$b}{'average_zscore'} } (keys %{$target_motifs_score});
#print Dumper \@final_motif_order; 

###### zscore cutoff ###
my $zscore_cutoff = 2.0;
@final_motif_order = grep { $target_motifs_score->{$_}{'average_zscore'} > $zscore_cutoff } @final_motif_order;

if ($debug) { print Dumper \@final_motif_order; }
#### alignment ######
open OUT, ">$output_dir/motif.alignment" or die "Cannot Open $output_dir/motif.alignment: $!";
foreach my $m(@final_motif_order) {
    print OUT ">$m\n";
    print OUT (join "\n", @{$target_motifs->{$m}{'motif'}});
    print OUT "\n";
}
print OUT ">end";
close OUT;
system "perl BBC.pl $output_dir/motif.alignment 1";


### main result, similar format as BoBro ####
open OUT, ">$output_dir/result.txt" or die "Cannot open $output_dir/result.txt: $!";
foreach my $m (@final_motif_order) {
    #print "$m\n";
    #my $seq = write_motif($m, $target_motifs_score, $target_motifs);
    my $seq;
    $seq .= '********************************************************';
    $seq .= "\n";
    $seq .= " $m\n";
    $seq .= '********************************************************';
    $seq .= "\n\n";
    $seq .= " Consensus: ";
    $seq .= $target_motifs_score->{$m}{'consensus'};
    $seq .= "\n";
    $seq .= " Motif length: ";
    $seq .= $target_motifs_score->{$m}{'length'};
    $seq .= "\n";
    $seq .= " Binding sites number: ";
    $seq .= $target_motifs_score->{$m}{'number'};
    $seq .= "\n";
    $seq .= " Pvalue: ";
    $seq .= $target_motifs_score->{$m}{'pvalue'};
    $seq .= "\n";
    $seq .= " Zscore: ";
    $seq .= $target_motifs_score->{$m}{'average_zscore'};
    $seq .= "\n";
    $seq .= " Enrichment: ";
    $seq .= $target_motifs_score->{$m}{'enrichment'};
    $seq .= "\n\n";
    $seq .= "----- Searched binding sites  of current Motif ------
#Motif	Seq	Start	Motif		End	Score	Info\n";

    foreach (@{$target_motifs->{$m}{'record'}}) {
	$seq .= "$_\n";
    }

    $seq .= "\n";

    print OUT $seq;

}
close OUT;

### draw logo ###
my $logo_num_limit = 10;
foreach my $m (@final_motif_order[0..$logo_num_limit]) {
    next unless defined $m;
    write_alignment("$tmp_dir/$m.align", @{$target_motifs->{$m}{'motif'}});
    system(draw_logo("$tmp_dir/$m.align", "$output_dir/$m.png"));
}

if(!$debug) {
    system ("rm $tmp_dir/*");
    system("rm -rf $tmp_dir");
}


#### subs ####
# give a $spe dir and $opr structure, write the real promoter of each gene to the tmp_dir in a fasta format, record spe2nc and gi2first_gene at the same time
# return %promoter_with_operon_structure;
sub promoter_of_spe {
    my ($spe, $opr) = @_;
    my %size;
    opendir SPE, $spe or die "Cannot opendir $spe: $!";
    foreach my $f (readdir SPE) {
	next unless $f =~ /\.faa/;

	#symlink "../../$spe/$f", "$tmp_dir/faa/$f";
	$size{$f} = -s "$spe/$f";
    }
    close SPE;
    #print Dumper \%size;

    my @ncs = reverse sort {$size{$a} <=> $size{$b}} (keys %size);

    foreach (@ncs) {
	$_ =~ s/\.faa//;
	system("perl script/parse_promoter.pl $spe/$_.ptt $spe/$_.fna $tmp_dir/$_.prt_no_opr_consider");
    }
    $spe2nc{$spe} = $ncs[0];
    my $cat_ptt_cmd = "cat $spe/NC_*.ptt > $tmp_dir/$ncs[0].pttcombine";
    system ($cat_ptt_cmd);
    my %orgin_pro = fasta2hash("$tmp_dir/$ncs[0].prt_no_opr_consider");
    #print Dumper \%orgin_pro;
    my $info = ptt2hash("$tmp_dir/$ncs[0].pttcombine");
    my %operon_hash = operon2hash($opr);
    #print Dumper \%operon_hash;
    #print Dumper $info;
    gi2first_gene_in_operon(\%operon_hash, $info, \%gi2first_gene);
    my %promoter_with_operon_structure;
    foreach (keys %orgin_pro) {
	$promoter_with_operon_structure{$_} = $orgin_pro{ $gi2first_gene{$_} };
	#print "$_\n" unless defined $gi2first_gene{$_};
    }
    hash2fasta("$tmp_dir/$ncs[0].prt", \%promoter_with_operon_structure);
    return %promoter_with_operon_structure;
}
#print Dumper \%gi2first_gene;


### set sep2nc ###
sub get_main_nc {
    my ($spe) = @_;
    my %size;
    opendir SPE, $spe or die "Cannot opendir $spe: $!";
    foreach my $f (readdir SPE) {
	next unless $f =~ /\.faa/;

	#symlink "../../$spe/$f", "$tmp_dir/faa/$f";
	$size{$f} = -s "$spe/$f";
    }
    close SPE;
    #print Dumper \%size;

    my @ncs = reverse sort {$size{$a} <=> $size{$b}} (keys %size);

#    foreach (@ncs) {
#	$_ =~ s/\.faa//;
#	system("perl script/parse_promoter.pl $spe/$_.ptt $spe/$_.fna $tmp_dir/$_.prt_no_opr_consider");
#    }
    $ncs[0] =~ s/\.faa//;
    return $ncs[0];
}
