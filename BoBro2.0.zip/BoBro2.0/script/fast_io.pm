# read in an fasta file to a hash or vise verse
use strict;
use warnings;


sub fasta2hash {

    my ($f) = pop;
    my %h;
    my $k_now;
    open IN, $f or die "Cannot open $f: $!";
    while(<IN>) {
	chomp;
	if(s/^>//) {
	    $k_now = $_;
	} else {
	    $h{$k_now} .= $_;
	}
    }
    close IN;
    return %h;
}


sub hash2fasta {
    my ($f, $h) = @_;
    open OUT, ">$f" or die "Cannot open $f: $!";
    while (my ($k, $v) = each %{$h}) {
	next unless $v;
	print OUT ">$k\n";
	print OUT "$v\n";
    }
    close OUT;
    return 1;
}

sub operon2hash {
    my $f = pop;
    my %h;
    open IN, $f or die "Cannot open $f: $!";
    while (<IN>) {
	chomp;
	next unless /^(\d+): (.*)$/;
	my @g = split / /, $2;
	$h{$1} = [ @g ];
    }
    close IN;
    return %h;
}

sub ortholog2hash {
    my $f = pop;
    my %h;
    open IN, $f or die "Cannot open $f: $!";
    while(<IN>) {
	chomp;
	next unless /^(\d+),(\d+)/;
	$h{$1} = $2;
    }
    close IN;
    return %h;
}

sub ptt2hash {
    my $f = pop;
    # $h -> {gi}{'strand'}
    #           {'start'}
    #           {'end'}
    #           {'name'}
    #           {'synonym'}
    #           {'code'}
    #           {'cog'}
    my $h;

    open IN, $f or die "Cannot open $f: $!";
    while(<IN>) {
	chomp;
	next unless /^\d+\.\.\d+/;
	my ($p, $strand, $l, $id, $name, $syn, $code, $cog) = split;
	my ($s, $e) = split /\.\./, $p;
	$h->{$id}{'strand'} = $strand;
	$h->{$id}{'start'} = $s;
	$h->{$id}{'end'} = $e;
	$h->{$id}{'name'} = $name;
	$h->{$id}{'synonym'} = $syn;
	$h->{$id}{'code'} = $code;
	$h->{$id}{'cog'} = $cog;
    }
    close IN;
    return $h;
}

sub first_gene {
    # this sub return the first gene of an operon with the asumation that
    # all genes are on the same chain
    # this $info should be returned by func ppt2hash
    my ($info, @genes) = @_;

    if(@genes == 1) {
	return $genes[0];
    }

    @genes = sort { $info->{$a}{'start'} <=> $info->{$b}{'start'} } @genes;
    my $chain = $info->{$genes[0]}{'strand'};
    if($chain eq '+') {
	return shift @genes;
    } else {
	return pop @genes;
    }
}

sub gi2first_gene_in_operon {
    # $operon_hash is the value return by operon2hash
    # $info is the value return by ptt2hash
    # this proceder will chang $gi2first_gene
    my ($operon_hash, $info, $gi2first_gene) = @_;
    foreach my $opr ( keys %{$operon_hash} ) {
	#print "$opr\n";
	my @opr_s = @{$operon_hash->{$opr}};
	my $first = first_gene($info, @opr_s);
	foreach (@opr_s) {
	    #print "$_\n";
	    $gi2first_gene->{$_} = $first;
	}
    }
}

sub unique_ele {
    # for an array, need not to be sorted, this sub removes the duplicate
    # elements in it then return the array
    my %saw;
    my @ret = grep(!$saw{$_}++, @_); # remove duplicate
    return @ret;
}

sub read_list {
    my $f = pop;
    my @a;
    open IN, $f or die "Cannot open $f: $!";
    while(<IN>) {
	chomp;
	push @a, $_;
    }
    close IN;
    return @a;
}


1;
